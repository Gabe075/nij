import pkg from "../package.json" with { type: "json" };
import { BOT_NAME } from "./config.js";
import { getPrefix } from "./utils/database.js";
import { readMore } from "./utils/index.js";

export function menuMessage(groupJid) {
  const date = new Date();

  const prefix = getPrefix(groupJid);

  return `⚜️  𝕻𝖆𝖈̧𝖔 𝕴𝖒𝖕𝖊𝖗𝖎𝖆𝖑 ⚜️${readMore()}

"Tudo pela Pátria, nada pela glória."

📜 𝐈𝐧𝐬𝐭𝐢𝐭𝐮𝐢𝐜̧𝐚̃𝐨: ${BOT_NAME}
📅 𝐃𝐚𝐭𝐚: ${date.toLocaleDateString("pt-br")}
⏳ 𝐇𝐨𝐫𝐚́𝐫𝐢𝐨: ${date.toLocaleTimeString("pt-br")}
🔰 𝐏𝐫𝐞𝐟𝐢𝐱𝐨: ${prefix}
⚙️ 𝐕𝐞𝐫𝐬𝐚̃𝐨: v${pkg.version}

╔══════════════════════╗
      ⚜️ DOM PEDRO II ⚜️
╚══════════════════════╝

━━━━━━━━━━━━━━━━━━
📜 REGISTRO & PERFIL
━━━━━━━━━━━━━━━━━━
» ${prefix}registro
» ${prefix}perfil
» ${prefix}ranking
» ${prefix}conquistas
» ${prefix}medalhas
» ${prefix}talentos

━━━━━━━━━━━━━━━━━━
💼 ECONOMIA & TRABALHO
━━━━━━━━━━━━━━━━━━
» ${prefix}banco
» ${prefix}depositar
» ${prefix}sacar
» ${prefix}pagar
» ${prefix}diario
» ${prefix}empregos
» ${prefix}escolher
» ${prefix}trabalhar
» ${prefix}emprestimo
» ${prefix}caridade
» ${prefix}fisco

━━━━━━━━━━━━━━━━━━
🏦 INVESTIMENTOS & FINANÇAS
━━━━━━━━━━━━━━━━━━
» ${prefix}bancocentral
» ${prefix}bancoinvest
» ${prefix}bancoxp
» ${prefix}bolsaavancada
» ${prefix}loteria

━━━━━━━━━━━━━━━━━━
🚜 AGRICULTURA IMPERIAL
━━━━━━━━━━━━━━━━━━
» ${prefix}comprarterra
» ${prefix}latifundios
» ${prefix}plantar
» ${prefix}regar
» ${prefix}colher
» ${prefix}sementes
» ${prefix}clima
» ${prefix}ferramentas
» ${prefix}cozinha

━━━━━━━━━━━━━━━━━━
🐄 PECUÁRIA & PRODUÇÃO
━━━━━━━━━━━━━━━━━━
» ${prefix}fazendaanimais
» ${prefix}estabulo
» ${prefix}pets
» ${prefix}artesanato
» ${prefix}inventario
» ${prefix}usar

━━━━━━━━━━━━━━━━━━
🏹 EXPLORAÇÃO & RECURSOS
━━━━━━━━━━━━━━━━━━
» ${prefix}garimpo
» ${prefix}minerar
» ${prefix}madeira
» ${prefix}pesca
» ${prefix}caca
» ${prefix}viagem
» ${prefix}tesouro
» ${prefix}museu
» ${prefix}bestiario

━━━━━━━━━━━━━━━━━━
⚔️ RPG & SOCIEDADE
━━━━━━━━━━━━━━━━━━
» ${prefix}arena
» ${prefix}habilidades
» ${prefix}missoes
» ${prefix}casamento
» ${prefix}heranca
» ${prefix}troca
» ${prefix}evento
» ${prefix}igreja
» ${prefix}correio

━━━━━━━━━━━━━━━━━━
🏛️ POLÍTICA & GUILDAS
━━━━━━━━━━━━━━━━━━
» ${prefix}corporacao
» ${prefix}bguilda
» ${prefix}politica
» ${prefix}tribunal
» ${prefix}justica
» ${prefix}rotas

━━━━━━━━━━━━━━━━━━
🎰 CASSINO IMPERIAL
━━━━━━━━━━━━━━━━━━
» ${prefix}slots
» ${prefix}roleta
» ${prefix}crash
» ${prefix}corrida
» ${prefix}copos

━━━━━━━━━━━━━━━━━━
🛒 MERCADO & PROPRIEDADES
━━━━━━━━━━━━━━━━━━
» ${prefix}loja
» ${prefix}mercadonegro
» ${prefix}mercadominerio
» ${prefix}contrabando
» ${prefix}imoveis

━━━━━━━━━━━━━━━━━━
📦 DOWNLOADS & UTILIDADES
━━━━━━━━━━━━━━━━━━
» ${prefix}sticker
» ${prefix}rename
» ${prefix}pack
» ${prefix}tiktok
» ${prefix}instagram
» ${prefix}facebook
» ${prefix}yt-video
» ${prefix}yt-audio
» ${prefix}twitter
» ${prefix}threads
» ${prefix}kwai

━━━━━━━━━━━━━━━━━━
⏰ LEMBRETES IMPERIAIS
━━━━━━━━━━━━━━━━━━
» ${prefix}lembrar
» ${prefix}meuslembretes
» ${prefix}cancelarlembrete

━━━━━━━━━━━━━━━━━━
🛡️ ADMINISTRAÇÃO
━━━━━━━━━━━━━━━━━━
» ${prefix}ban
» ${prefix}antifake
» ${prefix}anti-bet
» ${prefix}chatia
» ${prefix}limpar
» ${prefix}ping

⚜️ Dom Pedro II - O Magnânimo ⚜️`;
}