import fs from "fs";
import path from "path";
import { PREFIX } from "../../config.js";

const dbPath = path.resolve("database", "anti-bet.json");

function getAntiBetGroups() {
  if (!fs.existsSync(dbPath)) return [];
  return JSON.parse(fs.readFileSync(dbPath, "utf-8"));
}

function saveAntiBetGroups(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default {
  name: "anti-bet",
  description: "Bane automaticamente quem enviar links de casas de apostas.",
  commands: ["antibet", "anti-aposta"],
  usage: `${PREFIX}antibet 1 (ligar) ou 0 (desligar)`,
  
  handle: async ({ args, sendReply, remoteJid, isGroup }) => {
    if (!isGroup) {
      return await sendReply("⚠️ Este comando só funciona em grupos.");
    }

    if (!args[0] || !["0", "1"].includes(args[0])) {
      return await sendReply(`⚠️ Uso incorreto. Exemplo: *${PREFIX}antibet 1*`);
    }

    const groups = getAntiBetGroups();
    const isEnabled = args[0] === "1";

    if (isEnabled) {
      if (!groups.includes(remoteJid)) {
        groups.push(remoteJid);
        saveAntiBetGroups(groups);
      }
      await sendReply("🛡️ *Anti-Bet Ativado!* Qualquer pessoa que enviar links de apostas (bet) será banida imediatamente sem aviso prévio.");
    } else {
      const index = groups.indexOf(remoteJid);
      if (index > -1) {
        groups.splice(index, 1);
        saveAntiBetGroups(groups);
      }
      await sendReply("🛑 *Anti-Bet Desativado.* A proteção contra links de apostas foi desligada.");
    }
  },
};
