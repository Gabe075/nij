import fs from "fs";
import path from "path";
import { PREFIX } from "../../config.js";
import { isGroup } from "../../utils/index.js";

const antifakePath = path.resolve("database", "antifake.json");

export default {
  name: "antifake",
  description: "Bloqueia a entrada de números de outros países.",
  commands: ["antifake", "bloquearddi"],
  usage: `${PREFIX}antifake +7`,
  
  handle: async ({ args, sendReply, remoteJid }) => {
    if (!isGroup(remoteJid)) {
      return await sendReply("⚠️ Este comando só pode ser usado em grupos.");
    }

    if (!args[0]) {
      return await sendReply(`⚠️ Digite o DDI que deseja bloquear ou desbloquear.\nExemplo: *${PREFIX}antifake +7*\nPara ver os bloqueados, digite: *${PREFIX}antifake lista*`);
    }

    // 🟢 CORREÇÃO: Se a pessoa digitar "lista"
    if (args[0].toLowerCase() === "lista") {
      let db = {};
      if (fs.existsSync(antifakePath)) db = JSON.parse(fs.readFileSync(antifakePath, "utf-8"));
      
      const lista = db[remoteJid] || [];
      if (lista.length === 0) return await sendReply("✅ Nenhum DDI está bloqueado neste grupo.");
      
      return await sendReply(`🚫 *DDIs Bloqueados:*\n\n+${lista.join("\n+")}`);
    }

    // Limpa o DDI (tira o + e espaços)
    const ddi = args[0].replace("+", "").trim();
    
    if (isNaN(ddi)) {
      return await sendReply("⚠️ O DDI deve conter apenas números. Exemplo: +7");
    }

    let db = {};
    if (fs.existsSync(antifakePath)) {
      db = JSON.parse(fs.readFileSync(antifakePath, "utf-8"));
    }
    if (!db[remoteJid]) db[remoteJid] = [];

    const index = db[remoteJid].indexOf(ddi);
    
    if (index > -1) {
      db[remoteJid].splice(index, 1);
      fs.writeFileSync(antifakePath, JSON.stringify(db, null, 2));
      return await sendReply(`✅ DDI *+${ddi}* removido da lista!\nNúmeros desse país podem entrar novamente.`);
    } else {
      db[remoteJid].push(ddi);
      fs.writeFileSync(antifakePath, JSON.stringify(db, null, 2));
      return await sendReply(`🚫 DDI *+${ddi}* bloqueado!\nQualquer número desse país será banido automaticamente ao entrar.`);
    }
  }
};
