import fs from "fs";
import path from "path";
import { PREFIX } from "../../config.js";

const dbPath = path.resolve("database", "ai-groups.json");

function getAIGroups() {
  if (!fs.existsSync(dbPath)) return [];
  return JSON.parse(fs.readFileSync(dbPath, "utf-8"));
}

function saveAIGroups(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export default {
  name: "chat-ia",
  description: "Liga ou desliga o chat por IA no grupo (Apenas Dono)",
  commands: ["chatia", "ia-grupo"],
  usage: `${PREFIX}chatia 1 (para ligar) ou 0 (para desligar)`,
  
  handle: async ({ args, sendReply, remoteJid, isGroup }) => {
    if (!isGroup) {
      return await sendReply("⚠️ Este comando só funciona em grupos.");
    }

    if (!args[0] || !["0", "1"].includes(args[0])) {
      return await sendReply(`⚠️ Uso incorreto. Exemplo: *${PREFIX}chatia 1*`);
    }

    const groups = getAIGroups();
    const isEnabled = args[0] === "1";

    if (isEnabled) {
      if (!groups.includes(remoteJid)) {
        groups.push(remoteJid);
        saveAIGroups(groups);
      }
      await sendReply("🤖 *IA Ativada!* A partir de agora eu vou conversar com vocês aqui no grupo.");
    } else {
      const index = groups.indexOf(remoteJid);
      if (index > -1) {
        groups.splice(index, 1);
        saveAIGroups(groups);
      }
      await sendReply("💤 *IA Desativada.* Fui dormir, galera. O chat automático está desligado neste grupo.");
    }
  },
};
