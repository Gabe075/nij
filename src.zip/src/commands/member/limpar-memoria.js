import fs from "fs";
import path from "path";
import { PREFIX } from "../../config.js";

const memoryPath = path.resolve("database", "memory.json");

export default {
  name: "limpar-memoria",
  description: "Apaga o seu histórico de conversa com o Gabirosvaldo neste grupo.",
  commands: ["limpar", "esquecer", "resetar"],
  usage: `${PREFIX}limpar`,
  
  handle: async ({ sendReply, remoteJid, userLid, sendSuccessReact }) => {
    // Verifica se o arquivo de memória existe
    if (!fs.existsSync(memoryPath)) {
      return await sendReply("🧠 Eu ainda não tenho nenhuma memória salva!");
    }

    // Lê o banco de dados
    const memoryDB = JSON.parse(fs.readFileSync(memoryPath, "utf-8"));
    
    // Cria a chave exata do usuário neste grupo
    const memoryKey = `${remoteJid}-${userLid}`;

    // Verifica se o usuário tem histórico
    if (memoryDB[memoryKey]) {
      // Apaga o histórico do usuário
      delete memoryDB[memoryKey];
      
      // Salva o arquivo atualizado no disco
      fs.writeFileSync(memoryPath, JSON.stringify(memoryDB, null, 2));
      
      await sendSuccessReact();
      await sendReply("🧹 Pronto! Esqueci tudo que conversamos. Vamos começar de novo?");
    } else {
      await sendReply("🤔 Eu não tenho nenhuma lembrança de termos conversado recentemente aqui.");
    }
  },
};
