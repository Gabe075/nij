import { delay } from "baileys";
import { PREFIX } from "../../../config.js";

export default {
  name: "pix",
  description: "Envia a sua chave PIX e contato para a galera rachar a conta.",
  commands: ["pix", "pagar", "tributo", "conta"],
  usage: `${PREFIX}pix`,
  
  handle: async ({ sendReply, sendReact, sendContact }) => {
    await sendReact("💸");

    // ==========================================
    // ⚙️ SUAS INFORMAÇÕES (Preencha aqui)
    // ==========================================
    const chavePix = "22997295147"; // Sua chave PIX
    const nomePix = "Gabriel Da Fonseca Duarte Sagrillo"; // Seu nome como aparece no banco
    const banco = "Nubank"; // Nome do seu banco
    const seuNumero = "+5522997295147"; // Seu número do WhatsApp
    // ==========================================

    const mensagem = `👑 *COBRANÇA IMPERIAL* 👑\n\n` +
                     `Chegou a hora de pagar os tributos!\n\n`
                     `🔑 *Chave PIX:* ${chavePix}\n` +
                     `👤 *Nome:* ${nomePix}\n` +
                     `🏦 *Banco:* ${banco}\n\n` +
                     `_(Copie a chave acima e faça a transferência)_`;

    // Envia a mensagem com os dados do PIX
    await sendReply(mensagem);

    // Espera 2 segundos para não mandar tudo atropelado
    await delay(2000);

    // Envia o seu contato logo em seguida
    await sendContact(seuNumero, "Gabe");
  },
};
