import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const remindersPath = path.resolve("database", "reminders.json");

export default {
  name: "cancelarlembrete",
  description: "Cancela um lembrete ativo.",
  commands: ["cancelarlembrete", "dellembrete"],
  usage: `${PREFIX}cancelarlembrete df01`,

  handle: async ({ args, sendReply, remoteJid, webMessage, prefix }) => {
    if (args.length === 0) {
      return await sendReply(`⚠️ Digite o ID do lembrete que deseja cancelar.\nExemplo: *${prefix}cancelarlembrete df01*`);
    }

    if (!fs.existsSync(remindersPath)) {
      return await sendReply("📭 Você não tem nenhum lembrete ativo.");
    }

    const targetId = args[0].toLowerCase();
    let reminders = JSON.parse(fs.readFileSync(remindersPath, "utf-8"));
    const participant = webMessage.key.participant || remoteJid;

    // Procura o lembrete que tenha o ID digitado E que pertença a você
    const index = reminders.findIndex(r => r.id === targetId && r.participant === participant);

    if (index === -1) {
      return await sendReply(`❌ Lembrete *${targetId}* não encontrado ou não pertence a você.\nUse *${prefix}meuslembretes* para ver seus IDs.`);
    }

    // Remove o lembrete da lista
    const removed = reminders.splice(index, 1)[0];
    
    // Salva o arquivo atualizado
    fs.writeFileSync(remindersPath, JSON.stringify(reminders, null, 2));

    await sendReply(`🗑️ Lembrete *${targetId}* ("${removed.message}") cancelado com sucesso!`);
  }
};
