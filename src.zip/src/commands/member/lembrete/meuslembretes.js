import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const remindersPath = path.resolve("database", "reminders.json");

export default {
  name: "meuslembretes",
  description: "Mostra a lista dos seus lembretes ativos.",
  commands: ["meuslembretes", "lembretes"],
  usage: `${PREFIX}meuslembretes`,

  handle: async ({ sendReply, remoteJid, webMessage, prefix }) => {
    if (!fs.existsSync(remindersPath)) {
      return await sendReply("📭 Você não tem nenhum lembrete ativo.");
    }

    const reminders = JSON.parse(fs.readFileSync(remindersPath, "utf-8"));
    const participant = webMessage.key.participant || remoteJid;

    // Filtra apenas os lembretes de quem enviou o comando
    const myReminders = reminders.filter(r => r.participant === participant);

    if (myReminders.length === 0) {
      return await sendReply("📭 Você não tem nenhum lembrete ativo.");
    }

    let msg = "📋 *SEUS LEMBRETES ATIVOS*\n\n";
    
    myReminders.forEach(rem => {
      const date = new Date(rem.targetTime);
      const timeStr = date.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });

      let tipoStr = "";
      if (rem.type === "df") tipoStr = "Normal";
      else if (rem.type === "dc") tipoStr = "Recorrente";
      else if (rem.type === "dr") tipoStr = "Diário";
      else if (rem.type === "ds") {
        const baseDate = new Date(rem.baseTime).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
        tipoStr = `Agendado (Evento real: ${baseDate})`;
      }

      msg += `🆔 *ID:* ${rem.id}\n`;
      msg += `📝 *Mensagem:* ${rem.message}\n`;
      msg += `🏷️ *Tipo:* ${tipoStr}\n`;
      msg += `⏰ *Próximo aviso:* ${timeStr}\n`;
      msg += `---------------------------\n`;
    });

    msg += `\nPara cancelar um lembrete, digite: *${prefix}cancelarlembrete ID*`;
    await sendReply(msg);
  }
};
