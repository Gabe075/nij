import { PREFIX } from "../../../config.js";

export default {
  name: "ajudalembrete",
  description: "Explica de forma fácil como usar os lembretes.",
  commands: ["ajudalembrete", "helplembrete"],
  usage: `${PREFIX}ajudalembrete`,
  
  handle: async ({ sendReply, prefix }) => {
    const mensagem = `⏰ *GUIA FÁCIL DE LEMBRETES* ⏰

O bot tem 4 tipos de lembretes. Veja como usar cada um:

🟢 *1. NORMAL (Toca 1 vez e some)*
Você pode usar de dois jeitos:
⏳ *Como Cronômetro:* Daqui a pouco tempo.
👉 *${prefix}lembrar 1h 30m Tirar a carne*

⌚ *Como Despertador:* Numa hora exata.
👉 *${prefix}lembrar 18:00 Academia*
_(Ambos recebem o ID "df" porque tocam uma vez e acabam)._

---

🔁 *2. RECORRENTE (Repete sem parar)*
Fica apitando de tempo em tempo.
👉 *${prefix}lembrar a cada 30m Beber água*
_(Recebe o ID "dc")._

---

📅 *3. DIÁRIO (Todo dia na mesma hora)*
Toca todo santo dia no horário marcado.
👉 *${prefix}lembrar diario 19:00 Tomar remédio*
_(Recebe o ID "dr")._

---

📆 *4. AGENDADO (Dia específico)*
Para reuniões e eventos. Ele te avisa às 6h da manhã, depois 30 min antes, e na hora exata!
👉 *${prefix}lembrar dia 28 15:30 Reunião*
_(Recebe o ID "ds")._

---

🛠️ *OUTROS COMANDOS ÚTEIS:*
*${prefix}meuslembretes* ➔ Mostra tudo que tá agendado.
*${prefix}cancelarlembrete df01* ➔ Apaga um lembrete.`;

    await sendReply(mensagem);
  }
};
