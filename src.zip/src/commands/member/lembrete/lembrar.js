import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const remindersPath = path.resolve("database", "reminders.json");

// Função para pegar a data/hora atual no Brasil
function getBrDate() {
  const str = new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" });
  return new Date(str);
}

export default {
  name: "lembrar",
  description: "Cria lembretes normais, recorrentes, diários ou agendados.",
  commands: ["lembrar", "lembrete"],
  usage: `${PREFIX}lembrar ...`,
  
  handle: async ({ fullArgs, sendReply, remoteJid, webMessage, prefix }) => {
    if (!fullArgs) {
      return await sendReply(`⚠️ *Tipos de Lembrete:*\n\n` +
        `*1. Normal (df):*\nEx: *${prefix}lembrar 1h 30m Tirar a carne*\nEx: *${prefix}lembrar 18:00 Academia*\n\n` +
        `*2. Recorrente (dc):*\nEx: *${prefix}lembrar a cada 30m Beber água*\n\n` +
        `*3. Diário (dr):*\nEx: *${prefix}lembrar diario 19:00 Tomar remédio*\n\n` +
        `*4. Agendado (ds):*\nEx: *${prefix}lembrar dia 28 15:30 Reunião*`);
    }

    let text = fullArgs.trim();
    let type = "df"; // Padrão
    let targetTime = 0;
    let baseTime = 0; // Usado para o 'ds'
    let intervalMs = 0; // Usado para o 'dc'
    let message = "";
    let timeLabel = "";

    const nowBr = getBrDate();

    // ---------------------------------------------------------
    // TIPO DC: Recorrente (ex: a cada 30m Beber água)
    // ---------------------------------------------------------
    const matchDc = text.match(/^(?:recorrente|a cada)\s+((?:\d+[smhd]\s*)+)(.+)$/i);
    // ---------------------------------------------------------
    // TIPO DR: Diário (ex: diario 19:00 Tomar remédio)
    // ---------------------------------------------------------
    const matchDr = text.match(/^(?:diario|diariamente|todo dia)\s+([01]?\d|2[0-3])[:h]([0-5]\d)?\s+(.+)$/i);
    // ---------------------------------------------------------
    // TIPO DS: Dia Específico (ex: dia 28 15:30 Reunião)
    // ---------------------------------------------------------
    const matchDs = text.match(/^dia\s+(\d{1,2})\s+([01]?\d|2[0-3])[:h]([0-5]\d)?\s+(.+)$/i);
    // ---------------------------------------------------------
    // TIPO DF: Exato (ex: 18:30 Academia)
    // ---------------------------------------------------------
    const matchDfExact = text.match(/^([01]?\d|2[0-3])[:h]([0-5]\d)?\s+(.+)$/i);
    // ---------------------------------------------------------
    // TIPO DF: Relativo (ex: 1h 30m Tirar a carne)
    // ---------------------------------------------------------
    const matchDfRel = text.match(/^((?:\d+[smhd]\s*)+)(.+)$/i);

    if (matchDc) {
      type = "dc";
      const timeTokens = matchDc[1].toLowerCase().match(/\d+[smhd]/g);
      message = matchDc[2].trim();
      for (const token of timeTokens) {
        const val = parseInt(token);
        const unit = token.slice(-1);
        if (unit === "s") intervalMs += val * 1000;
        if (unit === "m") intervalMs += val * 60 * 1000;
        if (unit === "h") intervalMs += val * 60 * 60 * 1000;
        if (unit === "d") intervalMs += val * 24 * 60 * 60 * 1000;
      }
      targetTime = Date.now() + intervalMs;
      timeLabel = `a cada ${matchDc[1].trim()}`;

    } else if (matchDr) {
      type = "dr";
      const h = parseInt(matchDr[1]);
      const m = parseInt(matchDr[2] || "0");
      message = matchDr[3].trim();

      const targetDate = new Date(nowBr);
      targetDate.setHours(h, m, 0, 0);
      if (targetDate.getTime() <= nowBr.getTime()) targetDate.setDate(targetDate.getDate() + 1);
      
      targetTime = Date.now() + (targetDate.getTime() - nowBr.getTime());
      timeLabel = `todos os dias às ${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}`;

    } else if (matchDs) {
      type = "ds";
      const day = parseInt(matchDs[1]);
      const h = parseInt(matchDs[2]);
      const m = parseInt(matchDs[3] || "0");
      message = matchDs[4].trim();

      const targetDate = new Date(nowBr);
      targetDate.setDate(day);
      targetDate.setHours(h, m, 0, 0);
      
      // Se o dia já passou neste mês, joga pro mês que vem
      if (targetDate.getTime() <= nowBr.getTime()) targetDate.setMonth(targetDate.getMonth() + 1);

      baseTime = Date.now() + (targetDate.getTime() - nowBr.getTime()); // A hora real do evento
      
      // Calcula as fases (6h da manhã, 30m antes, e na hora)
      const phase1 = new Date(targetDate); phase1.setHours(6, 0, 0, 0);
      const phase2 = new Date(targetDate.getTime() - (30 * 60 * 1000));
      const phase3 = targetDate;

      // Define qual é o próximo alarme a tocar
      if (nowBr.getTime() < phase1.getTime()) {
        targetTime = Date.now() + (phase1.getTime() - nowBr.getTime());
      } else if (nowBr.getTime() < phase2.getTime()) {
        targetTime = Date.now() + (phase2.getTime() - nowBr.getTime());
      } else {
        targetTime = Date.now() + (phase3.getTime() - nowBr.getTime());
      }
      
      timeLabel = `no dia ${day} às ${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')} (com avisos prévios)`;

    } else if (matchDfExact) {
      type = "df";
      const h = parseInt(matchDfExact[1]);
      const m = parseInt(matchDfExact[2] || "0");
      message = matchDfExact[3].trim();

      const targetDate = new Date(nowBr);
      targetDate.setHours(h, m, 0, 0);
      if (targetDate.getTime() <= nowBr.getTime()) targetDate.setDate(targetDate.getDate() + 1);
      
      targetTime = Date.now() + (targetDate.getTime() - nowBr.getTime());
      timeLabel = `às ${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}`;

    } else if (matchDfRel) {
      type = "df";
      const timeTokens = matchDfRel[1].toLowerCase().match(/\d+[smhd]/g);
      message = matchDfRel[2].trim();
      let totalMs = 0;
      for (const token of timeTokens) {
        const val = parseInt(token);
        const unit = token.slice(-1);
        if (unit === "s") totalMs += val * 1000;
        if (unit === "m") totalMs += val * 60 * 1000;
        if (unit === "h") totalMs += val * 60 * 60 * 1000;
        if (unit === "d") totalMs += val * 24 * 60 * 60 * 1000;
      }
      targetTime = Date.now() + totalMs;
      timeLabel = `daqui a ${matchDfRel[1].trim()}`;
    } else {
      return await sendReply("⚠️ Formato inválido! Digite `/lembrar` para ver os exemplos.");
    }

    let reminders = [];
    if (fs.existsSync(remindersPath)) reminders = JSON.parse(fs.readFileSync(remindersPath, "utf-8"));

    // Gera o ID com o prefixo correto (df, dc, dr, ds)
    let maxId = 0;
    for (const rem of reminders) {
      if (rem.id && rem.id.startsWith(type)) {
        const num = parseInt(rem.id.replace(type, ""));
        if (!isNaN(num) && num > maxId) maxId = num;
      }
    }
    const newId = `${type}${String(maxId + 1).padStart(2, '0')}`;

    const participant = webMessage.key.participant || remoteJid;

    reminders.push({
      id: newId,
      type,
      targetTime,
      baseTime,
      intervalMs,
      remoteJid,
      participant,
      message
    });

    fs.writeFileSync(remindersPath, JSON.stringify(reminders, null, 2));
    await sendReply(`⏰ Anotado! Vou te chamar no privado *${timeLabel}* para te lembrar de: "${message}".\n\n🆔 ID: *${newId}*`);
  }
};
