import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "troca",
    description: "Troque itens com outros jogadores de forma segura.",
    commands: ["trocar", "trade"],
    usage: `${PREFIX}trocar @user`,
    handle: async ({ sendReply }) => {
        return await sendReply("🤝 *SISTEMA DE TROCAS* 🤝\nEnvie uma proposta de troca para outro súdito!");
    }
};
