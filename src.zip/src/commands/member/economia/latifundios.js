import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const latifundiosPath = path.resolve("database", "latifundios.json");

const TIPOS_CULTURA = {
  "cafe": { nome: "Plantação de Café", custo: 5000, producaoBase: 200, tempoColheita: 6 }, // 6 horas
  "cana": { nome: "Plantação de Cana", custo: 3000, producaoBase: 100, tempoColheita: 4 }, // 4 horas
  "algodao": { nome: "Plantação de Algodão", custo: 8000, producaoBase: 350, tempoColheita: 8 } // 8 horas
};

export default {
  name: "latifundios",
  description: "Compre terras e cultive para gerar produtos e lucros.",
  commands: ["latifundios", "fazenda", "plantar"],
  usage: `${PREFIX}latifundios`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const culturaKey = parts[1]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    
    let latDB = {};
    if (fs.existsSync(latifundiosPath)) latDB = JSON.parse(fs.readFileSync(latifundiosPath, "utf-8"));
    if (!latDB[remoteJid]) latDB[remoteJid] = {};
    if (!latDB[remoteJid][participant]) latDB[remoteJid][participant] = { culturas: {} };

    if (!acao || acao === "lista") {
      let menu = `🚜 *LATIFÚNDIOS IMPERIAIS* 🚜\n\nCompre terras e plante culturas para colher produtos e vendê-los!\n\n`;
      for (const [key, cultura] of Object.entries(TIPOS_CULTURA)) {
        menu += `🌱 *${cultura.nome}*\n`;
        menu += `   ↳ Produção Base: ${cultura.producaoBase} unidades\n`;
        menu += `   ↳ Tempo de Colheita: ${cultura.tempoColheita} horas\n`;
        menu += `   ↳ Custo: 💰 ${cultura.custo} Réis\n`;
        menu += `🛒 Comando: *${PREFIX}latifundios plantar ${key}*\n\n`;
      }
      menu += `_Use *${PREFIX}latifundios minhas* para ver suas plantações e colher._`;
      return await sendReply(menu);
    }

    if (acao === "minhas") {
      const minhasCulturas = latDB[remoteJid][participant].culturas;
      if (Object.keys(minhasCulturas).length === 0) return await sendReply("Você não possui nenhuma plantação.");

      let msg = `🌱 *SUAS PLANTAÇÕES* 🌱\n\n`;
      const agora = Date.now();

      for (const [key, data] of Object.entries(minhasCulturas)) {
        const cultura = TIPOS_CULTURA[key];
        if (cultura) {
          const tempoRestante = (data.proximaColheita - agora);
          const status = tempoRestante <= 0 ? "Pronta para Colher!" : `Colheita em ${Math.ceil(tempoRestante / (1000 * 60 * 60))} horas`;
          
          msg += `🌿 *${cultura.nome}*\n`;
          msg += `   ↳ Status: ${status}\n`;
          msg += `   ↳ Última Colheita: ${new Date(data.ultimaColheita).toLocaleString()}\n\n`;
        }
      }
      msg += `_Use *${PREFIX}latifundios colher <tipo>* para colher sua produção._`;
      return await sendReply(msg);
    }

    if (acao === "plantar") {
      if (!TIPOS_CULTURA[culturaKey]) {
        return await sendWarningReply(`Tipo de cultura inválido! Digite *${PREFIX}latifundios* para ver a lista.`);
      }
      const cultura = TIPOS_CULTURA[culturaKey];

      if (db[remoteJid][participant].saldo < cultura.custo) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${cultura.custo} Réis* para plantar ${cultura.nome}.`);
      }

      db[remoteJid][participant].saldo -= cultura.custo;
      latDB[remoteJid][participant].culturas[culturaKey] = {
        ultimaColheita: Date.now(),
        proximaColheita: Date.now() + (cultura.tempoColheita * 60 * 60 * 1000)
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(latifundiosPath, JSON.stringify(latDB, null, 2));

      return await sendSuccessReply(`✅ *PLANTAÇÃO INICIADA!*\nVocê plantou *${cultura.nome}*! Volte em ${cultura.tempoColheita} horas para colher.`);
    }

    if (acao === "colher") {
      if (!TIPOS_CULTURA[culturaKey]) {
        return await sendWarningReply(`Tipo de cultura inválido! Digite *${PREFIX}latifundios* para ver a lista.`);
      }
      const cultura = TIPOS_CULTURA[culturaKey];
      const minhaCultura = latDB[remoteJid][participant].culturas[culturaKey];

      if (!minhaCultura) return await sendWarningReply(`Você não possui plantação de *${cultura.nome}* para colher.`);

      if (agora < minhaCultura.proximaColheita) {
        const tempoRestante = (minhaCultura.proximaColheita - agora);
        const horas = Math.ceil(tempoRestante / (1000 * 60 * 60));
        return await sendWarningReply(`A plantação de *${cultura.nome}* ainda não está pronta para colher. Volte em *${horas} horas*.`);
      }

      const producao = Math.floor(cultura.producaoBase * (1 + (Math.random() * 0.2 - 0.1))); // Variação de +/- 10%
      
      // Adiciona ao inventário do usuário (ou diretamente ao saldo, dependendo da sua preferência)
      if (!db[remoteJid][participant].inventario) db[remoteJid][participant].inventario = {};
      db[remoteJid][participant].inventario[culturaKey] = (db[remoteJid][participant].inventario[culturaKey] || 0) + producao;

      latDB[remoteJid][participant].culturas[culturaKey].ultimaColheita = agora;
      latDB[remoteJid][participant].culturas[culturaKey].proximaColheita = agora + (cultura.tempoColheita * 60 * 60 * 1000);

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(latifundiosPath, JSON.stringify(latDB, null, 2));

      return await sendSuccessReply(`✅ *COLHEITA REALIZADA!*\nVocê colheu *${producao} unidades* de *${cultura.nome}* e guardou no seu inventário!`);
    }
  }
};
