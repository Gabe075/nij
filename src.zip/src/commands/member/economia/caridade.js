import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "caridade",
    description: "Doe dinheiro para ajudar plebeus iniciantes.",
    commands: ["caridade", "doarplebeu"],
    usage: `${PREFIX}caridade <valor>`,
    handle: async ({ sendReply }) => {
        return await sendReply("🕊️ *SOPA DOS POBRES* 🕊️\nSua doação ajuda jogadores de nível baixo a começarem sua jornada!");
    }
};
