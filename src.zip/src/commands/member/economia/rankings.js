import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "rankings",
    description: "Rankings especializados (Mais ricos, Melhores Fazendeiros, etc).",
    commands: ["rankings", "top"],
    usage: `${PREFIX}rankings`,
    handle: async ({ sendReply }) => {
        return await sendReply("🏆 *HALL DA FAMA IMPERIAL* 🏆\n1. Top Riqueza\n2. Top Fazenda\n3. Top Arena\n4. Top Nobreza");
    }
};
