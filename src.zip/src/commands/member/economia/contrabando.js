import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const PRODUTOS = {
  "joias": { nome: "Joias Roubadas 💎", precoCompra: 1500, precoVenda: 3000, risco: 30 },
  "armas": { nome: "Armamento Ilegal 🔫", precoCompra: 5000, precoVenda: 12000, risco: 50 },
  "arte": { nome: "Obras de Arte Falsificadas 🖼️", precoCompra: 10000, precoVenda: 25000, risco: 70 },
  "reliquias": { nome: "Relíquias Imperiais 👑", precoCompra: 50000, precoVenda: 150000, risco: 90 }
};

export default {
  name: "contrabando",
  description: "Compre e venda itens ilegais com alto risco e alta recompensa.",
  commands: ["contrabando", "trafico"],
  usage: `${PREFIX}contrabando`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const item = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    if (!db[remoteJid][participant].contrabando) db[remoteJid][participant].contrabando = {};

    if (!acao || acao === "ajuda") {
      let menu = `🏴‍☠️ *MERCADO DE CONTRABANDO* 🏴‍☠️\n\n`;
      menu += `Compre barato e tente vender caro... se não for pego pela Guarda Imperial!\n\n`;
      
      for (const [key, prod] of Object.entries(PRODUTOS)) {
        menu += `📦 *${prod.nome}*\n`;
        menu += `   ↳ Compra: ${prod.precoCompra} Réis\n`;
        menu += `   ↳ Venda: ${prod.precoVenda} Réis\n`;
        menu += `   ↳ Risco de Prisão: ${prod.risco}%\n`;
        menu += `🛒 *${PREFIX}contrabando comprar ${key}*\n`;
        menu += `💰 *${PREFIX}contrabando vender ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}contrabando inventario* para ver seus itens ilegais._`;
      return await sendReply(menu);
    }

    if (acao === "inventario") {
      const inv = db[remoteJid][participant].contrabando;
      if (Object.keys(inv).length === 0) return await sendReply("📭 Você não possui itens contrabandeados.");
      
      let msg = `🎒 *SEU INVENTÁRIO ILEGAL* 🎒\n\n`;
      for (const [key, qtd] of Object.entries(inv)) {
        if (qtd > 0) msg += `📦 *${PRODUTOS[key].nome}:* ${qtd} unidades\n`;
      }
      return await sendReply(msg);
    }

    if (acao === "comprar") {
      if (!PRODUTOS[item]) return await sendWarningReply(`⚠️ Item inválido!`);
      const prod = PRODUTOS[item];
      
      if (db[remoteJid][participant].saldo < prod.precoCompra) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${prod.precoCompra} Réis*.`);
      }
      
      db[remoteJid][participant].saldo -= prod.precoCompra;
      db[remoteJid][participant].contrabando[item] = (db[remoteJid][participant].contrabando[item] || 0) + 1;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *COMPRA ILEGAL FEITA!*\nVocê comprou 1x *${prod.nome}* por ${prod.precoCompra} Réis.\nAgora tente vender sem ser pego!`);
    }

    if (acao === "vender") {
      if (!PRODUTOS[item]) return await sendWarningReply(`⚠️ Item inválido!`);
      const prod = PRODUTOS[item];
      
      if (!db[remoteJid][participant].contrabando[item] || db[remoteJid][participant].contrabando[item] < 1) {
        return await sendWarningReply(`⚠️ Você não tem este item para vender.`);
      }
      
      // Tenta vender
      const chance = Math.floor(Math.random() * 100);
      
      // Pego pela polícia
      if (chance < prod.risco) {
        db[remoteJid][participant].contrabando[item] -= 1;
        const multa = Math.floor(prod.precoCompra * 1.5);
        db[remoteJid][participant].saldo = Math.max(0, db[remoteJid][participant].saldo - multa);
        
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendWarningReply(`🚨 *VOCÊ FOI PEGO PELA GUARDA IMPERIAL!* 🚨\n\nO item *${prod.nome}* foi confiscado e você pagou uma multa de *${multa} Réis*!`);
      }
      
      // Venda com sucesso
      db[remoteJid][participant].contrabando[item] -= 1;
      db[remoteJid][participant].saldo += prod.precoVenda;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`💰 *VENDA BEM SUCEDIDA!*\n\nVocê conseguiu despistar a guarda e vendeu *${prod.nome}* por incríveis *${prod.precoVenda} Réis*!`);
    }
  }
};
