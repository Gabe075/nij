import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "igreja",
  description: "Doe Réis para a Igreja Imperial e receba a benção divina (XP e Sorte).",
  commands: ["igreja", "doarigreja", "dizimo"],
  usage: `${PREFIX}igreja <valor>`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const valorStr = fullArgs ? fullArgs.trim().split(/\s+/)[0] : "";
    
    if (!valorStr || isNaN(valorStr) || parseInt(valorStr, 10) <= 0) {
      return await sendReply(`⛪ *IGREJA IMPERIAL* ⛪\n\nFaça uma doação para a Igreja e receba a benção divina!\nDeus recompensa os generosos com XP e sorte.\n\nComando: *${PREFIX}igreja <valor>*`);
    }
    
    const valor = parseInt(valorStr, 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    
    if (db[remoteJid][participant].saldo < valor) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
    }
    
    // Desconta a doação
    db[remoteJid][participant].saldo -= valor;
    
    // Recompensa divina
    const xpGanho = Math.floor(valor * 0.1); // 10% do valor doado vira XP
    db[remoteJid][participant].xp = (db[remoteJid][participant].xp || 0) + xpGanho;
    
    // Chance de Milagre (Retorno financeiro multiplicado)
    const milagre = Math.floor(Math.random() * 100);
    let msgMilagre = "";
    
    if (milagre < 5) { // 5% de chance de um milagre
      const recompensa = valor * 3;
      db[remoteJid][participant].saldo += recompensa;
      msgMilagre = `\n\n✨ *UM MILAGRE ACONTECEU!* ✨\nOs céus sorriram para você! Você encontrou *${recompensa} Réis* logo após sair da Igreja!`;
    }
    
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    
    return await sendSuccessReply(`⛪ *DOAÇÃO RECEBIDA!*\n\nA Igreja agradece sua generosidade de *${valor} Réis*.\nVocê foi abençoado com *+${xpGanho} XP*!${msgMilagre}`);
  }
};
