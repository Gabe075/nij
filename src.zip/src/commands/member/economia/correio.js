import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "correio",
    description: "Envie mensagens e presentes para outros jogadores.",
    commands: ["correio", "enviarpresente"],
    usage: `${PREFIX}correio @user`,
    handle: async ({ sendReply }) => {
        return await sendReply("📬 *CORREIO IMPERIAL* 📬\nEnvie cartas e mimos para seus amigos!");
    }
};
