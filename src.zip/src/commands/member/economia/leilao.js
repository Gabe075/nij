import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const leilaoPath = path.resolve("database", "leilao.json");

export default {
  name: "leilao",
  description: "Participe de leilões para comprar e vender itens raros.",
  commands: ["leilao", "bid", "arrematar"],
  usage: `${PREFIX}leilao`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const idLeilao = parts[1];
    const valorLance = parseInt(parts[2], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let leilaoDB = {};
    if (fs.existsSync(leilaoPath)) leilaoDB = JSON.parse(fs.readFileSync(leilaoPath, "utf-8"));
    if (!leilaoDB[remoteJid]) leilaoDB[remoteJid] = { ativos: {} };

    // Limpeza de leilões expirados
    const agora = Date.now();
    for (const id in leilaoDB[remoteJid].ativos) {
      if (leilaoDB[remoteJid].ativos[id].expira < agora) {
        const leilaoExpirado = leilaoDB[remoteJid].ativos[id];
        if (leilaoExpirado.maiorLance && leilaoExpirado.maiorLance.valor > 0) {
          // Venda bem-sucedida
          db[remoteJid][leilaoExpirado.vendedor].saldo += leilaoExpirado.maiorLance.valor;
          // Notificar comprador e vendedor
          await sendReply(`🎉 *LEILÃO ENCERRADO!* 🎉\n\nO item *${leilaoExpirado.item}* foi arrematado por *${leilaoExpirado.maiorLance.valor} Réis* por @${leilaoExpirado.maiorLance.participante.split("@")[0]}!\nO vendedor @${leilaoExpirado.vendedor.split("@")[0]} recebeu o valor.`, [leilaoExpirado.maiorLance.participante, leilaoExpirado.vendedor]);
        } else {
          // Leilão sem lances ou não vendido
          await sendReply(`💔 *LEILÃO ENCERRADO!* 💔\n\nO item *${leilaoExpirado.item}* não recebeu lances ou não atingiu o valor mínimo e foi devolvido ao vendedor @${leilaoExpirado.vendedor.split("@")[0]}.`, [leilaoExpirado.vendedor]);
        }
        delete leilaoDB[remoteJid].ativos[id];
      }
    }
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    fs.writeFileSync(leilaoPath, JSON.stringify(leilaoDB, null, 2));

    if (!acao || acao === "ajuda") {
      let menu = `🏛️ *CASA DE LEILÕES IMPERIAL* 🏛️\n\n`;
      menu += `Compre e venda itens raros no mercado de leilões!\n\n`;
      menu += `🔸 *${PREFIX}leilao criar <item> <lance_inicial> <tempo_em_minutos>* - Inicia um leilão\n`;
      menu += `🔸 *${PREFIX}leilao listar* - Veja os leilões ativos\n`;
      menu += `🔸 *${PREFIX}leilao lance <ID_LEILAO> <valor>* - Faça um lance em um leilão\n`;
      menu += `🔸 *${PREFIX}leilao meus* - Veja seus leilões ativos\n`;
      return await sendReply(menu);
    }

    if (acao === "listar") {
      const ativos = Object.values(leilaoDB[remoteJid].ativos);
      if (ativos.length === 0) return await sendReply("Nenhum leilão ativo no momento.");

      let msg = `📜 *LEILÕES ATIVOS* 📜\n\n`;
      ativos.forEach(l => {
        const tempoRestante = Math.ceil((l.expira - agora) / (60 * 1000));
        msg += `🆔 *ID:* ${l.id}\n`;
        msg += `   ↳ Item: ${l.item}\n`;
        msg += `   ↳ Vendedor: @${l.vendedor.split("@")[0]}\n`;
        msg += `   ↳ Lance Atual: ${l.maiorLance ? l.maiorLance.valor : l.lanceInicial} Réis\n`;
        msg += `   ↳ Tempo Restante: ${tempoRestante} minutos\n\n`;
      });
      return await sendReply(msg, ativos.map(l => l.vendedor).concat(ativos.map(l => l.maiorLance?.participante || [])));
    }

    if (acao === "criar") {
      const item = parts[1];
      const lanceInicial = parseInt(parts[2], 10);
      const tempoMinutos = parseInt(parts[3], 10);

      if (!item || isNaN(lanceInicial) || lanceInicial <= 0 || isNaN(tempoMinutos) || tempoMinutos <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}leilao criar EspadaLendaria 1000 60* (60 minutos)`);
      }
      if (db[remoteJid][participant].saldo < lanceInicial) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${lanceInicial} Réis* para iniciar o leilão (valor mínimo de lance).`);
      }

      const id = `leilao_${Date.now()}`;
      leilaoDB[remoteJid].ativos[id] = {
        id: id,
        item: item,
        vendedor: participant,
        lanceInicial: lanceInicial,
        maiorLance: null,
        expira: agora + (tempoMinutos * 60 * 1000)
      };
      fs.writeFileSync(leilaoPath, JSON.stringify(leilaoDB, null, 2));
      return await sendSuccessReply(`✅ *LEILÃO CRIADO!*\n\nSeu item *${item}* está em leilão com lance inicial de *${lanceInicial} Réis* por ${tempoMinutos} minutos!`);
    }

    if (acao === "lance") {
      if (!idLeilao || isNaN(valorLance) || valorLance <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}leilao lance ${Object.keys(leilaoDB[remoteJid].ativos)[0] || 'ID_LEILAO'} 1500*`);
      }
      const leilao = leilaoDB[remoteJid].ativos[idLeilao];
      if (!leilao) return await sendWarningReply("⚠️ Leilão não encontrado.");
      if (leilao.vendedor === participant) return await sendWarningReply("⚠️ Você não pode dar lance no seu próprio leilão.");
      if (leilao.expira < agora) return await sendWarningReply("⚠️ Este leilão já expirou.");

      const lanceMinimo = leilao.maiorLance ? leilao.maiorLance.valor + 1 : leilao.lanceInicial;
      if (valorLance < lanceMinimo) {
        return await sendWarningReply(`⚠️ Seu lance deve ser maior que o lance atual (*${lanceMinimo} Réis*).`);
      }
      if (db[remoteJid][participant].saldo < valorLance) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${valorLance} Réis* na carteira para fazer este lance.`);
      }

      // Devolve o dinheiro do lance anterior ao participante
      if (leilao.maiorLance) {
        db[remoteJid][leilao.maiorLance.participante].saldo += leilao.maiorLance.valor;
        await sendReply(`↩️ *LANCE SUPERADO!*\n\nSeu lance de *${leilao.maiorLance.valor} Réis* no item *${leilao.item}* foi superado por @${participant.split("@")[0]}. O valor foi devolvido à sua carteira.`, [leilao.maiorLance.participante]);
      }

      db[remoteJid][participant].saldo -= valorLance;
      leilao.maiorLance = { participante: participant, valor: valorLance };
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(leilaoPath, JSON.stringify(leilaoDB, null, 2));
      return await sendSuccessReply(`💰 *LANCE REGISTRADO!*\n\nVocê deu um lance de *${valorLance} Réis* no item *${leilao.item}*!`);
    }
  }
};
