import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const corporacoesPath = path.resolve("database", "corporacoes.json");

// Tabela de Níveis da Corporação baseada no Cofre
function getLevelCorporacao(cofre) {
  if (cofre >= 500000) return { level: 5, bonus: 25 };
  if (cofre >= 200000) return { level: 4, bonus: 20 };
  if (cofre >= 75000) return { level: 3, bonus: 15 };
  if (cofre >= 30000) return { level: 2, bonus: 10 };
  return { level: 1, bonus: 5 };
}

export default {
  name: "corporacao",
  description: "Gerencie sua Corporação Imperial.",
  commands: ["corporacao", "empresa", "guilda", "familia"],
  usage: `${PREFIX}corporacao info`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let corpDB = {};
    if (fs.existsSync(corporacoesPath)) corpDB = JSON.parse(fs.readFileSync(corporacoesPath, "utf-8"));
    if (!corpDB[remoteJid]) corpDB[remoteJid] = {};

    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const minhaCorporacaoId = db[remoteJid][participant].corporacao;

    // 📜 MENU DE AJUDA
    if (!acao || acao === "ajuda") {
      let menu = `🏢 *CORPORAÇÕES IMPERIAIS* 🏢\n\n`;
      menu += `Transforme sua família em uma poderosa corporação!\n\n`;
      menu += `🔸 *${PREFIX}corporacao criar <Nome>* - Custa 20.000 Réis\n`;
      menu += `🔸 *${PREFIX}corporacao info* - Ver status da sua corporação\n`;
      menu += `🔸 *${PREFIX}corporacao doar <valor>* - Ajudar no cofre\n`;
      menu += `🔸 *${PREFIX}corporacao niveis* - Ver tabela de evolução\n`;
      menu += `🔸 *${PREFIX}corporacao recrutar @user* - (Apenas CEO)\n`;
      menu += `🔸 *${PREFIX}corporacao expulsar @user* - (Apenas CEO)\n`;
      menu += `🔸 *${PREFIX}corporacao sair* - Abandonar a corporação\n`;
      return await sendReply(menu);
    }

    // 📊 TABELA DE NÍVEIS DA CORPORAÇÃO
    if (acao === "niveis" || acao === "tabela") {
      let msg = `📈 *EVOLUÇÃO DA CORPORAÇÃO* 📈\n\n`;
      msg += `Doe Réis para o cofre da corporação para subir de nível e aumentar o bônus de salário de *todos* os membros!\n\n`;
      
      msg += `🌟 *Nível 1:* 0 Réis no cofre\n`;
      msg += `   ↳ Bônus: +5% no salário\n\n`;
      
      msg += `🌟 *Nível 2:* 30.000 Réis no cofre\n`;
      msg += `   ↳ Bônus: +10% no salário\n\n`;
      
      msg += `🌟 *Nível 3:* 75.000 Réis no cofre\n`;
      msg += `   ↳ Bônus: +15% no salário\n\n`;
      
      msg += `🌟 *Nível 4:* 200.000 Réis no cofre\n`;
      msg += `   ↳ Bônus: +20% no salário\n\n`;
      
      msg += `🌟 *Nível 5 (Máximo):* 500.000 Réis no cofre\n`;
      msg += `   ↳ Bônus: +25% no salário\n`;
      
      return await sendReply(msg);
    }

    // 🏰 CRIAR CORPORAÇÃO
    if (acao === "criar") {
      if (minhaCorporacaoId) return await sendWarningReply("⚠️ Você já pertence a uma corporação! Saia dela primeiro.");
      
      const nomeCorporacao = parts.slice(1).join(" ");
      if (!nomeCorporacao) return await sendWarningReply(`⚠️ Digite o nome da corporação.\nExemplo: *${PREFIX}corporacao criar Umbrella Corp*`);
      
      const idCorporacao = nomeCorporacao.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (corpDB[remoteJid][idCorporacao]) return await sendWarningReply("⚠️ Já existe uma corporação com esse nome neste grupo!");
      
      const custoCriacao = 20000;
      if (db[remoteJid][participant].saldo < custoCriacao) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${custoCriacao} Réis* na carteira para fundar uma corporação.`);
      }

      // Desconta e cria
      db[remoteJid][participant].saldo -= custoCriacao;
      db[remoteJid][participant].corporacao = idCorporacao;
      
      corpDB[remoteJid][idCorporacao] = {
        nome: nomeCorporacao,
        ceo: participant,
        membros: [participant],
        cofre: 0
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(corporacoesPath, JSON.stringify(corpDB, null, 2));

      return await sendSuccessReply(`🏢 *CORPORAÇÃO FUNDADA!*\n\nA corporação *${nomeCorporacao}* foi criada com sucesso!\nUse *${PREFIX}corporacao recrutar @usuario* para chamar aliados.`);
    }

    // ℹ️ INFO DA CORPORAÇÃO
    if (acao === "info") {
      if (!minhaCorporacaoId || !corpDB[remoteJid][minhaCorporacaoId]) {
        return await sendWarningReply("⚠️ Você não pertence a nenhuma corporação.");
      }

      const corp = corpDB[remoteJid][minhaCorporacaoId];
      const status = getLevelCorporacao(corp.cofre);
      
      let msg = `🏢 *CORPORAÇÃO: ${corp.nome}* 🏢\n\n`;
      msg += `👑 *CEO:* @${corp.ceo.split("@")[0]}\n`;
      msg += `🌟 *Nível da Corporação:* ${status.level}\n`;
      msg += `💰 *Cofre:* ${corp.cofre} Réis\n`;
      msg += `📈 *Bônus de Salário:* +${status.bonus}%\n\n`;
      msg += `👥 *Membros (${corp.membros.length}):*\n`;
      
      corp.membros.forEach(m => {
        msg += ` ↳ @${m.split("@")[0]}\n`;
      });

      return await sendReply(msg, corp.membros);
    }

    // ➕ RECRUTAR MEMBRO
    if (acao === "recrutar" || acao === "adicionar") {
      if (!minhaCorporacaoId) return await sendWarningReply("⚠️ Você não tem uma corporação.");
      const corp = corpDB[remoteJid][minhaCorporacaoId];
      if (corp.ceo !== participant) return await sendWarningReply("⚠️ Apenas o CEO pode recrutar membros.");
      if (mentionedJidList.length === 0) return await sendWarningReply("⚠️ Marque o usuário que deseja recrutar.");
      
      const alvo = mentionedJidList[0];
      if (!db[remoteJid][alvo]) db[remoteJid][alvo] = { saldo: 0 };
      if (db[remoteJid][alvo].corporacao) return await sendWarningReply("⚠️ Este usuário já pertence a uma corporação.");

      db[remoteJid][alvo].corporacao = minhaCorporacaoId;
      corp.membros.push(alvo);

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(corporacoesPath, JSON.stringify(corpDB, null, 2));

      return await sendSuccessReply(`🤝 *NOVO MEMBRO!*\n\n@${alvo.split("@")[0]} agora faz parte da corporação *${corp.nome}*!`, [alvo]);
    }

    // 🥾 EXPULSAR MEMBRO
    if (acao === "expulsar") {
      if (!minhaCorporacaoId) return await sendWarningReply("⚠️ Você não tem uma corporação.");
      const corp = corpDB[remoteJid][minhaCorporacaoId];
      if (corp.ceo !== participant) return await sendWarningReply("⚠️ Apenas o CEO pode expulsar membros.");
      if (mentionedJidList.length === 0) return await sendWarningReply("⚠️ Marque o usuário que deseja expulsar.");
      
      const alvo = mentionedJidList[0];
      if (alvo === participant) return await sendWarningReply("⚠️ Você não pode expulsar a si mesmo. Use o comando sair.");
      if (!corp.membros.includes(alvo)) return await sendWarningReply("⚠️ Este usuário não faz parte da sua corporação.");

      // Remove da corporação
      corp.membros = corp.membros.filter(m => m !== alvo);
      if (db[remoteJid][alvo]) db[remoteJid][alvo].corporacao = null;

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(corporacoesPath, JSON.stringify(corpDB, null, 2));

      return await sendSuccessReply(`🥾 *MEMBRO EXPULSO!*\n\n@${alvo.split("@")[0]} foi expulso da corporação *${corp.nome}* pelo CEO.`, [alvo]);
    }

    // 💸 DOAR PARA O COFRE
    if (acao === "doar") {
      if (!minhaCorporacaoId) return await sendWarningReply("⚠️ Você não tem uma corporação para doar.");
      
      const valorStr = parts.find(arg => /^\d+$/.test(arg));
      if (!valorStr) return await sendWarningReply(`⚠️ Digite um valor válido.\nExemplo: *${PREFIX}corporacao doar 500*`);
      
      const valor = parseInt(valorStr, 10);
      if (valor <= 0) return await sendWarningReply("⚠️ O valor deve ser maior que zero.");
      if (db[remoteJid][participant].saldo < valor) return await sendWarningReply(`⚠️ Você só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);

      const corp = corpDB[remoteJid][minhaCorporacaoId];
      const levelAntes = getLevelCorporacao(corp.cofre).level;

      db[remoteJid][participant].saldo -= valor;
      corp.cofre += valor;

      const levelDepois = getLevelCorporacao(corp.cofre).level;
      let avisoUpar = "";
      if (levelDepois > levelAntes) {
        avisoUpar = `\n\n🎉 *A CORPORAÇÃO SUBIU DE NÍVEL!* 🎉\nAgora todos os membros ganham +${getLevelCorporacao(corp.cofre).bonus}% de bônus no salário!`;
      }

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(corporacoesPath, JSON.stringify(corpDB, null, 2));

      return await sendSuccessReply(`💰 *DOAÇÃO RECEBIDA!*\nVocê doou *${valor} Réis* para o cofre da corporação *${corp.nome}*.${avisoUpar}`);
    }

    // 🚪 SAIR DA CORPORAÇÃO
    if (acao === "sair") {
      if (!minhaCorporacaoId) return await sendWarningReply("⚠️ Você não está em nenhuma corporação.");
      const corp = corpDB[remoteJid][minhaCorporacaoId];

      if (corp.ceo === participant) {
        return await sendWarningReply("⚠️ Você é o CEO! Para sair, você precisa passar a liderança ou a corporação será desfeita (recurso em breve).");
      }

      corp.membros = corp.membros.filter(m => m !== participant);
      db[remoteJid][participant].corporacao = null;

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(corporacoesPath, JSON.stringify(corpDB, null, 2));

      return await sendSuccessReply("🚪 Você saiu da corporação.");
    }
  }
};
