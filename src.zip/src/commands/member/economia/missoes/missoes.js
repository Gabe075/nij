import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const missoesPath = path.resolve("database", "missoes.json");

// Lista de missões possíveis com foco em realismo e estratégia
const TODAS_MISSOES = {
  "trabalhar": { desc: "Cumpra seu expediente de trabalho", meta: 1, recompensa: 100, xp: 50, tipo: "diaria" },
  "depositar": { desc: "Deposite Réis no Banco Imperial", meta: 1, recompensa: 150, xp: 75, tipo: "diaria" },
  "doar_corporacao": { desc: "Faça uma doação para o cofre da sua Corporação", meta: 1, recompensa: 200, xp: 100, tipo: "diaria" },
  "coletar_imoveis": { desc: "Recolha os lucros das suas propriedades", meta: 1, recompensa: 120, xp: 60, tipo: "diaria" },
  "comprar_loja": { desc: "Adquira um item na Loja Imperial", meta: 1, recompensa: 80, xp: 40, tipo: "diaria" },
  "vender_acoes": { desc: "Venda ações na Bolsa de Valores", meta: 1, recompensa: 250, xp: 120, tipo: "diaria" },
  "pagar_divida": { desc: "Quite uma dívida com o Agiota", meta: 1, recompensa: 300, xp: 150, tipo: "diaria" },
  "processar_ladrao": { desc: "Inicie um processo no Tribunal de Justiça", meta: 1, recompensa: 400, xp: 200, tipo: "diaria" },
  "candidatar_politica": { desc: "Candidate-se a um cargo político", meta: 1, recompensa: 500, xp: 250, tipo: "diaria" },
  "comprar_fabrica": { desc: "Adquira uma Fábrica para produção", meta: 1, recompensa: 1000, xp: 500, tipo: "diaria" },
  "vender_producao": { desc: "Venda produtos da sua Fábrica", meta: 1, recompensa: 300, xp: 150, tipo: "diaria" },
  "enviar_rota": { desc: "Envie uma Rota Comercial", meta: 1, recompensa: 700, xp: 350, tipo: "diaria" },
  "pagar_imposto": { desc: "Pague seu Imposto de Renda", meta: 1, recompensa: 200, xp: 100, tipo: "diaria" },
  "ter_filho": { desc: "Tenha um filho no casamento", meta: 1, recompensa: 600, xp: 300, tipo: "diaria" },
  "adotar_mascote": { desc: "Adote um mascote imperial", meta: 1, recompensa: 200, xp: 100, tipo: "diaria" }
};

// Função para adicionar progresso a uma missão
export function addProgressoMissao(remoteJid, participant, missaoId) {
  let missoesDB = {};
  if (fs.existsSync(missoesPath)) missoesDB = JSON.parse(fs.readFileSync(missoesPath, "utf-8"));
  if (!missoesDB[remoteJid]) missoesDB[remoteJid] = {};
  if (!missoesDB[remoteJid][participant]) missoesDB[remoteJid][participant] = { missoesAtivas: [], ultimaAtualizacao: 0 };

  const userMissoes = missoesDB[remoteJid][participant];
  const agora = Date.now();
  const umDia = 24 * 60 * 60 * 1000;

  // Reseta missões se for um novo dia
  if (agora - userMissoes.ultimaAtualizacao > umDia) {
    userMissoes.missoesAtivas = [];
    userMissoes.ultimaAtualizacao = agora;
  }

  // Adiciona a missão se não existir
  if (userMissoes.missoesAtivas.length === 0) {
    // Seleciona 3 missões aleatórias
    const missoesDisponiveis = Object.keys(TODAS_MISSOES);
    for (let i = 0; i < 3; i++) {
      const randomId = missoesDisponiveis[Math.floor(Math.random() * missoesDisponiveis.length)];
      userMissoes.missoesAtivas.push({
        id: randomId,
        progresso: 0,
        completa: false
      });
    }
  }

  // Atualiza o progresso da missão específica
  const missaoIndex = userMissoes.missoesAtivas.findIndex(m => m.id === missaoId && !m.completa);
  if (missaoIndex !== -1) {
    userMissoes.missoesAtivas[missaoIndex].progresso++;
    if (userMissoes.missoesAtivas[missaoIndex].progresso >= TODAS_MISSOES[missaoId].meta) {
      userMissoes.missoesAtivas[missaoIndex].completa = true;
    }
  }

  fs.writeFileSync(missoesPath, JSON.stringify(missoesDB, null, 2));
}

export default {
  name: "missoes",
  description: "Veja e gerencie suas Missões de Estado diárias.",
  commands: ["missoes", "tarefas", "objetivos"],
  usage: `${PREFIX}missoes`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let missoesDB = {};
    if (fs.existsSync(missoesPath)) missoesDB = JSON.parse(fs.readFileSync(missoesPath, "utf-8"));
    if (!missoesDB[remoteJid]) missoesDB[remoteJid] = {};
    if (!missoesDB[remoteJid][participant]) missoesDB[remoteJid][participant] = { missoesAtivas: [], ultimaAtualizacao: 0 };

    const userMissoes = missoesDB[remoteJid][participant];
    const agora = Date.now();
    const umDia = 24 * 60 * 60 * 1000;

    // Reseta missões se for um novo dia ou se não tiver missões ativas
    if (agora - userMissoes.ultimaAtualizacao > umDia || userMissoes.missoesAtivas.length === 0) {
      userMissoes.missoesAtivas = [];
      userMissoes.ultimaAtualizacao = agora;
      // Seleciona 3 missões aleatórias
      const missoesDisponiveis = Object.keys(TODAS_MISSOES);
      for (let i = 0; i < 3; i++) {
        const randomId = missoesDisponiveis[Math.floor(Math.random() * missoesDisponiveis.length)];
        userMissoes.missoesAtivas.push({
          id: randomId,
          progresso: 0,
          completa: false
        });
      }
      fs.writeFileSync(missoesPath, JSON.stringify(missoesDB, null, 2));
    }

    // Menu principal
    if (!acao || acao === "ajuda") {
      let msg = `📜 *QUADRO DE MISSÕES DE ESTADO* 📜\n\n`;
      if (userMissoes.missoesAtivas.length === 0) {
        msg += `_Nenhuma missão ativa no momento. Volte mais tarde!_`;
      } else {
        userMissoes.missoesAtivas.forEach((missao, index) => {
          const detalhes = TODAS_MISSOES[missao.id];
          const status = missao.completa ? "✅ COMPLETA" : `[${missao.progresso}/${detalhes.meta}]`;
          msg += `*${index + 1}.* ${detalhes.desc}\n`;
          msg += `   ↳ Recompensa: ${detalhes.recompensa} Réis | ${detalhes.xp} XP\n`;
          msg += `   ↳ Status: ${status}\n\n`;
        });
        msg += `_Use *${PREFIX}missoes resgatar <número_missao>* para coletar suas recompensas._`;
      }
      return await sendReply(msg);
    }

    // Resgatar recompensa
    if (acao === "resgatar") {
      const numMissao = parseInt(parts[1], 10);
      if (isNaN(numMissao) || numMissao < 1 || numMissao > userMissoes.missoesAtivas.length) {
        return await sendWarningReply("⚠️ Número da missão inválido.");
      }

      const missao = userMissoes.missoesAtivas[numMissao - 1];
      if (!missao.completa) {
        return await sendWarningReply("⚠️ Esta missão ainda não foi completada.");
      }

      const detalhes = TODAS_MISSOES[missao.id];

      // Adiciona recompensa
      db[remoteJid][participant].saldo += detalhes.recompensa;
      db[remoteJid][participant].xp = (db[remoteJid][participant].xp || 0) + detalhes.xp;

      // Remove a missão completada e adiciona uma nova
      userMissoes.missoesAtivas.splice(numMissao - 1, 1);
      const missoesDisponiveis = Object.keys(TODAS_MISSOES);
      const randomId = missoesDisponiveis[Math.floor(Math.random() * missoesDisponiveis.length)];
      userMissoes.missoesAtivas.push({
        id: randomId,
        progresso: 0,
        completa: false
      });

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(missoesPath, JSON.stringify(missoesDB, null, 2));

      return await sendSuccessReply(`✅ *RECOMPENSA RESGATADA!*\nVocê ganhou *${detalhes.recompensa} Réis* e *${detalhes.xp} XP* pela missão "${detalhes.desc}"!`);
    }
  }
};
