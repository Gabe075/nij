import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "tesouro",
  description: "Participe de uma caça ao tesouro e encontre riquezas escondidas.",
  commands: ["tesouro", "cacatesouro", "mapa"],
  usage: `${PREFIX}tesouro`,
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    
    const agora = Date.now();
    const tempoEspera = 60 * 60 * 1000; // 1 hora
    
    if (db[remoteJid][participant].ultimoTesouro) {
      const tempoPassado = agora - db[remoteJid][participant].ultimoTesouro;
      if (tempoPassado < tempoEspera) {
        const minutosRestantes = Math.ceil((tempoEspera - tempoPassado) / 60000);
        return await sendReply(`⏳ *O mapa ainda está sendo decifrado!* Volte em *${minutosRestantes} minutos* para sua próxima caça.`);
      }
    }
    
    const custoMapa = 200; // Custa 200 réis para comprar um mapa
    if (db[remoteJid][participant].saldo < custoMapa) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoMapa} Réis* para comprar um mapa do tesouro.`);
    }
    
    db[remoteJid][participant].saldo -= custoMapa;
    db[remoteJid][participant].ultimoTesouro = agora;
    
    const sorte = Math.floor(Math.random() * 100);
    let ganho = 0;
    let msg = "";
    
    if (sorte < 30) { // 30% de chance de não achar nada
      msg = `🗺️ Você seguiu o mapa, mas só encontrou um baú vazio. Que azar! Você perdeu os *${custoMapa} Réis* do mapa.`;
    } else if (sorte < 60) { // 30% de chance de achar moedas de ouro
      ganho = Math.floor(Math.random() * 500) + 250;
      msg = `🗺️ Você encontrou um pequeno baú com *${ganho} Réis* em moedas de ouro!`;
    } else if (sorte < 85) { // 25% de chance de achar joias
      ganho = Math.floor(Math.random() * 1500) + 750;
      msg = `🗺️ Que sorte! Você desenterrou um baú cheio de *Joias Antigas* valendo *${ganho} Réis*!`;
    } else if (sorte < 95) { // 10% de chance de achar artefatos
      ganho = Math.floor(Math.random() * 4000) + 2000;
      msg = `🗺️ INCRÍVEL! Você achou um *Artefato Imperial Raro*! Ele foi vendido por *${ganho} Réis*.`;
    } else { // 5% de chance de achar um tesouro lendário
      ganho = Math.floor(Math.random() * 10000) + 5000;
      msg = `👑 *TESOURO LENDÁRIO ENCONTRADO!* 👑\nVocê descobriu o lendário *Tesouro do Imperador*! Ele vale incríveis *${ganho} Réis*!`;
    }
    
    db[remoteJid][participant].saldo += ganho;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    
    if (ganho > 0) {
      return await sendSuccessReply(msg);
    } else {
      return await sendReply(msg);
    }
  }
};
