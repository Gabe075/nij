import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const tribunalPath = path.resolve("database", "tribunal.json");

export default {
  name: "tribunal",
  description: "Processe ladrões e receba indenizações.",
  commands: ["tribunal", "processar", "justica"],
  usage: `${PREFIX}tribunal`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const alvoJid = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let tribDB = {};
    if (fs.existsSync(tribunalPath)) tribDB = JSON.parse(fs.readFileSync(tribunalPath, "utf-8"));
    if (!tribDB[remoteJid]) tribDB[remoteJid] = {};

    // Menu principal
    if (!acao || acao === "ajuda") {
      let menu = `⚖️ *TRIBUNAL DE JUSTIÇA IMPERIAL* ⚖️\n\n`;
      menu += `Defenda seus bens e processe quem te roubou!\n\n`;
      menu += `🔸 *${PREFIX}tribunal processar @ladrão* - Inicia um processo contra um ladrão (Custa 500 Réis)\n`;
      menu += `🔸 *${PREFIX}tribunal meusprocessos* - Veja seus processos em andamento\n`;
      menu += `🔸 *${PREFIX}tribunal pagarindenizacao <ID_PROCESSO>* - Pague uma indenização para encerrar um processo\n`;
      menu += `_Para processar, você precisa ter sido roubado e ter um Informante no seu inventário._`;
      return await sendReply(menu);
    }

    // Processar alguém
    if (acao === "processar") {
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque o ladrão que você deseja processar.\nExemplo: *${PREFIX}tribunal processar @ladrão*`);
      if (alvoJid === participant) return await sendWarningReply("⚠️ Você não pode processar a si mesmo.");

      // Verifica se o informante está no inventário
      const informante = db[remoteJid][participant].inventario?.informante || 0;
      if (informante < 1) return await sendWarningReply("⚠️ Você precisa de um *Informante* no seu inventário para iniciar um processo.");

      // Custo do processo
      const custoProcesso = 500;
      if (db[remoteJid][participant].saldo < custoProcesso) return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoProcesso} Réis* para pagar as custas do processo.`);

      // Verifica se já existe um processo contra o alvo
      const processosAtivos = Object.values(tribDB[remoteJid]).filter(p => p.acusador === participant && p.reu === alvoJid && p.status === "pendente");
      if (processosAtivos.length > 0) return await sendWarningReply("⚠️ Você já tem um processo pendente contra este usuário.");

      // Desconta o informante e o dinheiro
      db[remoteJid][participant].inventario.informante -= 1;
      db[remoteJid][participant].saldo -= custoProcesso;

      const idProcesso = `proc_${Date.now()}`;
      tribDB[remoteJid][idProcesso] = {
        id: idProcesso,
        acusador: participant,
        reu: alvoJid,
        data: Date.now(),
        status: "pendente",
        indenizacao: Math.floor(Math.random() * (2000 - 500) + 500) // Indenização aleatória entre 500 e 2000 Réis
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(tribunalPath, JSON.stringify(tribDB, null, 2));

      return await sendSuccessReply(`✅ *PROCESSO INICIADO!*\nVocê processou @${alvoJid.split("@")[0]}! O Tribunal analisará o caso e ele será notificado.`, [alvoJid]);
    }

    // Meus processos
    if (acao === "meusprocessos") {
      const meusProcessos = Object.values(tribDB[remoteJid]).filter(p => (p.acusador === participant || p.reu === participant) && p.status === "pendente");
      if (meusProcessos.length === 0) return await sendReply("Você não possui processos em andamento.");

      let msg = `📜 *SEUS PROCESSOS EM ANDAMENTO* 📜\n\n`;
      meusProcessos.forEach(p => {
        const tipo = p.acusador === participant ? "(Acusador)" : "(Réu)";
        const outro = p.acusador === participant ? p.reu : p.acusador;
        msg += `🆔 *ID:* ${p.id}\n`;
        msg += `   ↳ Tipo: ${tipo}\n`;
        msg += `   ↳ Parte Contrária: @${outro.split("@")[0]}\n`;
        msg += `   ↳ Indenização: ${p.indenizacao} Réis\n`;
        msg += `   ↳ Status: ${p.status}\n\n`;
      });
      return await sendReply(msg, meusProcessos.map(p => p.acusador === participant ? p.reu : p.acusador));
    }

    // Pagar indenização
    if (acao === "pagarindenizacao") {
      const idProcesso = parts[1];
      if (!idProcesso) return await sendWarningReply(`⚠️ Digite o ID do processo que deseja pagar.\nExemplo: *${PREFIX}tribunal pagarindenizacao proc_12345*`);

      const processo = tribDB[remoteJid][idProcesso];
      if (!processo || processo.reu !== participant || processo.status !== "pendente") {
        return await sendWarningReply("⚠️ Processo não encontrado ou você não é o réu/ele já foi encerrado.");
      }

      if (db[remoteJid][participant].saldo < processo.indenizacao) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${processo.indenizacao} Réis* para pagar esta indenização.`);
      }

      // Realiza o pagamento
      db[remoteJid][participant].saldo -= processo.indenizacao;
      db[remoteJid][processo.acusador].saldo += processo.indenizacao;
      processo.status = "pago";

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(tribunalPath, JSON.stringify(tribDB, null, 2));

      return await sendSuccessReply(`✅ *INDENIZAÇÃO PAGA!*\nVocê pagou *${processo.indenizacao} Réis* a @${processo.acusador.split("@")[0]} e o processo *${idProcesso}* foi encerrado.`, [processo.acusador]);
    }
  }
};
