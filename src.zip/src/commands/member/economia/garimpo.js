import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "garimpo",
  description: "Tente a sorte garimpando pedras preciosas.",
  commands: ["garimpo", "garimpar", "minerar"],
  usage: `${PREFIX}garimpo`,
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    
    const agora = Date.now();
    const tempoEspera = 15 * 60 * 1000; // 15 minutos
    
    if (db[remoteJid][participant].ultimoGarimpo) {
      const tempoPassado = agora - db[remoteJid][participant].ultimoGarimpo;
      if (tempoPassado < tempoEspera) {
        const minutosRestantes = Math.ceil((tempoEspera - tempoPassado) / 60000);
        return await sendReply(`⛏️ *Sua picareta quebrou!* Aguarde *${minutosRestantes} minutos* antes de garimpar novamente.`);
      }
    }
    
    const custoGarimpo = 100; // Custa 100 réis para entrar no garimpo
    if (db[remoteJid][participant].saldo < custoGarimpo) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoGarimpo} Réis* para comprar os equipamentos de garimpo.`);
    }
    
    db[remoteJid][participant].saldo -= custoGarimpo;
    db[remoteJid][participant].ultimoGarimpo = agora;
    
    const sorte = Math.floor(Math.random() * 100);
    let ganho = 0;
    let msg = "";
    
    if (sorte < 40) { // 40% de chance de não achar nada
      msg = `⛏️ Você cavou por horas e só encontrou terra e pedras comuns. Você perdeu os *${custoGarimpo} Réis* do equipamento.`;
    } else if (sorte < 70) { // 30% de chance de achar pepitas de ouro
      ganho = Math.floor(Math.random() * 300) + 150;
      msg = `⛏️ Você encontrou algumas *Pepitas de Ouro*! Elas foram vendidas por *${ganho} Réis*.`;
    } else if (sorte < 90) { // 20% de chance de achar esmeraldas
      ganho = Math.floor(Math.random() * 800) + 400;
      msg = `⛏️ UAU! Você encontrou uma *Esmeralda Bruta*! Foi vendida por *${ganho} Réis*.`;
    } else if (sorte < 98) { // 8% de chance de achar rubis
      ganho = Math.floor(Math.random() * 2000) + 1000;
      msg = `⛏️ INCRÍVEL! Você encontrou um *Rubi Imperial*! O joalheiro pagou *${ganho} Réis* por ele.`;
    } else { // 2% de chance de achar um diamante perfeito
      ganho = Math.floor(Math.random() * 5000) + 5000;
      msg = `💎 *A SORTE GRANDE!* 💎\nVocê encontrou o lendário *Diamante Estrela do Sul*! Ele foi vendido por incríveis *${ganho} Réis*!`;
    }
    
    db[remoteJid][participant].saldo += ganho;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    
    if (ganho > 0) {
      return await sendSuccessReply(msg);
    } else {
      return await sendReply(msg);
    }
  }
};
