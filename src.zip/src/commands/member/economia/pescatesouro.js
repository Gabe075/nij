import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "pescatesouro",
    description: "Tente pescar baús de tesouro em vez de peixes.",
    commands: ["pescatesouro", "baus"],
    usage: `${PREFIX}pescatesouro`,
    handle: async ({ sendReply }) => {
        return await sendReply("🏴‍☠️ *CAÇA AO TESOURO SUBMARINO* 🏴‍☠️\nEncontre relíquias perdidas no fundo do mar!");
    }
};
