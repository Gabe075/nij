import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "bancoxp",
    description: "Converta XP em benefícios ou vice-versa.",
    commands: ["bancoxp", "trocarxp"],
    usage: `${PREFIX}bancoxp`,
    handle: async ({ sendReply }) => {
        return await sendReply("✨ *ALTAR DE XP* ✨\nSacrifique seu XP para obter bênçãos temporárias!");
    }
};
