import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "loteriafederal",
    description: "Participe da Loteria do Império com prêmios acumulados.",
    commands: ["loteriafederal", "bilhete"],
    usage: `${PREFIX}loteriafederal`,
    handle: async ({ sendReply }) => {
        return await sendReply("🎫 *LOTERIA FEDERAL DO BRAZIL* 🎫\nPrêmio Acumulado: *5.000.000 Réis*!\nSorteio todos os domingos.");
    }
};
