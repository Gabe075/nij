import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "sementes",
    description: "Armazene e gerencie suas sementes de forma eficiente.",
    commands: ["sementes", "meu_estoque"],
    usage: `${PREFIX}sementes`,
    handle: async ({ sendReply }) => {
        return await sendReply("📦 *SILO IMPERIAL* 📦\nGerencie suas sementes e fertilizantes.");
    }
};
