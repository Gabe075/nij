import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "minigames",
  description: "Jogue minigames para ganhar Réis e se divertir.",
  commands: ["minigames", "jogos"],
  usage: `${PREFIX}minigames`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const aposta = parseInt(parts[1], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (!acao || acao === "ajuda") {
      let menu = `🎲 *MINIGAMES IMPERIAIS* 🎲\n\n`;
      menu += `Divirta-se e teste sua sorte em nossos jogos!\n\n`;
      menu += `🔸 *${PREFIX}minigames caraoucoroa <aposta>* - Jogue cara ou coroa\n`;
      menu += `🔸 *${PREFIX}minigames dado <aposta>* - Jogue o dado (1-6)\n`;
      return await sendReply(menu);
    }

    if (isNaN(aposta) || aposta <= 0) {
      return await sendWarningReply(`⚠️ Você precisa apostar um valor válido.\nExemplo: *${PREFIX}minigames caraoucoroa 100*`);
    }
    if (db[remoteJid][participant].saldo < aposta) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
    }

    if (acao === "caraoucoroa") {
      const escolha = parts[2]?.toLowerCase();
      if (!escolha || (escolha !== "cara" && escolha !== "coroa")) {
        return await sendWarningReply(`⚠️ Escolha 'cara' ou 'coroa'.\nExemplo: *${PREFIX}minigames caraoucoroa 100 cara*`);
      }

      const resultado = Math.random() < 0.5 ? "cara" : "coroa";
      let msg = `🪙 *CARA OU COROA* 🪙\nVocê apostou *${aposta} Réis* na opção *${escolha.toUpperCase()}*.\n\n`;

      if (escolha === resultado) {
        db[remoteJid][participant].saldo += aposta;
        msg += `🎉 *PARABÉNS!* A moeda caiu em *${resultado.toUpperCase()}*! Você ganhou *${aposta} Réis*!`;
      } else {
        db[remoteJid][participant].saldo -= aposta;
        msg += `💔 *QUE PENA!* A moeda caiu em *${resultado.toUpperCase()}*! Você perdeu *${aposta} Réis*!`;
      }
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendReply(msg);
    }

    if (acao === "dado") {
      const numeroApostado = parseInt(parts[2], 10);
      if (isNaN(numeroApostado) || numeroApostado < 1 || numeroApostado > 6) {
        return await sendWarningReply(`⚠️ Escolha um número entre 1 e 6.\nExemplo: *${PREFIX}minigames dado 100 3*`);
      }

      const resultado = Math.floor(Math.random() * 6) + 1;
      let msg = `🎲 *JOGO DO DADO* 🎲\nVocê apostou *${aposta} Réis* no número *${numeroApostado}*.\n\n`;

      if (numeroApostado === resultado) {
        const ganho = aposta * 5; // Ganha 5x a aposta se acertar
        db[remoteJid][participant].saldo += ganho;
        msg += `🎉 *PARABÉNS!* O dado caiu em *${resultado}*! Você ganhou *${ganho} Réis*!`;
      } else {
        db[remoteJid][participant].saldo -= aposta;
        msg += `💔 *QUE PENA!* O dado caiu em *${resultado}*! Você perdeu *${aposta} Réis*!`;
      }
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendReply(msg);
    }
  }
};
