import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "roubar",
  description: "Tenta roubar Réis de outro membro. Cuidado com a Guarda Imperial!",
  commands: ["roubar", "assaltar", "crime"],
  usage: `${PREFIX}roubar @usuario`,
  
  handle: async ({ sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) {
      return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");
    }

    const senderJid = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (mentionedJidList.length === 0) {
      return await sendWarningReply(`⚠️ Você precisa marcar a sua vítima.\nExemplo: *${PREFIX}roubar @usuario*`);
    }
    
    const receiverJid = mentionedJidList[0];

    if (senderJid === receiverJid) {
      return await sendWarningReply("⚠️ Você não pode roubar a si mesmo! Tá ficando louco?");
    }

    let db = {};
    if (fs.existsSync(ecoPath)) {
      db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    }

    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][senderJid]) db[remoteJid][senderJid] = { saldo: 0 };
    if (!db[remoteJid][receiverJid]) db[remoteJid][receiverJid] = { saldo: 0 };

    const agora = Date.now();
    const tempoEspera = 60 * 60 * 1000; 
    
    if (db[remoteJid][senderJid].ultimoRoubo) {
      const tempoPassado = agora - db[remoteJid][senderJid].ultimoRoubo;
      if (tempoPassado < tempoEspera) {
        const minutosRestantes = Math.ceil((tempoEspera - tempoPassado) / 60000);
        return await sendWarningReply(`🚓 *A Guarda Imperial está patrulhando!*\nEsconda-se por mais *${minutosRestantes} minutos* antes de tentar outro assalto.`);
      }
    }

    const senderBalance = db[remoteJid][senderJid].saldo;
    const receiverBalance = db[remoteJid][receiverJid].saldo;

    if (senderBalance < 50) {
      return await sendWarningReply("⚠️ Você precisa de pelo menos *50 Réis* para planejar um assalto. Vá trabalhar!");
    }

    if (receiverBalance < 50) {
      return await sendWarningReply("⚠️ Essa pessoa é muito pobre. Tenha piedade e procure um alvo mais rico!");
    }

    if (db[remoteJid][receiverJid].escudo && agora < db[remoteJid][receiverJid].escudo) {
      if (db[remoteJid][senderJid].inventario && db[remoteJid][senderJid].inventario.fumaca > 0) {
        db[remoteJid][senderJid].inventario.fumaca -= 1;
        db[remoteJid][receiverJid].escudo = 0; 
        await sendReply(`🧨 *BOMBA DE FUMAÇA!*\nVocê jogou uma bomba de fumaça e destruiu o Escudo Imperial de @${receiverJid.split("@")[0]}! O assalto vai prosseguir...`, [receiverJid]);
      } else {
        db[remoteJid][senderJid].ultimoRoubo = agora;
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendWarningReply(`🛡️ *ASSALTO BLOQUEADO!*\nA vítima está protegida por um *Escudo Imperial*! O ataque falhou e você teve que recuar. Compre uma Bomba de Fumaça no Mercado Negro para quebrar escudos.`);
      }
    }

    db[remoteJid][senderJid].ultimoRoubo = agora;

    const petAtacante = db[remoteJid][senderJid].pet;
    const petVitima = db[remoteJid][receiverJid].pet;

    let chanceSucesso = 40; 
    if (petAtacante === "macaco") chanceSucesso += 15; 
    if (petVitima === "cao") chanceSucesso -= 20; 

    const chance = Math.random() * 100;
    const isSuccess = chance <= chanceSucesso;

    const senderNum = senderJid.split("@")[0];
    const receiverNum = receiverJid.split("@")[0];

    if (isSuccess) {
      const percentual = (Math.floor(Math.random() * 21) + 10) / 100;
      const valorRoubado = Math.floor(receiverBalance * percentual);

      db[remoteJid][senderJid].saldo += valorRoubado;
      db[remoteJid][receiverJid].saldo -= valorRoubado;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      let avisoPet = petAtacante === "macaco" ? "\n🐒 _Seu Macaco Ladrão ajudou no assalto!_" : "";

      await sendReply(`🥷 *ASSALTO BEM SUCEDIDO!* 🥷\n\n@${senderNum} conseguiu roubar *${valorRoubado} Réis* de @${receiverNum} e fugiu pelas sombras!${avisoPet}\n\n🏦 Seu saldo atual: *${db[remoteJid][senderJid].saldo} Réis*`, [senderJid, receiverJid]);
    } else {
      const percentualMulta = (Math.floor(Math.random() * 21) + 15) / 100;
      const valorMulta = Math.floor(senderBalance * percentualMulta);

      db[remoteJid][senderJid].saldo -= valorMulta;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      let avisoPet = petVitima === "cao" ? "\n🐕 _O Cão de Guarda da vítima alertou a Guarda Imperial!_" : "";

      await sendReply(`🚓 *VOCÊ FOI PRESO!* 🚓\n\nO assalto deu errado! @${receiverNum} chamou a Guarda Imperial.${avisoPet}\nVocê foi pego e pagou uma fiança de *${valorMulta} Réis* para ser solto.\n\n🏦 Seu saldo atual: *${db[remoteJid][senderJid].saldo} Réis*`, [senderJid, receiverJid]);
    }

    // 🟢 ATUALIZA A MISSÃO (Independentemente se deu certo ou errado)
    addProgressoMissao(remoteJid, senderJid, "roubar");
  }
};
