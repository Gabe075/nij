import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "depositar",
  description: "Guarda seus Réis no Banco Imperial.",
  commands: ["depositar", "guardar", "deposito"],
  usage: `${PREFIX}depositar <valor> ou tudo`,
  
  handle: async ({ args, sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    if (!args.length) {
      return await sendWarningReply(`⚠️ Digite o valor que deseja depositar.\nExemplo: *${PREFIX}depositar 500* ou *${PREFIX}depositar tudo*`);
    }

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };

    const carteira = db[remoteJid][participant].saldo || 0;

    if (carteira <= 0) {
      return await sendWarningReply("⚠️ Sua carteira está vazia! Vá trabalhar para ganhar Réis.");
    }

    let valor = 0;
    if (args[0].toLowerCase() === "tudo" || args[0].toLowerCase() === "all") {
      valor = carteira;
    } else {
      valor = parseInt(args[0].replace(/[^0-9]/g, ""), 10);
    }

    if (isNaN(valor) || valor <= 0) {
      return await sendWarningReply("⚠️ Digite um valor válido para depositar.");
    }

    if (valor > carteira) {
      return await sendWarningReply(`⚠️ Você só tem *${carteira} Réis* na carteira.`);
    }

    db[remoteJid][participant].saldo -= valor;
    db[remoteJid][participant].banco = (db[remoteJid][participant].banco || 0) + valor;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, participant, "depositar");

    await sendReply(`🏦 *DEPÓSITO REALIZADO!*\n\nVocê guardou *${valor} Réis* no cofre.\n\n💰 Carteira: *${db[remoteJid][participant].saldo}*\n🏛️ Banco: *${db[remoteJid][participant].banco}*`);
  }
};
