import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "pagar",
  description: "Transfere Réis para outro membro do grupo.",
  commands: ["pagar", "transferir", "pix", "enviar"],
  usage: `${PREFIX}pagar @usuario <valor>`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) {
      return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");
    }

    const senderJid = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (mentionedJidList.length === 0) {
      return await sendWarningReply(`⚠️ Você precisa marcar quem vai receber o dinheiro.\nExemplo: *${PREFIX}pagar @usuario 50*`);
    }
    
    const receiverJid = mentionedJidList[0];

    if (senderJid === receiverJid) {
      return await sendWarningReply("⚠️ Você não pode transferir dinheiro para si mesmo!");
    }

    const parts = fullArgs.split(" ");
    let amountStr = parts.find(part => /^\d+$/.test(part));

    if (!amountStr) {
      return await sendWarningReply(`⚠️ Digite um valor válido para transferir.\nExemplo: *${PREFIX}pagar @usuario 50*`);
    }

    const amount = parseInt(amountStr, 10);

    if (amount <= 0) {
      return await sendWarningReply("⚠️ O valor da transferência deve ser maior que zero.");
    }

    let db = {};
    if (fs.existsSync(ecoPath)) {
      db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    }

    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][senderJid]) db[remoteJid][senderJid] = { saldo: 0 };
    if (!db[remoteJid][receiverJid]) db[remoteJid][receiverJid] = { saldo: 0 };

    if (db[remoteJid][senderJid].saldo < amount) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][senderJid].saldo} Réis* na carteira.`);
    }

    db[remoteJid][senderJid].saldo -= amount;
    db[remoteJid][receiverJid].saldo += amount;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, senderJid, "transferir");

    const senderNum = senderJid.split("@")[0];
    const receiverNum = receiverJid.split("@")[0];

    await sendReply(`💸 *TRANSFERÊNCIA REALIZADA!* 💸\n\n@${senderNum} enviou *${amount} Réis* para @${receiverNum}!\n\n🏦 Seu saldo atual: *${db[remoteJid][senderJid].saldo} Réis*`, [senderJid, receiverJid]);
  }
};
