import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "espionar",
  description: "Usa um informante para ver o saldo de alguém.",
  commands: ["espionar", "investigar"],
  usage: `${PREFIX}espionar @usuario`,
  
  handle: async ({ sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return;

    const senderJid = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (mentionedJidList.length === 0) return await sendWarningReply(`⚠️ Marque o alvo.\nExemplo: *${PREFIX}espionar @usuario*`);
    const receiverJid = mentionedJidList[0];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid] || !db[remoteJid][senderJid] || !db[remoteJid][senderJid].inventario?.informante) {
      return await sendWarningReply(`⚠️ Você não tem um *🕵️ Contrato de Informante*. Compre no *${PREFIX}mercadonegro*.`);
    }

    // Consome o item
    db[remoteJid][senderJid].inventario.informante -= 1;
    
    const alvoSaldo = db[remoteJid][receiverJid]?.saldo || 0;
    const alvoBanco = db[remoteJid][receiverJid]?.banco || 0;
    const alvoEscudo = db[remoteJid][receiverJid]?.escudo > Date.now() ? "✅ Sim" : "❌ Não";

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, senderJid, "espionar");

    await sendReply(`🕵️ *RELATÓRIO DO INFORMANTE* 🕵️\n\nAlvo: @${receiverJid.split("@")[0]}\n\n👛 Carteira: *${alvoSaldo} Réis*\n🏛️ Banco: *${alvoBanco} Réis*\n🛡️ Escudo Ativo: *${alvoEscudo}*\n\n_O informante foi pago e sumiu no mapa._`, [receiverJid]);
  }
};
