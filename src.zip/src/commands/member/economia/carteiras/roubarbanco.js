import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "roubarbanco",
  description: "Usa um Pé de Cabra para roubar o banco de alguém.",
  commands: ["roubarbanco", "assaltarbanco"],
  usage: `${PREFIX}roubarbanco @usuario`,
  
  handle: async ({ sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return;

    const senderJid = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    if (mentionedJidList.length === 0) return await sendWarningReply(`⚠️ Marque a vítima.\nExemplo: *${PREFIX}roubarbanco @usuario*`);
    const receiverJid = mentionedJidList[0];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid] || !db[remoteJid][senderJid] || !db[remoteJid][senderJid].inventario?.pedecabra) {
      return await sendWarningReply(`⚠️ Você precisa de um *🪝 Pé de Cabra* para arrombar um cofre. Compre no *${PREFIX}mercadonegro*.`);
    }

    const receiverBanco = db[remoteJid][receiverJid]?.banco || 0;
    
    // 🟢 NOVO LIMITE: Só pode roubar quem tem mais de 10.000 no banco
    if (receiverBanco < 10000) {
      return await sendWarningReply("⚠️ O cofre dessa pessoa tem menos de 10.000 Réis. O Sindicato do Crime diz que não vale a pena gastar um Pé de Cabra com isso.");
    }

    // Consome o item
    db[remoteJid][senderJid].inventario.pedecabra -= 1;

    // 35% de chance de sucesso
    const isSuccess = Math.random() * 100 <= 35;

    if (isSuccess) {
      // 🟢 NOVO SAQUE: Rouba entre 30% e 60% do banco da vítima
      const percentual = (Math.floor(Math.random() * 31) + 30) / 100;
      const roubado = Math.floor(receiverBanco * percentual); 
      
      db[remoteJid][senderJid].saldo += roubado;
      db[remoteJid][receiverJid].banco -= roubado;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      await sendReply(`🪝 *O ROUBO DO SÉCULO!* 🪝\n\nVocê arrombou o cofre de @${receiverJid.split("@")[0]} e levou *${roubado} Réis* direto para sua carteira!`, [receiverJid]);
    } else {
      // 🟢 NOVA MULTA: 5000 fixo + 10% da carteira
      const multa = 5000 + Math.floor(db[remoteJid][senderJid].saldo * 0.10); 
      db[remoteJid][senderJid].saldo -= multa;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      await sendReply(`🚨 *ALERTA MÁXIMO!* 🚨\n\nO alarme do banco tocou! Você foi pego pela Tropa de Choque Imperial tentando arrombar o cofre de @${receiverJid.split("@")[0]}.\nVocê pagou *${multa} Réis* de fiança e seu Pé de Cabra foi confiscado!`, [receiverJid]);
    }
  }
};
