import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");

export default {
  name: "agiota",
  description: "Pegue dinheiro emprestado (com juros altos).",
  commands: ["agiota", "emprestimo"],
  usage: `${PREFIX}agiota`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const args = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = args[0]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let level = 1;
    if (fs.existsSync(levelsPath)) {
      const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      if (levelsDB[remoteJid] && levelsDB[remoteJid][participant]) {
        level = levelsDB[remoteJid][participant].level;
      }
    }

    const limiteCredito = level * 1500;
    const agora = Date.now();

    // 🔄 ATUALIZAÇÃO PREGUIÇOSA (Juros de Atraso)
    if (db[remoteJid][participant].emprestimo) {
      let emp = db[remoteJid][participant].emprestimo;
      while (agora > emp.prazo) {
        // Adiciona 10% de multa por cada 24h de atraso
        const multa = Math.floor(emp.divida * 0.10);
        emp.divida += multa;
        emp.prazo += (24 * 60 * 60 * 1000); // Joga o prazo pra frente
      }
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    }

    // 📜 MENU E INFO
    if (!acao || acao === "info") {
      if (!db[remoteJid][participant].emprestimo) {
        let menu = `🕴️ *O AGIOTA* 🕴️\n\n`;
        menu += `_"Precisando de grana rápida? Eu resolvo. Mas não me dê calote."_\n\n`;
        menu += `💳 *Seu Limite de Crédito:* ${limiteCredito} Réis\n`;
        menu += `📈 *Taxa de Juros:* 20% (Prazo de 24h)\n\n`;
        menu += `🔸 *${PREFIX}agiota pegar <valor>* - Solicita um empréstimo\n`;
        menu += `🔸 *${PREFIX}agiota pagar <valor>* - Quita sua dívida\n`;
        menu += `🔸 *${PREFIX}agiota info* - Vê o status da sua dívida\n`;
        return await sendReply(menu);
      }

      const emp = db[remoteJid][participant].emprestimo;
      const horasRestantes = Math.max(0, (emp.prazo - agora) / (1000 * 60 * 60));
      
      let msg = `🕴️ *CONTRATO DO AGIOTA* 🕴️\n\n`;
      msg += `💰 *Valor Devido:* ${emp.divida} Réis\n`;
      msg += `⏳ *Tempo Restante:* ${horasRestantes.toFixed(1)} horas\n\n`;
      msg += `_Use *${PREFIX}agiota pagar <valor>* ou *${PREFIX}agiota pagar tudo* para limpar seu nome._\n`;
      msg += `⚠️ _Aviso: Atrasos geram multa de 10% ao dia!_`;
      
      return await sendReply(msg);
    }

    // 💸 PEGAR EMPRÉSTIMO
    if (acao === "pegar") {
      if (db[remoteJid][participant].emprestimo) {
        return await sendWarningReply("⚠️ Você já tem uma dívida ativa! Pague o que deve antes de pedir mais.");
      }

      const valorStr = args[1];
      if (!valorStr) return await sendWarningReply(`⚠️ Digite o valor que deseja pegar.\nExemplo: *${PREFIX}agiota pegar 1000*`);

      const valor = parseInt(valorStr.replace(/[^0-9]/g, ""), 10);
      if (isNaN(valor) || valor <= 0) return await sendWarningReply("⚠️ Digite um valor válido.");

      if (valor > limiteCredito) {
        return await sendWarningReply(`🛑 *Crédito Negado!*\nO Agiota não confia tanto em você. Seu limite atual é de *${limiteCredito} Réis* (Baseado no seu Nível ${level}).`);
      }

      const divida = Math.floor(valor * 1.20); // 20% de juros
      const prazo = agora + (24 * 60 * 60 * 1000); // 24 horas

      db[remoteJid][participant].saldo += valor;
      db[remoteJid][participant].emprestimo = {
        valorOriginal: valor,
        divida: divida,
        prazo: prazo
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      return await sendSuccessReply(`🤝 *NEGÓCIO FECHADO!* 🤝\n\nO Agiota te entregou *${valor} Réis* em dinheiro vivo.\n\nSua dívida agora é de *${divida} Réis*.\nVocê tem exatamente *24 horas* para pagar, ou os juros vão comer sua alma!`);
    }

    // 💰 PAGAR DÍVIDA
    if (acao === "pagar") {
      if (!db[remoteJid][participant].emprestimo) {
        return await sendWarningReply("⚠️ Você não deve nada ao Agiota. Está com a ficha limpa!");
      }

      const emp = db[remoteJid][participant].emprestimo;
      const valorStr = args[1]?.toLowerCase();
      
      if (!valorStr) return await sendWarningReply(`⚠️ Digite o valor que deseja pagar.\nExemplo: *${PREFIX}agiota pagar 500* ou *${PREFIX}agiota pagar tudo*`);

      let valorPagamento = 0;
      if (valorStr === "tudo" || valorStr === "all") {
        valorPagamento = emp.divida;
      } else {
        valorPagamento = parseInt(valorStr.replace(/[^0-9]/g, ""), 10);
      }

      if (isNaN(valorPagamento) || valorPagamento <= 0) return await sendWarningReply("⚠️ Digite um valor válido.");

      if (valorPagamento > emp.divida) {
        valorPagamento = emp.divida; // Não deixa pagar mais do que deve
      }

      if (db[remoteJid][participant].saldo < valorPagamento) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira para pagar o Agiota.`);
      }

      db[remoteJid][participant].saldo -= valorPagamento;
      emp.divida -= valorPagamento;

      if (emp.divida <= 0) {
        delete db[remoteJid][participant].emprestimo;
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendSuccessReply(`✅ *DÍVIDA QUITADA!*\n\nVocê pagou o que devia e o Agiota rasgou sua promissória. Seu nome está limpo novamente!`);
      } else {
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendSuccessReply(`💰 *PAGAMENTO PARCIAL!*\n\nVocê pagou *${valorPagamento} Réis* ao Agiota.\nAinda restam *${emp.divida} Réis* para quitar a dívida.`);
      }
    }
  }
};
