import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "sacar",
  description: "Retira seus Réis do Banco Imperial.",
  commands: ["sacar", "saque", "retirar"],
  usage: `${PREFIX}sacar 100 ou ${PREFIX}sacar tudo`,
  
  handle: async ({ args, sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    if (!args[0]) return await sendWarningReply(`⚠️ Digite o valor que deseja sacar.\nExemplo: *${PREFIX}sacar 100*`);

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };
    if (db[remoteJid][participant].banco === undefined) db[remoteJid][participant].banco = 0;

    // 📈 RENDIMENTO ANTES DO SAQUE
    const agora = Date.now();
    const umDia = 24 * 60 * 60 * 1000;
    if (!db[remoteJid][participant].ultimoRendimento) {
      db[remoteJid][participant].ultimoRendimento = agora;
    } else {
      const diasPassados = Math.floor((agora - db[remoteJid][participant].ultimoRendimento) / umDia);
      if (diasPassados > 0 && db[remoteJid][participant].banco > 0) {
        db[remoteJid][participant].banco = Math.floor(db[remoteJid][participant].banco * Math.pow(1.02, diasPassados));
      }
      if (diasPassados > 0) db[remoteJid][participant].ultimoRendimento += diasPassados * umDia;
    }

    const bancoAtual = db[remoteJid][participant].banco;
    if (bancoAtual <= 0) return await sendWarningReply("⚠️ Sua conta bancária está zerada!");

    let valor = (args[0].toLowerCase() === "tudo" || args[0].toLowerCase() === "all") ? bancoAtual : parseInt(args[0].replace(/[^0-9]/g, ""), 10);

    if (isNaN(valor) || valor <= 0) return await sendWarningReply("⚠️ Digite um valor válido para sacar.");
    if (valor > bancoAtual) return await sendWarningReply(`⚠️ Você só tem *${bancoAtual} Réis* guardados no banco.`);

    db[remoteJid][participant].banco -= valor;
    db[remoteJid][participant].saldo += valor;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    await sendReply(`💸 *SAQUE REALIZADO!*\n\nVocê retirou *${valor} Réis* do Banco Imperial.\n\n💰 Carteira: *${db[remoteJid][participant].saldo}*\n🏛️ Banco: *${db[remoteJid][participant].banco}*`);
  }
};
