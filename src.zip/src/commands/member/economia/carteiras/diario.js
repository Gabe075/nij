import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "diario",
  description: "Recebe seus Réis diários do Império.",
  commands: ["diario", "daily", "tributo"],
  usage: `${PREFIX}diario`,
  
  handle: async ({ sendReply, remoteJid, webMessage }) => {
    let db = {};
    if (fs.existsSync(ecoPath)) {
      db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    }

    if (!db[remoteJid]) db[remoteJid] = {};
    
    const participant = webMessage.key.participant || remoteJid;
    if (!db[remoteJid][participant]) {
      db[remoteJid][participant] = { saldo: 0, lastDaily: 0 };
    }

    const userEco = db[remoteJid][participant];
    const now = Date.now();
    const tempoDeEspera = 24 * 60 * 60 * 1000; // 24 horas

    // Verifica se já pegou hoje
    if (now - userEco.lastDaily < tempoDeEspera) {
      const faltamMs = tempoDeEspera - (now - userEco.lastDaily);
      const horas = Math.floor(faltamMs / (1000 * 60 * 60));
      const minutos = Math.floor((faltamMs % (1000 * 60 * 60)) / (1000 * 60));
      return await sendReply(`⏳ Calma lá! Você já recolheu seus tributos hoje.\nVolte daqui a *${horas}h e ${minutos}m*.`);
    }

    // Dá um valor aleatório entre 100 e 500 Réis
    const ganho = Math.floor(Math.random() * 401) + 100;
    
    userEco.saldo += ganho;
    userEco.lastDaily = now;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    await sendReply(`💰 *TRIBUTO RECOLHIDO!*\n\nO Imperador foi generoso e te concedeu *${ganho} Réis*.\n🏦 Seu saldo atual: *${userEco.saldo} Réis*.`);
  }
};
