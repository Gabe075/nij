import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "carteira",
  description: "Mostra seu saldo atual e o dinheiro no banco.",
  commands: ["carteira", "saldo", "banco", "dinheiro"],
  usage: `${PREFIX}carteira`,
  
  handle: async ({ sendReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return;

    const participant = webMessage.key.participant || remoteJid;
    const userNum = participant.split("@")[0];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };
    if (db[remoteJid][participant].banco === undefined) db[remoteJid][participant].banco = 0;

    // 📈 LÓGICA DE RENDIMENTO (2% ao dia)
    const agora = Date.now();
    const umDia = 24 * 60 * 60 * 1000;
    let avisoRendimento = "";

    if (!db[remoteJid][participant].ultimoRendimento) {
      db[remoteJid][participant].ultimoRendimento = agora;
    } else {
      const diasPassados = Math.floor((agora - db[remoteJid][participant].ultimoRendimento) / umDia);
      if (diasPassados > 0 && db[remoteJid][participant].banco > 0) {
        const bancoAntigo = db[remoteJid][participant].banco;
        // Juros compostos: Valor * (1.02 ^ dias)
        db[remoteJid][participant].banco = Math.floor(bancoAntigo * Math.pow(1.02, diasPassados));
        db[remoteJid][participant].ultimoRendimento += diasPassados * umDia;
        
        const lucro = db[remoteJid][participant].banco - bancoAntigo;
        avisoRendimento = `\n📈 _Seu dinheiro rendeu +${lucro} Réis desde a última vez!_`;
      } else if (diasPassados > 0) {
        db[remoteJid][participant].ultimoRendimento += diasPassados * umDia;
      }
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    const saldo = db[remoteJid][participant].saldo;
    const banco = db[remoteJid][participant].banco;
    const total = saldo + banco;

    let msg = `🏦 *FINANÇAS IMPERIAIS* 🏦\n\n`;
    msg += `👤 Titular: @${userNum}\n\n`;
    msg += `👛 *Na Carteira:* ${saldo} Réis\n`;
    msg += `🏛️ *No Banco:* ${banco} Réis${avisoRendimento}\n`;
    msg += `──────────────\n`;
    msg += `📊 *Patrimônio Total:* ${total} Réis\n\n`;
    msg += `_Dica: O dinheiro no banco rende 2% ao dia automaticamente!_`;

    await sendReply(msg, [participant]);
  }
};
