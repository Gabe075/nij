import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");

export default {
  name: "usar",
  description: "Consome um item do seu inventário.",
  commands: ["usar", "consumir"],
  usage: `${PREFIX}usar <item>`,
  
  handle: async ({ args, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const senderJid = webMessage.key.participant || remoteJid;
    const escolha = args[0]?.toLowerCase();

    if (!escolha) return await sendWarningReply(`⚠️ Digite o item que deseja usar.\nExemplo: *${PREFIX}usar cafe*`);

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid] || !db[remoteJid][senderJid] || !db[remoteJid][senderJid].inventario || !db[remoteJid][senderJid].inventario[escolha]) {
      return await sendWarningReply(`⚠️ Você não tem esse item no seu *${PREFIX}inventario*.`);
    }

    // Consome o item
    db[remoteJid][senderJid].inventario[escolha] -= 1;

    // Aplica os efeitos
    if (escolha === "escudo") {
      db[remoteJid][senderJid].escudo = Date.now() + (12 * 60 * 60 * 1000);
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      addProgressoMissao(remoteJid, senderJid, "usar_item"); // 🟢 ATUALIZA A MISSÃO
      return await sendSuccessReply(`🛡️ *Item Consumido!*\nVocê ativou o *Escudo Imperial*. Sua carteira está protegida contra roubos pelas próximas 12 horas!`);
    } 
    
    else if (escolha === "kit") {
      db[remoteJid][senderJid].ultimoRoubo = 0; 
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      addProgressoMissao(remoteJid, senderJid, "usar_item"); // 🟢 ATUALIZA A MISSÃO
      return await sendSuccessReply(`🥷 *Item Consumido!*\nVocê usou o *Kit de Fuga*. A Guarda Imperial perdeu seu rastro e você já pode assaltar novamente!`);
    }

    else if (escolha === "cafe") {
      db[remoteJid][senderJid].ultimoTrabalho = 0; 
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      addProgressoMissao(remoteJid, senderJid, "usar_item"); // 🟢 ATUALIZA A MISSÃO
      return await sendSuccessReply(`☕ *Item Consumido!*\nVocê tomou um *Café Expresso* bem forte! Sua energia foi totalmente restaurada e você já pode bater o ponto novamente.`);
    }

    else if (escolha === "pocao") {
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2)); 
      
      let levelsDB = {};
      if (fs.existsSync(levelsPath)) levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      if (!levelsDB[remoteJid]) levelsDB[remoteJid] = {};
      if (!levelsDB[remoteJid][senderJid]) levelsDB[remoteJid][senderJid] = { xp: 0, level: 1 };

      levelsDB[remoteJid][senderJid].xp += 500;
      fs.writeFileSync(levelsPath, JSON.stringify(levelsDB, null, 2));

      addProgressoMissao(remoteJid, senderJid, "usar_item"); // 🟢 ATUALIZA A MISSÃO
      return await sendSuccessReply(`🧪 *Item Consumido!*\nVocê bebeu a *Poção de Sabedoria* e ganhou +500 XP instantaneamente!`);
    }
    
    else {
      // Devolve o item se não for consumível por esse comando (ex: pé de cabra)
      db[remoteJid][senderJid].inventario[escolha] += 1;
      return await sendWarningReply(`⚠️ Este item não pode ser consumido diretamente assim. Leia a descrição dele na loja para saber como usar.`);
    }
  }
};
