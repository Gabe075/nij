import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

// Dicionário para traduzir o ID do item para o nome bonito
const NOMES_ITENS = {
  "fumaca": "🧨 Bomba de Fumaça",
  "informante": "🕵️ Contrato de Informante",
  "pedecabra": "🪝 Pé de Cabra",
  "escudo": "🛡️ Escudo Imperial",
  "pocao": "🧪 Poção de Sabedoria",
  "kit": "🥷 Kit de Fuga",
  "cafe": "☕ Café Expresso"
};

export default {
  name: "inventario",
  description: "Mostra os itens guardados na sua mochila.",
  commands: ["inventario", "mochila", "inv", "itens"],
  usage: `${PREFIX}inventario`,
  
  handle: async ({ sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    
    const userInv = db[remoteJid]?.[participant]?.inventario || {};

    let msg = `🎒 *SEU INVENTÁRIO* 🎒\n\n`;
    let temItem = false;

    for (const [key, qtd] of Object.entries(userInv)) {
      if (qtd > 0) {
        const nome = NOMES_ITENS[key] || key;
        msg += `🔸 *${nome}* - ${qtd}x\n`;
        // Adiciona a dica de como usar se for item consumível
        if (["escudo", "pocao", "kit", "cafe"].includes(key)) {
          msg += `   ↳ _Comando: ${PREFIX}usar ${key}_\n`;
        }
        temItem = true;
      }
    }

    if (!temItem) {
      msg += `_Sua mochila está completamente vazia._\n_Visite a *${PREFIX}loja* ou o *${PREFIX}mercadonegro* para comprar equipamentos!_`;
    }

    await sendReply(msg);
  }
};
