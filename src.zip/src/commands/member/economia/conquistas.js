import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "conquistas",
    description: "Veja suas medalhas e conquistas imperiais.",
    commands: ["conquistas", "medalhas"],
    usage: `${PREFIX}conquistas`,
    handle: async ({ sendReply }) => {
        return await sendReply("🎖️ *MEDALHAS DE HONRA* 🎖️\nDesbloqueie conquistas para ganhar bônus permanentes!");
    }
};
