import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const bolsaPath = path.resolve("database", "bolsa_avancada.json");

const EMPRESAS_AVANCADAS = {
  "petrobraz": { nome: "Petrobraz Imperial", setor: "Petróleo", volatilidade: 0.30, dividendo: 0.05 },
  "valedorio": { nome: "Vale do Rio Imperial", setor: "Mineração", volatilidade: 0.25, dividendo: 0.03 },
  "bancodobrazil": { nome: "Banco do Brazil Imperial", setor: "Financeiro", volatilidade: 0.15, dividendo: 0.07 },
  "tecnologia": { nome: "Tecnologia Imperial S.A.", setor: "Tecnologia", volatilidade: 0.40, dividendo: 0.02 },
};

export default {
  name: "bolsaavancada",
  description: "Invista em ações de empresas imperiais com dividendos e maior volatilidade.",
  commands: ["bolsaavancada", "acoesavancadas", "investirplus"],
  usage: `${PREFIX}bolsaavancada`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const empresaKey = parts[1]?.toLowerCase();
    const qtd = parseInt(parts[2], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let bolsa = {};
    if (fs.existsSync(bolsaPath)) {
      bolsa = JSON.parse(fs.readFileSync(bolsaPath, "utf-8"));
    } else {
      // Inicializa preços base
      Object.keys(EMPRESAS_AVANCADAS).forEach(key => {
        bolsa[key] = { preco: 100, ultimaAtualizacao: Date.now() };
      });
      fs.writeFileSync(bolsaPath, JSON.stringify(bolsa, null, 2));
    }

    // Atualiza preços e paga dividendos se passou 1 hora
    const umaHora = 60 * 60 * 1000;
    const agora = Date.now();
    let atualizou = false;
    Object.keys(bolsa).forEach(key => {
      if (agora - bolsa[key].ultimaAtualizacao > umaHora) {
        const v = EMPRESAS_AVANCADAS[key].volatilidade;
        const mudanca = (Math.random() * (v * 2) - v);
        bolsa[key].preco = Math.max(10, Math.floor(bolsa[key].preco * (1 + mudanca)));
        bolsa[key].ultimaAtualizacao = agora;
        atualizou = true;

        // Pagar dividendos
        if (EMPRESAS_AVANCADAS[key].dividendo > 0) {
          for (const jid in db[remoteJid]) {
            if (db[remoteJid][jid].acoesAvancadas && db[remoteJid][jid].acoesAvancadas[key]) {
              const qtdAcoes = db[remoteJid][jid].acoesAvancadas[key];
              const dividendoGanho = Math.floor(qtdAcoes * bolsa[key].preco * EMPRESAS_AVANCADAS[key].dividendo);
              db[remoteJid][jid].saldo += dividendoGanho;
              sendReply(`💰 *DIVIDENDOS RECEBIDOS!*\nVocê recebeu *${dividendoGanho} Réis* em dividendos da *${EMPRESAS_AVANCADAS[key].nome}*!`, [jid]);
            }
          }
        }
      }
    });
    if (atualizou) fs.writeFileSync(bolsaPath, JSON.stringify(bolsa, null, 2));
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2)); // Salva o ecoPath após dividendos

    if (!acao || acao === "lista") {
      let menu = `📈 *BOLSA DE VALORES AVANÇADA IMPERIAL* 📈\n\n`;
      Object.keys(EMPRESAS_AVANCADAS).forEach(key => {
        menu += `🏢 *${EMPRESAS_AVANCADAS[key].nome}*\n`;
        menu += `   ↳ Preço: ${bolsa[key].preco} Réis\n`;
        menu += `   ↳ Setor: ${EMPRESAS_AVANCADAS[key].setor}\n`;
        menu += `   ↳ Dividendo Anual: ${(EMPRESAS_AVANCADAS[key].dividendo * 100).toFixed(0)}%\n`;
        menu += `🛒 Comando: *${PREFIX}bolsaavancada comprar ${key} 1*\n\n`;
      });
      menu += `_Use *${PREFIX}bolsaavancada carteira* para ver suas ações._`;
      return await sendReply(menu);
    }

    if (acao === "carteira") {
      const carteira = db[remoteJid][participant].acoesAvancadas || {};
      if (Object.keys(carteira).length === 0) return await sendReply("📭 Você não possui nenhuma ação avançada.");
      
      let msg = `📂 *SUA CARTEIRA DE AÇÕES AVANÇADAS* 📂\n\n`;
      let totalInvestido = 0;
      Object.entries(carteira).forEach(([key, qtd]) => {
        const valorAtual = bolsa[key].preco * qtd;
        totalInvestido += valorAtual;
        msg += `🏢 *${EMPRESAS_AVANCADAS[key].nome}*\n`;
        msg += `   ↳ Quantidade: ${qtd}\n`;
        msg += `   ↳ Valor Atual: ${valorAtual} Réis\n\n`;
      });
      msg += `💰 *Patrimônio em Ações Avançadas:* ${totalInvestido} Réis`;
      return await sendReply(msg);
    }

    if (acao === "comprar") {
      if (!EMPRESAS_AVANCADAS[empresaKey] || isNaN(qtd) || qtd <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}bolsaavancada comprar petrobraz 10*`);
      }
      const custoTotal = bolsa[empresaKey].preco * qtd;
      if (db[remoteJid][participant].saldo < custoTotal) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoTotal} Réis* para comprar ${qtd} ações.`);
      }
      
      db[remoteJid][participant].saldo -= custoTotal;
      if (!db[remoteJid][participant].acoesAvancadas) db[remoteJid][participant].acoesAvancadas = {};
      db[remoteJid][participant].acoesAvancadas[empresaKey] = (db[remoteJid][participant].acoesAvancadas[empresaKey] || 0) + qtd;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *INVESTIMENTO REALIZADO!*\nVocê comprou ${qtd} ações da *${EMPRESAS_AVANCADAS[empresaKey].nome}* por ${custoTotal} Réis.`);
    }

    if (acao === "vender") {
      if (!EMPRESAS_AVANCADAS[empresaKey] || isNaN(qtd) || qtd <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}bolsaavancada vender petrobraz 10*`);
      }
      const possuida = db[remoteJid][participant].acoesAvancadas?.[empresaKey] || 0;
      if (possuida < qtd) return await sendWarningReply(`⚠️ Você só possui ${possuida} ações desta empresa.`);
      
      const valorVenda = bolsa[empresaKey].preco * qtd;
      db[remoteJid][participant].saldo += valorVenda;
      db[remoteJid][participant].acoesAvancadas[empresaKey] -= qtd;
      if (db[remoteJid][participant].acoesAvancadas[empresaKey] === 0) delete db[remoteJid][participant].acoesAvancadas[empresaKey];
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`💰 *VENDA REALIZADA!*\nVocê vendeu ${qtd} ações da *${EMPRESAS_AVANCADAS[empresaKey].nome}* por ${valorVenda} Réis.`);
    }
  }
};
