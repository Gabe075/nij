import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const bolsaPath = path.resolve("database", "bolsa.json");

const EMPRESAS = {
  "indias": { nome: "Companhia das Índias", setor: "Comércio", volatilidade: 0.15 },
  "ferro": { nome: "Estrada de Ferro Imperial", setor: "Transporte", volatilidade: 0.08 },
  "banco": { nome: "Banco do Brasil", setor: "Financeiro", volatilidade: 0.05 },
  "minas": { nome: "Minas Gerais S.A.", setor: "Mineração", volatilidade: 0.20 }
};

export default {
  name: "investir",
  description: "Invista na Bolsa de Valores Imperial.",
  commands: ["investir", "bolsa", "acoes", "compraracao"],
  usage: `${PREFIX}investir`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const empresaKey = parts[1]?.toLowerCase();
    const qtd = parseInt(parts[2], 10);

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    
    let bolsa = {};
    if (fs.existsSync(bolsaPath)) {
      bolsa = JSON.parse(fs.readFileSync(bolsaPath, "utf-8"));
    } else {
      // Inicializa preços base
      Object.keys(EMPRESAS).forEach(key => {
        bolsa[key] = { preco: 100, ultimaAtualizacao: Date.now() };
      });
      fs.writeFileSync(bolsaPath, JSON.stringify(bolsa, null, 2));
    }

    // Atualiza preços se passou 1 hora
    const umaHora = 60 * 60 * 1000;
    const agora = Date.now();
    let atualizou = false;

    Object.keys(bolsa).forEach(key => {
      if (agora - bolsa[key].ultimaAtualizacao > umaHora) {
        const v = EMPRESAS[key].volatilidade;
        const mudanca = (Math.random() * (v * 2) - v);
        bolsa[key].preco = Math.max(10, Math.floor(bolsa[key].preco * (1 + mudanca)));
        bolsa[key].ultimaAtualizacao = agora;
        atualizou = true;
      }
    });
    if (atualizou) fs.writeFileSync(bolsaPath, JSON.stringify(bolsa, null, 2));

    if (!acao || acao === "lista") {
      let menu = `📈 *BOLSA DE VALORES IMPERIAL* 📈\n\n`;
      Object.keys(EMPRESAS).forEach(key => {
        menu += `🏢 *${EMPRESAS[key].nome}*\n`;
        menu += `   ↳ Preço: ${bolsa[key].preco} Réis\n`;
        menu += `   ↳ Setor: ${EMPRESAS[key].setor}\n`;
        menu += `🛒 Comando: *${PREFIX}investir comprar ${key} 1*\n\n`;
      });
      menu += `_Use *${PREFIX}investir carteira* para ver suas ações._`;
      return await sendReply(menu);
    }

    if (acao === "carteira") {
      const carteira = db[remoteJid][participant].acoes || {};
      if (Object.keys(carteira).length === 0) return await sendReply("📭 Você não possui nenhuma ação.");
      
      let msg = `📂 *SUA CARTEIRA DE AÇÕES* 📂\n\n`;
      let totalInvestido = 0;
      Object.entries(carteira).forEach(([key, qtd]) => {
        const valorAtual = bolsa[key].preco * qtd;
        totalInvestido += valorAtual;
        msg += `🏢 *${EMPRESAS[key].nome}*\n`;
        msg += `   ↳ Quantidade: ${qtd}\n`;
        msg += `   ↳ Valor Atual: ${valorAtual} Réis\n\n`;
      });
      msg += `💰 *Patrimônio em Ações:* ${totalInvestido} Réis`;
      return await sendReply(msg);
    }

    if (acao === "comprar") {
      if (!EMPRESAS[empresaKey] || isNaN(qtd) || qtd <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}investir comprar indias 10*`);
      }
      const custoTotal = bolsa[empresaKey].preco * qtd;
      if (db[remoteJid][participant].saldo < custoTotal) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoTotal} Réis* para comprar ${qtd} ações.`);
      }

      db[remoteJid][participant].saldo -= custoTotal;
      if (!db[remoteJid][participant].acoes) db[remoteJid][participant].acoes = {};
      db[remoteJid][participant].acoes[empresaKey] = (db[remoteJid][participant].acoes[empresaKey] || 0) + qtd;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *INVESTIMENTO REALIZADO!*\nVocê comprou ${qtd} ações da *${EMPRESAS[empresaKey].nome}* por ${custoTotal} Réis.`);
    }

    if (acao === "vender") {
      if (!EMPRESAS[empresaKey] || isNaN(qtd) || qtd <= 0) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}investir vender indias 10*`);
      }
      const possuida = db[remoteJid][participant].acoes?.[empresaKey] || 0;
      if (possuida < qtd) return await sendWarningReply(`⚠️ Você só possui ${possuida} ações desta empresa.`);

      const valorVenda = bolsa[empresaKey].preco * qtd;
      db[remoteJid][participant].saldo += valorVenda;
      db[remoteJid][participant].acoes[empresaKey] -= qtd;
      if (db[remoteJid][participant].acoes[empresaKey] === 0) delete db[remoteJid][participant].acoes[empresaKey];

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`💰 *VENDA REALIZADA!*\nVocê vendeu ${qtd} ações da *${EMPRESAS[empresaKey].nome}* por ${valorVenda} Réis.`);
    }
  }
};
