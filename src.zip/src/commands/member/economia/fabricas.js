import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const fabricasPath = path.resolve("database", "fabricas.json");

const TIPOS_FABRICA = {
  "textil": { nome: "Fábrica Têxtil", custo: 15000, producaoHora: 500, produto: "Tecido" },
  "alimentos": { nome: "Fábrica de Alimentos", custo: 20000, producaoHora: 700, produto: "Alimento" },
  "armas": { nome: "Fábrica de Armas", custo: 50000, producaoHora: 1500, produto: "Arma" }
};

export default {
  name: "fabricas",
  description: "Compre e gerencie suas fábricas para produzir itens.",
  commands: ["fabricas", "fabrica", "produzir"],
  usage: `${PREFIX}fabricas`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const tipoFabrica = parts[1]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    
    let fabDB = {};
    if (fs.existsSync(fabricasPath)) fabDB = JSON.parse(fs.readFileSync(fabricasPath, "utf-8"));
    if (!fabDB[remoteJid]) fabDB[remoteJid] = {};
    if (!fabDB[remoteJid][participant]) fabDB[remoteJid][participant] = { fabricas: {} };

    if (!acao || acao === "lista") {
      let menu = `🏭 *PARQUE INDUSTRIAL IMPERIAL* 🏭\n\nCompre fábricas para produzir itens e vendê-los no mercado!\n\n`;
      for (const [key, fabrica] of Object.entries(TIPOS_FABRICA)) {
        menu += `🔸 *${fabrica.nome}*\n`;
        menu += `   ↳ Produz: ${fabrica.producaoHora} ${fabrica.produto}/hora\n`;
        menu += `   ↳ Custo: 💰 ${fabrica.custo} Réis\n`;
        menu += `🛒 Comando: *${PREFIX}fabricas comprar ${key}*\n\n`;
      }
      menu += `_Use *${PREFIX}fabricas minhas* para ver suas fábricas e coletar produção._`;
      return await sendReply(menu);
    }

    if (acao === "minhas") {
      const minhasFabricas = fabDB[remoteJid][participant].fabricas;
      if (Object.keys(minhasFabricas).length === 0) return await sendReply("Você não possui nenhuma fábrica.");

      let msg = `🏭 *SUAS FÁBRICAS* 🏭\n\n`;
      let totalProducao = 0;
      const agora = Date.now();

      for (const [key, data] of Object.entries(minhasFabricas)) {
        const fabrica = TIPOS_FABRICA[key];
        if (fabrica) {
          const horasPassadas = (agora - data.ultimaColeta) / (1000 * 60 * 60);
          const producaoAtual = Math.floor(fabrica.producaoHora * horasPassadas);
          totalProducao += producaoAtual;
          msg += `🏢 *${fabrica.nome}*\n`;
          msg += `   ↳ Produção Acumulada: ${producaoAtual} ${fabrica.produto}\n`;
          msg += `   ↳ Última Coleta: ${new Date(data.ultimaColeta).toLocaleString()}\n\n`;
        }
      }
      msg += `📦 *Total de Produção Acumulada:* ${totalProducao} itens`;
      msg += `\n_Use *${PREFIX}fabricas coletar* para recolher sua produção._`;
      return await sendReply(msg);
    }

    if (acao === "comprar") {
      if (!TIPOS_FABRICA[tipoFabrica]) {
        return await sendWarningReply(`⚠️ Tipo de fábrica inválido! Digite *${PREFIX}fabricas* para ver a lista.`);
      }
      const fabrica = TIPOS_FABRICA[tipoFabrica];

      if (db[remoteJid][participant].saldo < fabrica.custo) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${fabrica.custo} Réis* para comprar a ${fabrica.nome}.`);
      }

      db[remoteJid][participant].saldo -= fabrica.custo;
      fabDB[remoteJid][participant].fabricas[tipoFabrica] = {
        ultimaColeta: Date.now()
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(fabricasPath, JSON.stringify(fabDB, null, 2));

      return await sendSuccessReply(`✅ *FÁBRICA ADQUIRIDA!*\nVocê comprou a *${fabrica.nome}* e ela já começou a produzir!`);
    }

    if (acao === "coletar") {
      const minhasFabricas = fabDB[remoteJid][participant].fabricas;
      if (Object.keys(minhasFabricas).length === 0) return await sendWarningReply("Você não possui nenhuma fábrica para coletar.");

      let totalItensColetados = 0;
      const agora = Date.now();
      let relatorio = `📦 *PRODUÇÃO COLETADA!* 📦\n\n`;

      for (const [key, data] of Object.entries(minhasFabricas)) {
        const fabrica = TIPOS_FABRICA[key];
        if (fabrica) {
          const horasPassadas = (agora - data.ultimaColeta) / (1000 * 60 * 60);
          const producaoAtual = Math.floor(fabrica.producaoHora * horasPassadas);
          totalItensColetados += producaoAtual;
          
          // Adiciona ao inventário do usuário
          if (!db[remoteJid][participant].inventario) db[remoteJid][participant].inventario = {};
          db[remoteJid][participant].inventario[fabrica.produto.toLowerCase()] = (db[remoteJid][participant].inventario[fabrica.produto.toLowerCase()] || 0) + producaoAtual;

          relatorio += `🏢 ${fabrica.nome}: *+${producaoAtual} ${fabrica.produto}*\n`;
          fabDB[remoteJid][participant].fabricas[key].ultimaColeta = agora;
        }
      }

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(fabricasPath, JSON.stringify(fabDB, null, 2));

      return await sendSuccessReply(`${relatorio}\nTotal de itens coletados: *${totalItensColetados}*!`);
    }
  }
};
