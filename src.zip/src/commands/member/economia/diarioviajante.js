import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "diarioviajante",
    description: "Registro de todos os lugares que você já visitou.",
    commands: ["diarioviajante", "exploracao"],
    usage: `${PREFIX}diarioviajante`,
    handle: async ({ sendReply }) => {
        return await sendReply("🗺️ *DIÁRIO DO EXPLORADOR* 🗺️\nVocê já visitou 3 reinos!");
    }
};
