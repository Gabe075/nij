import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "casamentovip",
    description: "Realize uma festa de casamento luxuosa.",
    commands: ["festacasamento", "cerimonia"],
    usage: `${PREFIX}festacasamento`,
    handle: async ({ sendReply }) => {
        return await sendReply("🥂 *GRANDE BAILE DE CASAMENTO* 🥂\nConvide o servidor inteiro para sua festa real!");
    }
};
