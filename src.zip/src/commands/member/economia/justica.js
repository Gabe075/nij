import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "justica",
    description: "Sistema de leis e punições para crimes econômicos.",
    commands: ["justica", "leis"],
    usage: `${PREFIX}justica`,
    handle: async ({ sendReply }) => {
        return await sendReply("⚖️ *CÓDIGO PENAL IMPERIAL* ⚖️\nRoubar bancos dá pena de confisco de bens!");
    }
};
