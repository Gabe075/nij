import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "mercadominerio",
    description: "Venda seus minérios preciosos pela melhor cotação.",
    commands: ["mercadominerio", "cotacaomineral"],
    usage: `${PREFIX}mercadominerio`,
    handle: async ({ sendReply }) => {
        return await sendReply("💎 *BOLSA DE MINÉRIOS* 💎\nOuro: 500 Réis/g\nDiamante: 2500 Réis/g");
    }
};
