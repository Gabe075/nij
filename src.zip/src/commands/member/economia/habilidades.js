import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const HABILIDADES = {
  "ferreiro": {
    nome: "Ferreiro 🔨",
    descricao: "Cria e repara equipamentos, ganhando bônus em combate ou venda.",
    custoTreino: 1000,
    bonus: { combate: 0.05, venda: 0.03 },
    xpPorUso: 10
  },
  "alquimista": {
    nome: "Alquimista 🧪",
    descricao: "Cria poções e elixires com efeitos variados.",
    custoTreino: 1200,
    bonus: { cura: 0.10, sorte: 0.02 },
    xpPorUso: 12
  },
  "comerciante": {
    nome: "Comerciante 💰",
    descricao: "Negocia itens com melhores preços, aumentando lucros em vendas e compras.",
    custoTreino: 800,
    bonus: { compra: 0.05, venda: 0.05 },
    xpPorUso: 8
  },
};

export default {
  name: "habilidades",
  description: "Treine habilidades para desbloquear bônus e ações especiais.",
  commands: ["habilidades", "profissaoavancada", "treinar"],
  usage: `${PREFIX}habilidades`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const habilidadeKey = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    if (!db[remoteJid][participant].habilidades) db[remoteJid][participant].habilidades = {};

    if (!acao || acao === "ajuda") {
      let menu = `✨ *SISTEMA DE HABILIDADES IMPERIAIS* ✨\n\n`;
      menu += `Treine habilidades para se tornar um mestre em sua área e ganhar bônus!\n\n`;
      
      for (const [key, hab] of Object.entries(HABILIDADES)) {
        menu += `🛠️ *${hab.nome}*\n`;
        menu += `   ↳ Descrição: ${hab.descricao}\n`;
        menu += `   ↳ Custo de Treino: ${hab.custoTreino} Réis\n`;
        menu += `   ↳ Bônus: ${Object.entries(hab.bonus).map(([k, v]) => `${k}: +${(v * 100).toFixed(0)}%`).join(", ")}\n`;
        menu += `📚 *${PREFIX}habilidades treinar ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}habilidades minhas* para ver suas habilidades treinadas._`;
      return await sendReply(menu);
    }

    if (acao === "minhas") {
      const minhasHabs = db[remoteJid][participant].habilidades;
      if (Object.keys(minhasHabs).length === 0) return await sendReply("📭 Você não treinou nenhuma habilidade ainda.");
      
      let msg = `📚 *SUAS HABILIDADES TREINADAS* 📚\n\n`;
      for (const [key, data] of Object.entries(minhasHabs)) {
        const hab = HABILIDADES[key];
        msg += `🛠️ *${hab.nome}*\n`;
        msg += `   ↳ Nível: ${data.nivel}\n`;
        msg += `   ↳ XP: ${data.xp}\n`;
        msg += `   ↳ Bônus Ativos: ${Object.entries(hab.bonus).map(([k, v]) => `${k}: +${(v * 100 * data.nivel).toFixed(0)}%`).join(", ")}\n\n`;
      }
      return await sendReply(msg);
    }

    if (acao === "treinar") {
      if (!HABILIDADES[habilidadeKey]) return await sendWarningReply(`⚠️ Habilidade inválida!`);
      const hab = HABILIDADES[habilidadeKey];
      
      if (db[remoteJid][participant].habilidades[habilidadeKey]) {
        return await sendWarningReply(`⚠️ Você já treinou a habilidade *${hab.nome}*.`);
      }
      
      if (db[remoteJid][participant].saldo < hab.custoTreino) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${hab.custoTreino} Réis* para treinar *${hab.nome}*.`);
      }
      
      db[remoteJid][participant].saldo -= hab.custoTreino;
      db[remoteJid][participant].habilidades[habilidadeKey] = { nivel: 1, xp: 0 };
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *HABILIDADE TREINADA!*\nVocê agora é um *${hab.nome}* de Nível 1!`);
    }
  }
};
