import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "talentos",
    description: "Desbloqueie talentos passivos para sua conta.",
    commands: ["talentos", "passivas"],
    usage: `${PREFIX}talentos`,
    handle: async ({ sendReply }) => {
        return await sendReply("🌟 *ÁRVORE DE TALENTOS* 🌟\nMelhore sua eficiência em tudo o que faz!");
    }
};
