import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "bancocentral",
    description: "Sistema de dívidas e juros do Império.",
    commands: ["bancocentral", "dividas"],
    usage: `${PREFIX}bancocentral`,
    handle: async ({ sendReply }) => {
        return await sendReply("🏦 *BANCO CENTRAL DO BRAZIL* 🏦\nTaxa SELIC: 12.5% ao ano.\nCuidado com as dívidas!");
    }
};
