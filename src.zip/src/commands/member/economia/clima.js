import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const CLIMAS = ["Ensolarado ☀️", "Chuvoso 🌧️", "Tempestade ⛈️", "Nublado ☁️", "Nevoeiro 🌫️"];

export default {
    name: "clima",
    description: "Veja o clima atual do império. O clima afeta a pesca e a fazenda.",
    commands: ["clima", "tempo"],
    usage: `${PREFIX}clima`,
    handle: async ({ sendReply }) => {
        // Lógica baseada no dia do mês para ser consistente para todos
        const dia = new Date().getDate();
        const climaHoje = CLIMAS[dia % CLIMAS.length];
        
        let msg = `🌤️ *METEOROLOGIA IMPERIAL* 🌤️\n\n`;
        msg += `O clima hoje é: *${climaHoje}*\n\n`;
        
        if (climaHoje.includes("Chuvoso")) {
            msg += `💡 *Dica:* Hoje você não precisa regar sua fazenda! A natureza cuida disso.`;
        } else if (climaHoje.includes("Tempestade")) {
            msg += `💡 *Dica:* Peixes raros aparecem em tempestades! Ótimo dia para pescar.`;
        } else if (climaHoje.includes("Ensolarado")) {
            msg += `💡 *Dica:* Os cultivos crescem mais rápido no sol.`;
        }
        
        return await sendReply(msg);
    }
};
