import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const CAVALOS = {
    "pangaré": { nome: "Pangaré", preco: 2000, velocidade: 10 },
    "mangalarga": { nome: "Mangalarga Marchador", preco: 15000, velocidade: 30 },
    "arabe": { nome: "Puro Sangue Árabe", preco: 50000, velocidade: 60 },
    "imperial": { nome: "Garanhão Imperial", preco: 150000, velocidade: 100 }
};

export default {
    name: "estabulo",
    description: "Compre cavalos para viajar mais rápido e participar de corridas.",
    commands: ["estabulo", "cavalos", "comprarcavalo"],
    usage: `${PREFIX}estabulo`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage }) => {
        const participant = webMessage.key.participant || remoteJid;
        let db = {};
        if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
        if (!db[remoteJid]) db[remoteJid] = {};
        if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, cavalo: null };

        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        if (!acao || acao === "lista") {
            let msg = `🐎 *ESTÁBULO REAL* 🐎\n\n`;
            msg += `Seu cavalo atual: *${db[remoteJid][participant].cavalo || "Nenhum"}*\n\n`;
            for (const [key, c] of Object.entries(CAVALOS)) {
                msg += `🔸 *${c.nome}*\n`;
                msg += `   ↳ Preço: 💰 ${c.preco} Réis\n`;
                msg += `   ↳ Velocidade: ${c.velocidade}\n`;
                msg += `🛒 *${PREFIX}estabulo comprar ${key}*\n\n`;
            }
            return await sendReply(msg);
        }

        if (acao === "comprar") {
            const horse = parts[1]?.toLowerCase();
            if (!CAVALOS[horse]) return await sendWarningReply("⚠️ Cavalo não encontrado!");
            if (db[remoteJid][participant].saldo < CAVALOS[horse].preco) return await sendWarningReply("💸 Saldo insuficiente!");

            db[remoteJid][participant].saldo -= CAVALOS[horse].preco;
            db[remoteJid][participant].cavalo = CAVALOS[horse].nome;
            fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
            return await sendSuccessReply(`🐎 Você adquiriu um *${CAVALOS[horse].nome}*!`);
        }
    }
};
