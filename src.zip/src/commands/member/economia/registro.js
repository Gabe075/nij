import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");
const latifundiosPath = path.resolve("database", "latifundios.json");

function garantirArquivo(caminho, estrutura = {}) {
  if (!fs.existsSync(caminho)) {
    fs.writeFileSync(caminho, JSON.stringify(estrutura, null, 2));
  }
}

function lerJSON(caminho) {
  garantirArquivo(caminho, {});
  return JSON.parse(fs.readFileSync(caminho, "utf-8"));
}

function salvarJSON(caminho, dados) {
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2));
}

export default {
  name: "registro",
  description: "Cria seu Registro Geral Imperial.",
  commands: ["registro", "rg", "registrar"],
  usage: `${PREFIX}registro`,

  handle: async ({
    sendReply,
    sendSuccessReply,
    sendWarningReply,
    remoteJid,
    webMessage,
  }) => {

    const participant =
      webMessage.key.participant || webMessage.key.remoteJid;

    // =========================
    // ECONOMIA
    // =========================

    const ecoDB = lerJSON(ecoPath);

    if (!ecoDB[remoteJid]) {
      ecoDB[remoteJid] = {};
    }

    if (ecoDB[remoteJid][participant]) {
      return await sendWarningReply(
        "⚠️ Você já possui um Registro Imperial."
      );
    }

    ecoDB[remoteJid][participant] = {
      saldo: 500,
      banco: 0,
      profissao: "Desempregado",
      trabalhoCooldown: 0,
      ultimoDaily: 0,
      patrimonio: 500,
      mascote: null,
      imoveis: [],
      inventario: [],
      criadoEm: Date.now(),
    };

    salvarJSON(ecoPath, ecoDB);

    // =========================
    // LEVELS
    // =========================

    const levelsDB = lerJSON(levelsPath);

    if (!levelsDB[remoteJid]) {
      levelsDB[remoteJid] = {};
    }

    levelsDB[remoteJid][participant] = {
      level: 1,
      xp: 0,
    };

    salvarJSON(levelsPath, levelsDB);

    // =========================
    // LATIFUNDIOS
    // =========================

    const latDB = lerJSON(latifundiosPath);

    if (!latDB[remoteJid]) {
      latDB[remoteJid] = {};
    }

    latDB[remoteJid][participant] = {
      possuiFazenda: false,
      nomeFazenda: null,
      culturas: {},
      armazem: {},
      nivelFazenda: 0,
      terras: 0,
      criadoEm: Date.now(),
    };

    salvarJSON(latifundiosPath, latDB);

    // =========================
    // FINAL
    // =========================

    return await sendSuccessReply(
`📜 *REGISTRO IMPERIAL CRIADO!* 📜

👤 Seu cidadão foi oficialmente registrado no Império.

💰 Você recebeu:
➜ 500 Réis iniciais

📌 Agora você já pode:
• Trabalhar
• Evoluir
• Comprar propriedades
• Construir patrimônio

⚠️ Para iniciar na agricultura, compre uma fazenda primeiro.

🎮 Comandos úteis:
• ${PREFIX}perfil
• ${PREFIX}empregos
• ${PREFIX}trabalhar`
    );
  },
};