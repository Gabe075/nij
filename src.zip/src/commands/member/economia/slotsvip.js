import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "slotsvip",
    description: "Caça-níqueis exclusivo para Nobres com prêmios maiores.",
    commands: ["slotsvip", "cassinovip"],
    usage: `${PREFIX}slotsvip`,
    handle: async ({ sendReply, remoteJid, webMessage }) => {
        const participant = webMessage.key.participant || remoteJid;
        const ecoPath = path.resolve("database", "economia.json");
        let db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
        const user = db[remoteJid]?.[participant];

        if (!user || !user.nobreza || user.nobreza === "Plebeu") {
            return await sendReply("🚫 *ACESSO NEGADO!* Este cassino é exclusivo para a *Nobreza Imperial*.");
        }
        
        return await sendReply("🎰 *CASSINO VIP* 🎰\nEm breve: Prêmios de milhões de Réis!");
    }
};
