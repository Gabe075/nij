import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const museuPath = path.resolve("database", "museu.json");

export default {
    name: "museu",
    description: "Doe artefatos raros encontrados no garimpo ou pesca para o museu.",
    commands: ["museu", "doarartefato"],
    usage: `${PREFIX}museu`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage }) => {
        const participant = webMessage.key.participant || remoteJid;
        let db = {};
        if (fs.existsSync(museuPath)) db = JSON.parse(fs.readFileSync(museuPath, "utf-8"));
        if (!db[remoteJid]) db[remoteJid] = {};
        if (!db[remoteJid][participant]) db[remoteJid][participant] = { colecao: [] };

        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        if (!acao || acao === "ver") {
            let msg = `🏛️ *MUSEU IMPERIAL* 🏛️\n\n`;
            msg += `Sua coleção: ${db[remoteJid][participant].colecao.length} artefatos.\n\n`;
            if (db[remoteJid][participant].colecao.length === 0) {
                msg += `_Seu museu está vazio. Encontre artefatos raros explorando o mundo!_`;
            } else {
                msg += db[remoteJid][participant].colecao.map(a => `📜 ${a}`).join("\n");
            }
            return await sendReply(msg);
        }
    }
};
