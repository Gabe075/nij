import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const CIDADES = {
  "capital": { nome: "Capital Imperial 👑", precoBase: { madeira: 10, ferro: 20, especiarias: 50 } },
  "porto": { nome: "Porto Comercial ⚓", precoBase: { madeira: 15, ferro: 18, especiarias: 40 } },
  "mina": { nome: "Cidade Mineira ⛏️", precoBase: { madeira: 8, ferro: 25, especiarias: 60 } },
};

const RECURSOS = {
  "madeira": { nome: "Madeira 🌳", peso: 1 },
  "ferro": { nome: "Ferro 🔩", peso: 2 },
  "especiarias": { nome: "Especiarias 🌶️", peso: 0.5 },
};

export default {
  name: "rotascomerciais",
  description: "Estabeleça rotas comerciais entre cidades para comprar e vender recursos com lucro.",
  commands: ["rotas", "comercio", "negociar"],
  usage: `${PREFIX}rotas`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const recursoKey = parts[1]?.toLowerCase();
    const quantidade = parseInt(parts[2], 10);
    const cidadeOrigem = parts[3]?.toLowerCase();
    const cidadeDestino = parts[4]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, inventario: {} };
    if (!db[remoteJid][participant].rotas) db[remoteJid][participant].rotas = { emViagem: null };

    const agora = Date.now();

    // Verifica se há viagem em andamento e processa chegada
    if (db[remoteJid][participant].rotas.emViagem && db[remoteJid][participant].rotas.emViagem.chegada <= agora) {
      const viagem = db[remoteJid][participant].rotas.emViagem;
      const recurso = RECURSOS[viagem.recurso];
      const ganho = viagem.quantidade * viagem.precoVenda;
      
      db[remoteJid][participant].saldo += ganho;
      await sendSuccessReply(`🚚 *CARAVANA CHEGOU!*\nSua caravana chegou em *${CIDADES[viagem.destino].nome}* e vendeu *${viagem.quantidade}x ${recurso.nome}* por *${ganho} Réis*!`);
      
      db[remoteJid][participant].rotas.emViagem = null;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    }

    if (!acao || acao === "ajuda") {
      let menu = `🚚 *ROTAS COMERCIAIS IMPERIAIS* 🚚\n\n`;
      menu += `Compre recursos em uma cidade e venda em outra para lucrar!\n\n`;
      menu += `🔸 *${PREFIX}rotas listar* - Veja os preços dos recursos em cada cidade\n`;
      menu += `🔸 *${PREFIX}rotas comprar <recurso> <qtd> <cidade_origem>* - Compra recursos\n`;
      menu += `🔸 *${PREFIX}rotas enviar <recurso> <qtd> <cidade_origem> <cidade_destino>* - Envia recursos para venda\n`;
      menu += `🔸 *${PREFIX}rotas status* - Veja sua caravana em viagem\n\n`;
      
      if (db[remoteJid][participant].rotas.emViagem) {
        const viagem = db[remoteJid][participant].rotas.emViagem;
        const tempoRestante = Math.ceil((viagem.chegada - agora) / (60 * 1000));
        menu += `_Sua caravana está viajando com ${viagem.quantidade}x ${RECURSOS[viagem.recurso].nome} para ${CIDADES[viagem.destino].nome}. Chegada em ${tempoRestante} minutos._`;
      }
      return await sendReply(menu);
    }

    if (acao === "listar") {
      let msg = `📊 *PREÇOS DE RECURSOS NAS CIDADES* 📊\n\n`;
      for (const [cidadeKey, cidade] of Object.entries(CIDADES)) {
        msg += `🏙️ *${cidade.nome}*\n`;
        for (const [recursoKey, preco] of Object.entries(cidade.precoBase)) {
          msg += `   ↳ ${RECURSOS[recursoKey].nome}: ${preco} Réis\n`;
        }
        msg += `\n`;
      }
      return await sendReply(msg);
    }

    if (acao === "comprar") {
      if (!RECURSOS[recursoKey] || isNaN(quantidade) || quantidade <= 0 || !CIDADES[cidadeOrigem]) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}rotas comprar madeira 10 capital*`);
      }
      const recurso = RECURSOS[recursoKey];
      const cidade = CIDADES[cidadeOrigem];
      const precoUnitario = cidade.precoBase[recursoKey];
      const custoTotal = precoUnitario * quantidade;

      if (db[remoteJid][participant].saldo < custoTotal) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoTotal} Réis* para comprar ${quantidade}x ${recurso.nome}.`);
      }

      db[remoteJid][participant].saldo -= custoTotal;
      db[remoteJid][participant].inventario[recursoKey] = (db[remoteJid][participant].inventario[recursoKey] || 0) + quantidade;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *COMPRA REALIZADA!*\nVocê comprou ${quantidade}x *${recurso.nome}* em *${cidade.nome}* por *${custoTotal} Réis*!`);
    }

    if (acao === "enviar") {
      if (!RECURSOS[recursoKey] || isNaN(quantidade) || quantidade <= 0 || !CIDADES[cidadeOrigem] || !CIDADES[cidadeDestino]) {
        return await sendWarningReply(`⚠️ Uso incorreto!\nExemplo: *${PREFIX}rotas enviar madeira 10 capital porto*`);
      }
      if (cidadeOrigem === cidadeDestino) return await sendWarningReply("⚠️ A cidade de origem e destino não podem ser a mesma.");
      if (db[remoteJid][participant].rotas.emViagem) return await sendWarningReply("⚠️ Sua caravana já está em viagem. Aguarde a chegada para enviar outra.");

      const recurso = RECURSOS[recursoKey];
      const origem = CIDADES[cidadeOrigem];
      const destino = CIDADES[cidadeDestino];
      const precoCompra = origem.precoBase[recursoKey];
      const precoVenda = destino.precoBase[recursoKey];

      if ((db[remoteJid][participant].inventario[recursoKey] || 0) < quantidade) {
        return await sendWarningReply(`⚠️ Você não possui ${quantidade}x *${recurso.nome}* em seu inventário.`);
      }

      // Calcula tempo de viagem (ex: 10 minutos por cidade de distância)
      const tempoViagem = 30 * 60 * 1000; // Exemplo: 30 minutos fixos por rota

      db[remoteJid][participant].inventario[recursoKey] -= quantidade;
      db[remoteJid][participant].rotas.emViagem = {
        recurso: recursoKey,
        quantidade: quantidade,
        origem: cidadeOrigem,
        destino: cidadeDestino,
        precoVenda: precoVenda,
        partida: agora,
        chegada: agora + tempoViagem
      };
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`🚚 *CARAVANA ENVIADA!*\nSua caravana partiu de *${origem.nome}* com ${quantidade}x *${recurso.nome}* para *${destino.nome}*! Chegará em ${tempoViagem / (60 * 1000)} minutos.`);
    }

    if (acao === "status") {
      if (!db[remoteJid][participant].rotas.emViagem) return await sendReply("Você não tem nenhuma caravana em viagem.");
      const viagem = db[remoteJid][participant].rotas.emViagem;
      const tempoRestante = Math.ceil((viagem.chegada - agora) / (60 * 1000));
      return await sendReply(`🚚 *STATUS DA CARAVANA* 🚚\n\nRecurso: *${RECURSOS[viagem.recurso].nome}*\nQuantidade: *${viagem.quantidade}*\nOrigem: *${CIDADES[viagem.origem].nome}*\nDestino: *${CIDADES[viagem.destino].nome}*\nChegada em: *${tempoRestante} minutos*`);
    }
  }
};
