import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "bancoguilda",
    description: "Sistema financeiro avançado para guildas.",
    commands: ["bguilda", "investirguilda"],
    usage: `${PREFIX}bguilda`,
    handle: async ({ sendReply }) => {
        return await sendReply("🏢 *BANCO DAS CORPORAÇÕES* 🏢\nGerencie o capital da sua guilda e invista em melhorias!");
    }
};
