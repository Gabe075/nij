import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "pesca",
  description: "Vá pescar e tente a sorte para pegar peixes raros ou tesouros afundados.",
  commands: ["pesca", "pescar", "rio"],
  usage: `${PREFIX}pesca`,
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    
    const agora = Date.now();
    const tempoEspera = 10 * 60 * 1000; // 10 minutos
    
    if (db[remoteJid][participant].ultimaPesca) {
      const tempoPassado = agora - db[remoteJid][participant].ultimaPesca;
      if (tempoPassado < tempoEspera) {
        const minutosRestantes = Math.ceil((tempoEspera - tempoPassado) / 60000);
        return await sendReply(`🎣 *Seu anzol está vazio!* Aguarde *${minutosRestantes} minutos* antes de pescar novamente.`);
      }
    }
    
    const custoPesca = 50; // Custa 50 réis para pescar
    if (db[remoteJid][participant].saldo < custoPesca) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoPesca} Réis* para comprar iscas.`);
    }
    
    db[remoteJid][participant].saldo -= custoPesca;
    db[remoteJid][participant].ultimaPesca = agora;
    
    const sorte = Math.floor(Math.random() * 100);
    let ganho = 0;
    let msg = "";
    
    if (sorte < 50) { // 50% de chance de pegar peixe comum
      ganho = Math.floor(Math.random() * 100) + 50;
      msg = `🎣 Você pescou um *Peixe Comum*! Ele foi vendido por *${ganho} Réis*.`;
    } else if (sorte < 80) { // 30% de chance de pegar peixe raro
      ganho = Math.floor(Math.random() * 300) + 150;
      msg = `🎣 Que sorte! Você pescou um *Peixe Raro*! Ele foi vendido por *${ganho} Réis*.`;
    } else if (sorte < 95) { // 15% de chance de pegar peixe lendário
      ganho = Math.floor(Math.random() * 800) + 400;
      msg = `🎣 INCRÍVEL! Você pescou um *Peixe Lendário*! Ele foi vendido por *${ganho} Réis*.`;
    } else { // 5% de chance de achar um tesouro afundado
      ganho = Math.floor(Math.random() * 2000) + 1000;
      msg = `💎 *TESOURO AFUNDADO!* 💎\nVocê puxou um baú antigo do fundo do rio, contendo *${ganho} Réis*!`;
    }
    
    db[remoteJid][participant].saldo += ganho;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    
    if (ganho > 0) {
      return await sendSuccessReply(msg);
    } else {
      return await sendReply(msg);
    }
  }
};
