import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const DESTINOS = {
  "portugal": {
    nome: "Portugal 🇵🇹",
    custo: 5000,
    tempoViagem: 2 * 60 * 60 * 1000, // 2 horas
    eventos: [
      { tipo: "ganho", min: 1000, max: 3000, chance: 60, msg: "Você fez ótimos negócios em Lisboa e ganhou Réis!" },
      { tipo: "perda", min: 500, max: 1500, chance: 30, msg: "Seu navio foi atacado por piratas e você perdeu Réis!" },
      { tipo: "nada", chance: 10, msg: "A viagem foi tranquila, mas sem grandes emoções." }
    ]
  },
  "africa": {
    nome: "África 🌍",
    custo: 15000,
    tempoViagem: 4 * 60 * 60 * 1000, // 4 horas
    eventos: [
      { tipo: "ganho", min: 5000, max: 10000, chance: 50, msg: "Você descobriu novas rotas comerciais e lucrou muito!" },
      { tipo: "perda", min: 2000, max: 5000, chance: 40, msg: "Você contraiu uma doença tropical e gastou muito com curandeiros!" },
      { tipo: "nada", chance: 10, msg: "A expedição foi cansativa, mas sem grandes percalços." }
    ]
  },
  "indias": {
    nome: "Índias 🇮🇳",
    custo: 30000,
    tempoViagem: 8 * 60 * 60 * 1000, // 8 horas
    eventos: [
      { tipo: "ganho", min: 15000, max: 30000, chance: 40, msg: "Você negociou especiarias raras e ficou rico!" },
      { tipo: "perda", min: 8000, max: 15000, chance: 50, msg: "Seu navio afundou em uma tempestade e você perdeu tudo!" },
      { tipo: "nada", chance: 10, msg: "A longa jornada foi exaustiva, mas sem incidentes notáveis." }
    ]
  }
};

export default {
  name: "viagens",
  description: "Viaje para outros reinos, enfrente desafios e descubra novas oportunidades.",
  commands: ["viagem", "viajar", "explorar"],
  usage: `${PREFIX}viagem`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const destinoKey = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    const agora = Date.now();

    if (!acao || acao === "ajuda") {
      let menu = `✈️ *VIAGENS IMPERIAIS* ✈️\n\n`;
      menu += `Explore o mundo, mas esteja preparado para o inesperado!\n\n`;
      
      for (const [key, dest] of Object.entries(DESTINOS)) {
        menu += `🌎 *${dest.nome}*\n`;
        menu += `   ↳ Custo da Viagem: ${dest.custo} Réis\n`;
        menu += `   ↳ Tempo de Viagem: ${dest.tempoViagem / (60 * 60 * 1000)} horas\n`;
        menu += `🗺️ *${PREFIX}viagem ir ${key}*\n\n`;
      }
      
      if (db[remoteJid][participant].viagemAtiva) {
        const dest = DESTINOS[db[remoteJid][participant].viagemAtiva.destino];
        const tempoRestante = Math.ceil((db[remoteJid][participant].viagemAtiva.chegada - agora) / (60 * 1000));
        menu += `_Você está atualmente viajando para ${dest.nome}. Chegada em ${tempoRestante} minutos._`;
      }
      return await sendReply(menu);
    }

    if (acao === "ir") {
      if (!DESTINOS[destinoKey]) return await sendWarningReply(`⚠️ Destino inválido!`);
      const destino = DESTINOS[destinoKey];

      if (db[remoteJid][participant].viagemAtiva) {
        return await sendWarningReply("⚠️ Você já está em uma viagem! Aguarde a chegada para iniciar outra.");
      }
      
      if (db[remoteJid][participant].saldo < destino.custo) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${destino.custo} Réis* para viajar para *${destino.nome}*.`);
      }
      
      db[remoteJid][participant].saldo -= destino.custo;
      db[remoteJid][participant].viagemAtiva = {
        destino: destinoKey,
        partida: agora,
        chegada: agora + destino.tempoViagem
      };
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✈️ *VIAGEM INICIADA!*\nVocê partiu para *${destino.nome}*! Chegará em ${destino.tempoViagem / (60 * 60 * 1000)} horas. Boa sorte!`);
    }

    // Verifica chegada e processa evento
    if (db[remoteJid][participant].viagemAtiva && db[remoteJid][participant].viagemAtiva.chegada <= agora) {
      const viagem = db[remoteJid][participant].viagemAtiva;
      const destino = DESTINOS[viagem.destino];
      
      let eventoEscolhido = null;
      let totalChance = 0;
      destino.eventos.forEach(e => totalChance += e.chance);

      let randomNum = Math.floor(Math.random() * totalChance);
      for (const evento of destino.eventos) {
        if (randomNum < evento.chance) {
          eventoEscolhido = evento;
          break;
        }
        randomNum -= evento.chance;
      }

      let msgEvento = ``;
      if (eventoEscolhido) {
        if (eventoEscolhido.tipo === "ganho") {
          const ganho = Math.floor(Math.random() * (eventoEscolhido.max - eventoEscolhido.min)) + eventoEscolhido.min;
          db[remoteJid][participant].saldo += ganho;
          msgEvento = `\n💰 *Resultado:* ${eventoEscolhido.msg} Você ganhou *${ganho} Réis*!`;
        } else if (eventoEscolhido.tipo === "perda") {
          const perda = Math.floor(Math.random() * (eventoEscolhido.max - eventoEscolhido.min)) + eventoEscolhido.min;
          db[remoteJid][participant].saldo = Math.max(0, db[remoteJid][participant].saldo - perda);
          msgEvento = `\n💸 *Resultado:* ${eventoEscolhido.msg} Você perdeu *${perda} Réis*!`;
        } else {
          msgEvento = `\n✨ *Resultado:* ${eventoEscolhido.msg}`;
        }
      }

      delete db[remoteJid][participant].viagemAtiva;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendReply(`🎉 *CHEGADA AO DESTINO!* 🎉\nVocê chegou em *${destino.nome}*!${msgEvento}`);
    }
  }
};
