import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js"; // Ajuste os '../' se necessário

const levelsPath = path.resolve("database", "levels.json");
const ecoPath = path.resolve("database", "economia.json");

// A mesma função de títulos de nobreza que você criou
function getTituloNobreza(level) {
  if (level < 5) return "Plebeu 🧑‍🌾";
  if (level < 10) return "Escudeiro 🛡️";
  if (level < 15) return "Cavaleiro ⚔️";
  if (level < 20) return "Barão 🎩";
  if (level < 30) return "Visconde 🧐";
  if (level < 40) return "Conde 🍷";
  if (level < 50) return "Marquês 📜";
  if (level < 70) return "Duque 🏰";
  return "Grão-Duque 👑";
}

export default {
  name: "ranking",
  description: "Mostra os membros mais ricos e de maior nível do grupo.",
  commands: ["rank", "ranking", "top", "corte"],
  usage: `${PREFIX}ranking`,
  
  handle: async ({ sendReply, remoteJid, isGroup }) => {
    if (!isGroup) {
      return await sendReply("⚠️ Este comando só funciona em grupos.");
    }

    let rankMessage = "🏆 *PLACAR DO IMPÉRIO* 🏆\n\n";
    const mentions = [];

    // ==========================================
    // 🌟 RANKING DE XP (CORTE IMPERIAL)
    // ==========================================
    rankMessage += "🌟 *TOP 5 - CORTE IMPERIAL (XP)* 🌟\n";
    if (fs.existsSync(levelsPath)) {
      const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      const groupLevels = levelsDB[remoteJid] || {};
      
      const sortedLevels = Object.entries(groupLevels)
        .map(([jid, data]) => ({ jid, xp: data.xp, level: data.level }))
        .sort((a, b) => b.xp - a.xp)
        .slice(0, 5); // Pega o Top 5 para não ficar gigante

      if (sortedLevels.length === 0) {
        rankMessage += "_Nenhum registro de XP ainda._\n";
      } else {
        sortedLevels.forEach((user, index) => {
          let medal = ["🥇", "🥈", "🥉", "🏅", "🏅"][index];
          const titulo = getTituloNobreza(user.level);
          
          rankMessage += `${medal} ${index + 1}º - @${user.jid.split("@")[0]}\n`;
          rankMessage += `   👑 ${titulo} | Lvl: ${user.level} | XP: ${user.xp}\n`;
          
          if (!mentions.includes(user.jid)) mentions.push(user.jid);
        });
      }
    } else {
      rankMessage += "_Nenhum registro de XP ainda._\n";
    }

    rankMessage += "\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n";

    // ==========================================
    // 💰 RANKING DE ECONOMIA (MAGNATAS)
    // ==========================================
    rankMessage += "💰 *TOP 5 - MAGNATAS (FORTUNA)* 💰\n";
    if (fs.existsSync(ecoPath)) {
      const ecoDB = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
      const groupEco = ecoDB[remoteJid] || {};
      
      const sortedEco = Object.entries(groupEco)
        .map(([jid, data]) => {
          const saldo = data.saldo || 0;
          const banco = data.banco || 0;
          return { jid, total: saldo + banco }; // Soma carteira + banco
        })
        .filter(user => user.total > 0) // Só mostra quem tem mais de 0 Réis
        .sort((a, b) => b.total - a.total)
        .slice(0, 5);

      if (sortedEco.length === 0) {
        rankMessage += "_Nenhum registro de fortuna ainda._\n";
      } else {
        sortedEco.forEach((user, index) => {
          let medal = ["💎", "🥇", "🥈", "🥉", "🏅"][index];
          
          rankMessage += `${medal} ${index + 1}º - @${user.jid.split("@")[0]}\n`;
          rankMessage += `   🏦 Patrimônio: ${user.total} Réis\n`;
          
          if (!mentions.includes(user.jid)) mentions.push(user.jid);
        });
      }
    } else {
      rankMessage += "_Nenhum registro de fortuna ainda._\n";
    }

    await sendReply(rankMessage, mentions);
  },
};
