import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const TITULOS = {
    "barao": { nome: "Barão/Baronesa", custo: 100000, bonusTrabalho: 1.1 },
    "visconde": { nome: "Visconde/Viscondessa", custo: 250000, bonusTrabalho: 1.25 },
    "conde": { nome: "Conde/Condessa", custo: 500000, bonusTrabalho: 1.5 },
    "marques": { nome: "Marquês/Marquesa", custo: 1000000, bonusTrabalho: 2.0 },
    "duque": { nome: "Duque/Duquesa", custo: 5000000, bonusTrabalho: 3.0 }
};

export default {
    name: "nobreza",
    description: "Adquira títulos de nobreza e ganhe prestígio e bônus.",
    commands: ["nobreza", "titulos", "comprartitulo"],
    usage: `${PREFIX}nobreza`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
        if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
        const participant = webMessage.key.participant || remoteJid;
        
        let db = {};
        if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
        
        // Trava Undefined
        if (!db[remoteJid]) db[remoteJid] = {};
        if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, nobreza: "Plebeu" };
        
        const user = db[remoteJid][participant];
        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        if (!acao || acao === "lista") {
            let msg = `👑 *ORDEM DA NOBREZA IMPERIAL* 👑\n\n`;
            msg += `Seu título atual: *${user.nobreza || "Plebeu"}*\n\n`;
            for (const [key, t] of Object.entries(TITULOS)) {
                msg += `🔹 *${t.nome}*\n`;
                msg += `   ↳ Custo: 💰 ${t.custo.toLocaleString()} Réis\n`;
                msg += `   ↳ Bônus: +${Math.round((t.bonusTrabalho - 1) * 100)}% de salário\n`;
                msg += `🛒 *${PREFIX}nobreza comprar ${key}*\n\n`;
            }
            return await sendReply(msg);
        }

        if (acao === "comprar") {
            const tituloKey = parts[1]?.toLowerCase();
            if (!TITULOS[tituloKey]) return await sendWarningReply("⚠️ Título inválido!");
            
            const titulo = TITULOS[tituloKey];
            if (user.saldo < titulo.custo) return await sendWarningReply(`💸 Saldo insuficiente! Você precisa de ${titulo.custo.toLocaleString()} Réis.`);
            
            user.saldo -= titulo.custo;
            user.nobreza = titulo.nome;
            user.bonusNobreza = titulo.bonusTrabalho;
            
            fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
            return await sendSuccessReply(`🎉 *DECRETO REAL!* 🎉\nAgora você é oficialmente um(a) *${titulo.nome}* do Império!`);
        }
    }
};
