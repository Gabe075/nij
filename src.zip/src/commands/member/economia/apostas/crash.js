import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js";

const ecoPath = path.resolve("database", "economia.json");
const delay = (ms) => new Promise(res => setTimeout(res, ms));

export default {
  name: "crash",
  description: "Aposte no multiplicador antes que o gráfico exploda!",
  commands: ["crash"],
  usage: `${PREFIX}crash <valor> <alvo>`,
  
  handle: async ({ fullArgs, sendReply, sendEditedReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    
    if (parts.length < 2) {
      return await sendWarningReply(`Uso incorreto!\nExemplo: *${PREFIX}crash 50 2.0*\n_(Aposta 50 Réis para tentar tirar no multiplicador 2.0x)_`);
    }

    const aposta = parseInt(parts[0].replace(/[^0-9]/g, ""), 10);
    const alvo = parseFloat(parts[1].replace(",", "."));

    if (isNaN(aposta) || aposta <= 0) return await sendWarningReply("Valor de aposta inválido.");
    if (isNaN(alvo) || alvo <= 1.0) return await sendWarningReply("O alvo deve ser maior que 1.0x.");

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (db[remoteJid][participant].saldo < aposta) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
    }

    // Desconta a aposta
    db[remoteJid][participant].saldo -= aposta;

    // Lógica do Crash
    const chance = Math.random();
    let crashPoint = 1.0;
    
    if (chance < 0.05) {
      crashPoint = 1.0; 
    } else {
      crashPoint = (1 / (1 - chance * 0.9)); 
      if (crashPoint > 15.0) crashPoint = 15.0 + (Math.random() * 5); 
    }
    crashPoint = parseFloat(crashPoint.toFixed(2));

    // 🚀 ANIMAÇÃO DO FOGUETE (Edição de Mensagem)
    let currentMult = 1.0;
    let msgInfo = await sendReply(`🚀 ━━━ 𝐂𝐑𝐀𝐒𝐇 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋 ━━━ 🚀\n\n💰 Aposta: *${aposta} Réis*\n🎯 Alvo: *${alvo.toFixed(2)}x*\n\n📈 Multiplicador: *1.00x*...`);

    const steps = 3; // Faz 3 edições para não tomar block do WhatsApp por spam
    const targetAnim = Math.min(alvo, crashPoint);
    const stepValue = (targetAnim - 1.0) / steps;

    if (crashPoint > 1.0) {
        for (let i = 1; i <= steps; i++) {
            await delay(1200); // Espera 1.2 segundos entre cada edição
            currentMult += stepValue;
            if (currentMult > targetAnim) currentMult = targetAnim;
            
            msgInfo = await sendEditedReply(`🚀 ━━━ 𝐂𝐑𝐀𝐒𝐇 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋 ━━━ 🚀\n\n💰 Aposta: *${aposta} Réis*\n🎯 Alvo: *${alvo.toFixed(2)}x*\n\n📈 Multiplicador: *${currentMult.toFixed(2)}x*...`, msgInfo);
        }
    }
    
    await delay(1000);

    // 💥 RESULTADO FINAL
    let finalMsg = `💥 ━━━ 𝐂𝐑𝐀𝐒𝐇 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋 ━━━ 💥\n\n`;
    finalMsg += `💰 Aposta: *${aposta} Réis*\n`;
    finalMsg += `🎯 Alvo: *${alvo.toFixed(2)}x*\n`;
    finalMsg += `📉 Explodiu em: *${crashPoint.toFixed(2)}x*\n\n`;

    if (crashPoint >= alvo) {
      const lucro = Math.floor(aposta * alvo);
      db[remoteJid][participant].saldo += lucro;
      finalMsg += `🚀 *SUCESSO!*\nVocê retirou a tempo e ganhou *${lucro} Réis*!\n`;
    } else {
      finalMsg += `💥 *KABUM!*\nVocê foi ganancioso e perdeu *${aposta} Réis*.\n`;
    }

    finalMsg += `🏦 Saldo atual: *${db[remoteJid][participant].saldo} Réis*`;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    addProgressoMissao(remoteJid, participant, "jogar_cassino");

    await sendEditedReply(finalMsg, msgInfo);
  }
};
