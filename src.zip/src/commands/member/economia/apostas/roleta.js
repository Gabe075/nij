import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "roleta",
  description: "Aposte na roleta imperial (cores ou números).",
  commands: ["roleta", "roulette"],
  usage: `${PREFIX}roleta <cor/numero> <valor>`,
  
  handle: async ({ args, sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    if (args.length < 2) {
      let ajuda = `🎡 *COMO JOGAR NA ROLETA* 🎡\n\n`;
      ajuda += `Escolha onde apostar e o valor:\n`;
      ajuda += `🔸 *Cores:* vermelho (2x), preto (2x), verde (14x)\n`;
      ajuda += `🔸 *Números:* 0 a 36 (35x)\n\n`;
      ajuda += `Exemplos:\n*${PREFIX}roleta vermelho 50*\n*${PREFIX}roleta 17 100*`;
      return await sendWarningReply(ajuda);
    }

    const apostaTipo = args[0].toLowerCase();
    const apostaValor = parseInt(args[1].replace(/[^0-9]/g, ""), 10);

    if (isNaN(apostaValor) || apostaValor <= 0) {
      return await sendWarningReply("⚠️ Digite um valor válido para apostar.");
    }

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (db[remoteJid][participant].saldo < apostaValor) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
    }

    // Sorteia um número de 0 a 36
    const numeroSorteado = Math.floor(Math.random() * 37);
    let corSorteada = "";

    if (numeroSorteado === 0) {
      corSorteada = "verde";
    } else if (numeroSorteado % 2 === 0) {
      corSorteada = "preto";
    } else {
      corSorteada = "vermelho";
    }

    let ganhou = false;
    let multiplicador = 0;

    // Verifica se apostou em cor
    if (["vermelho", "preto", "verde", "red", "black", "green"].includes(apostaTipo)) {
      const corApostada = apostaTipo.replace("red", "vermelho").replace("black", "preto").replace("green", "verde");
      if (corApostada === corSorteada) {
        ganhou = true;
        multiplicador = corSorteada === "verde" ? 14 : 2;
      }
    } 
    // Verifica se apostou em número
    else if (!isNaN(parseInt(apostaTipo, 10))) {
      const numeroApostado = parseInt(apostaTipo, 10);
      if (numeroApostado >= 0 && numeroApostado <= 36) {
        if (numeroApostado === numeroSorteado) {
          ganhou = true;
          multiplicador = 35;
        }
      } else {
        return await sendWarningReply("⚠️ Escolha um número entre 0 e 36.");
      }
    } else {
      return await sendWarningReply("⚠️ Aposta inválida. Escolha uma cor (vermelho/preto/verde) ou um número (0-36).");
    }

    let emojiCor = corSorteada === "vermelho" ? "🔴" : corSorteada === "preto" ? "⚫" : "🟢";
    let resultadoMsg = `🎯 Resultado: ${emojiCor} *${corSorteada.toUpperCase()}* (Nº ${numeroSorteado})\n\n`;

    if (ganhou) {
      const lucro = apostaValor * multiplicador;
      db[remoteJid][participant].saldo += (lucro - apostaValor);
      resultadoMsg += `🎉 *VITÓRIA!* Você ganhou *${lucro} Réis*!`;
    } else {
      db[remoteJid][participant].saldo -= apostaValor;
      resultadoMsg += `❌ *DERROTA!* O banco levou seus *${apostaValor} Réis*.`;
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, participant, "jogar_cassino");

    await sendReply(`🎡 *ROLETA IMPERIAL* 🎡\n\n${resultadoMsg}\n🏦 Saldo atual: *${db[remoteJid][participant].saldo} Réis*`);
  }
};
