import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "slots",
  description: "Aposte seus Réis no caça-níqueis.",
  commands: ["slots", "cacaniqueis", "cassino"],
  usage: `${PREFIX}slots <valor>`,
  
  handle: async ({ args, sendReply, sendWarningReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    if (!args.length) {
      return await sendWarningReply(`⚠️ Digite o valor da aposta.\nExemplo: *${PREFIX}slots 50*`);
    }

    const aposta = parseInt(args[0].replace(/[^0-9]/g, ""), 10);

    if (isNaN(aposta) || aposta <= 0) {
      return await sendWarningReply("⚠️ Digite um valor válido para apostar.");
    }

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (db[remoteJid][participant].saldo < aposta) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
    }

    // Sorteio dos Emojis
    const emojis = ["🍒", "🍋", "🍉", "🔔", "💎", "7️⃣"];
    const slot1 = emojis[Math.floor(Math.random() * emojis.length)];
    const slot2 = emojis[Math.floor(Math.random() * emojis.length)];
    const slot3 = emojis[Math.floor(Math.random() * emojis.length)];

    let multiplicador = 0;
    let resultadoMsg = "";

    if (slot1 === slot2 && slot2 === slot3) {
      multiplicador = 10; // Jackpot (3 iguais)
      resultadoMsg = `🎰 *JACKPOT!* Você tirou 3 iguais!\nVocê ganhou *${aposta * multiplicador} Réis*!`;
    } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
      multiplicador = 2; // Dois iguais
      resultadoMsg = `🎉 *BOM!* Você tirou 2 iguais.\nVocê ganhou *${aposta * multiplicador} Réis*!`;
    } else {
      multiplicador = 0; // Perdeu
      resultadoMsg = `❌ *PERDEU!* Deu tudo diferente.\nO banco agradece seus *${aposta} Réis*.`;
    }

    // Atualiza o saldo
    if (multiplicador > 0) {
      db[remoteJid][participant].saldo += (aposta * multiplicador) - aposta; 
    } else {
      db[remoteJid][participant].saldo -= aposta; 
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, participant, "jogar_cassino");

    const msg = `🎰 *CASSINO IMPERIAL* 🎰\n\n[ ${slot1} | ${slot2} | ${slot3} ]\n\n${resultadoMsg}\n🏦 Saldo atual: *${db[remoteJid][participant].saldo} Réis*`;
    await sendReply(msg);
  }
};
