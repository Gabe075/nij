import fs from "fs";
import path from "path";
import { delay } from "baileys";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "copos",
  description: "Adivinhe em qual copo está a bolinha.",
  commands: ["copos", "copo", "bolinha"],
  usage: `${PREFIX}copos <1|2|3> <valor>`,
  
  handle: async ({ fullArgs, sendReply, sendEditedText, remoteJid, webMessage }) => {
    
    const params = fullArgs ? fullArgs.trim().split(/\s+/) : [];

    if (params.length < 2) {
      return await sendReply(`⚠️ *Como jogar:*\nEscolha um copo (1, 2 ou 3) e o valor da aposta.\nExemplo: *${PREFIX}copos 2 50* (Aposta 50 Réis no copo 2)`);
    }

    const palpite = parseInt(params[0]);
    const aposta = parseInt(params[1]);

    if (isNaN(palpite) || palpite < 1 || palpite > 3) {
      return await sendReply("⚠️ Escolha um copo válido: *1, 2 ou 3*!");
    }

    if (isNaN(aposta) || aposta <= 0) {
      return await sendReply("⚠️ O valor da aposta deve ser maior que zero!");
    }

    if (!fs.existsSync(ecoPath)) {
      return await sendReply("🏦 O Banco Imperial ainda está vazio. Digite `/diario` para começar!");
    }

    const db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    const participant = webMessage.key.participant || remoteJid;

    if (!db[remoteJid] || !db[remoteJid][participant] || db[remoteJid][participant].saldo < aposta) {
      const saldoAtual = db[remoteJid]?.[participant]?.saldo || 0;
      return await sendReply(`💸 Você não tem Réis suficientes para essa aposta!\nSeu saldo: *${saldoAtual} Réis*.`);
    }

    // 1. Cobra a aposta
    db[remoteJid][participant].saldo -= aposta;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // Layout Base
    const header = `🥤 ━━━ 𝐉𝐎𝐆𝐎 𝐃𝐎𝐒 𝐂𝐎𝐏𝐎𝐒 ━━━ 🥤\n\n💰 Aposta: *${aposta} Réis*\n🎯 Seu palpite: *Copo ${palpite}*\n`;

    // 2. Inicia a animação
    let msg = await sendReply(`${header}\nEscondendo a bolinha...\n[ 🥤 ]   [ 🥤 ]   [ 🥤 ]\n   1️⃣        2️⃣        3️⃣`);

    await delay(1000);
    msg = await sendEditedText(`${header}\nEmbaralhando...\n[ 🔄 ]   [ 🔄 ]   [ 🔄 ]\n   1️⃣        2️⃣        3️⃣`, msg);

    await delay(1000);
    msg = await sendEditedText(`${header}\nMais rápido...\n[ 💫 ]   [ 💫 ]   [ 💫 ]\n   1️⃣        2️⃣        3️⃣`, msg);

    await delay(1200);

    // 3. Sorteia o copo vencedor (1, 2 ou 3)
    const copoSorteado = Math.floor(Math.random() * 3) + 1;

    // Monta o visual final revelando a bolinha
    let coposVisuais = ["🥤", "🥤", "🥤"];
    coposVisuais[copoSorteado - 1] = "🔴"; // Coloca a bolinha no copo sorteado

    // 4. Calcula o resultado
    let textoResultado = "";
    if (palpite === copoSorteado) {
      const premio = Math.floor(aposta * 2.5); // Paga 2.5x a aposta
      db[remoteJid][participant].saldo += premio;
      textoResultado = `🎉 *NA MOSCA!*\nA bolinha estava no copo ${copoSorteado}!\nVocê ganhou *${premio} Réis*!`;
    } else {
      textoResultado = `❌ *ERROU!*\nA bolinha estava no copo ${copoSorteado}.\nO ilusionista levou seus *${aposta} Réis*.`;
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    const saldoFinal = db[remoteJid][participant].saldo;

    // 5. Edita para o resultado final
    await sendEditedText(`${header}\n[ ${coposVisuais[0]} ]   [ ${coposVisuais[1]} ]   [ ${coposVisuais[2]} ]\n   1️⃣        2️⃣        3️⃣\n\n${textoResultado}\n🏦 Saldo atual: *${saldoFinal} Réis*`, msg);
  }
};
