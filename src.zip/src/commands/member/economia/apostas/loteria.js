import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const loteriaPath = path.resolve("database", "loteria.json");

export default {
  name: "loteria",
  description: "Compre um bilhete quando o evento relâmpago estiver aberto.",
  commands: ["loteria", "rifa"],
  usage: `${PREFIX}loteria comprar`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const args = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = args[0]?.toLowerCase();

    let loteriaDB = { global: { status: "fechado", participantes: [] } };
    if (fs.existsSync(loteriaPath)) loteriaDB = JSON.parse(fs.readFileSync(loteriaPath, "utf-8"));

    const PRECO_BILHETE = 100;

    // 📜 INFO DA LOTERIA
    if (!acao || acao === "info") {
      if (loteriaDB.global.status === "fechado") {
        return await sendReply(`🎟️ *LOTERIA IMPERIAL* 🎟️\n\nAs vendas de bilhetes estão *FECHADAS* no momento.\nFique atento! O bot anunciará aleatoriamente 3 vezes ao dia quando um novo sorteio relâmpago começar.`);
      }

      const tempoRestante = Math.max(0, Math.ceil((loteriaDB.global.fechamento - Date.now()) / 60000));
      const qtd = loteriaDB.global.participantes.length;
      
      let msg = `🎟️ *LOTERIA IMPERIAL (ABERTA)* 🎟️\n\n`;
      msg += `⏳ *Tempo Restante:* ${tempoRestante} minutos\n`;
      msg += `👥 *Participantes:* ${qtd} pessoas\n\n`;
      msg += `Compre seu bilhete por *${PRECO_BILHETE} Réis* e concorra a até *10.000 Réis*!\n`;
      msg += `👉 Digite: *${PREFIX}loteria comprar*`;
      return await sendReply(msg);
    }

    // 🎟️ COMPRAR BILHETE
    if (acao === "comprar") {
      if (loteriaDB.global.status === "fechado") {
        return await sendWarningReply("⚠️ A loteria está fechada! Aguarde o próximo anúncio do bot.");
      }

      // Verifica se já comprou
      const jaComprou = loteriaDB.global.participantes.some(p => p.jid === participant && p.grupo === remoteJid);
      if (jaComprou) {
        return await sendWarningReply("⚠️ Você já comprou um bilhete para este sorteio! Aguarde o resultado.");
      }

      let db = {};
      if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
      if (!db[remoteJid]) db[remoteJid] = {};
      if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

      if (db[remoteJid][participant].saldo < PRECO_BILHETE) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nO bilhete custa *${PRECO_BILHETE} Réis*.`);
      }

      // Desconta e adiciona na lista
      db[remoteJid][participant].saldo -= PRECO_BILHETE;
      loteriaDB.global.participantes.push({ jid: participant, grupo: remoteJid });

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(loteriaPath, JSON.stringify(loteriaDB, null, 2));

      return await sendSuccessReply(`🎟️ *BILHETE COMPRADO!*\n\nVocê entrou para o sorteio relâmpago! Boa sorte.\nO resultado sairá automaticamente quando o tempo acabar.`);
    }
  }
};
