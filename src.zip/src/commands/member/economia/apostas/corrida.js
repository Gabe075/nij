import fs from "fs";
import path from "path";
import { delay } from "baileys";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

// Função para desenhar a pista de corrida
function renderizarPista(progresso) {
  let pista = "";
  for (let i = 0; i < 4; i++) {
    let p = progresso[i];
    if (p > 10) p = 10; // Limite da linha de chegada
    let rastro = "=".repeat(p);
    let caminho = "-".repeat(10 - p);
    pista += `${i + 1}️⃣ [${rastro}🐎${caminho}] 🏁\n`;
  }
  return pista;
}

export default {
  name: "corrida",
  description: "Aposte em um cavalo na Corrida Imperial.",
  commands: ["corrida", "cavalo", "jockey"],
  usage: `${PREFIX}corrida <numero_do_cavalo> <valor>`,
  
  handle: async ({ fullArgs, sendReply, sendEditedText, remoteJid, webMessage }) => {
    
    // Separa a frase por espaços
    const params = fullArgs ? fullArgs.trim().split(/\s+/) : [];

    if (params.length < 2) {
      return await sendReply(`⚠️ *Como jogar:*\nEscolha um cavalo (1 a 4) e o valor da aposta.\nExemplo: *${PREFIX}corrida 2 50* (Aposta 50 Réis no cavalo 2)`);
    }

    const cavaloEscolhido = parseInt(params[0]);
    const aposta = parseInt(params[1]);

    if (isNaN(cavaloEscolhido) || cavaloEscolhido < 1 || cavaloEscolhido > 4) {
      return await sendReply("⚠️ Escolha um cavalo válido entre 1 e 4!");
    }

    if (isNaN(aposta) || aposta <= 0) {
      return await sendReply("⚠️ O valor da aposta deve ser maior que zero!");
    }

    if (!fs.existsSync(ecoPath)) {
      return await sendReply("🏦 O Banco Imperial ainda está vazio. Digite `/diario` para começar!");
    }

    const db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    const participant = webMessage.key.participant || remoteJid;

    if (!db[remoteJid] || !db[remoteJid][participant] || db[remoteJid][participant].saldo < aposta) {
      const saldoAtual = db[remoteJid]?.[participant]?.saldo || 0;
      return await sendReply(`💸 Você não tem Réis suficientes para essa aposta!\nSeu saldo: *${saldoAtual} Réis*.`);
    }

    // 1. Cobra a aposta
    db[remoteJid][participant].saldo -= aposta;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 2. Inicia a corrida
    let progresso = [0, 0, 0, 0];
    let msg = await sendReply(`🏇 *GRANDE PRÊMIO IMPERIAL* 🏇\n\nAs portas se abriram! Você apostou ${aposta} Réis no Cavalo ${cavaloEscolhido}.\n\n${renderizarPista(progresso)}`);

    let vencedor = -1;
    let corridaRolando = true;

    // 3. Loop da animação (Os cavalos andam)
    while (corridaRolando) {
      await delay(1500); // Espera 1.5s entre cada "passo"

      // Faz cada cavalo andar um valor aleatório (0 a 3 casas)
      for (let i = 0; i < 4; i++) {
        progresso[i] += Math.floor(Math.random() * 4);
        if (progresso[i] >= 10) {
          corridaRolando = false;
        }
      }

      // Se alguém cruzou a linha, descobre quem foi o que foi mais longe
      if (!corridaRolando) {
        let maxProgresso = -1;
        for (let i = 0; i < 4; i++) {
          if (progresso[i] > maxProgresso) {
            maxProgresso = progresso[i];
            vencedor = i + 1; // Cavalos são 1, 2, 3, 4
          }
        }
      }

      // Atualiza a tela
      let status = corridaRolando ? "Os cavalos estão na pista!..." : `🏆 O Cavalo ${vencedor} cruzou a linha de chegada!`;
      msg = await sendEditedText(`🏇 *GRANDE PRÊMIO IMPERIAL* 🏇\n\n${status}\n\n${renderizarPista(progresso)}`, msg);
    }

    await delay(1000);

    // 4. Calcula o resultado
    let textoResultado = "";
    if (vencedor === cavaloEscolhido) {
      const premio = aposta * 3; // Paga 3x o valor apostado!
      db[remoteJid][participant].saldo += premio;
      textoResultado = `🎉 *VITÓRIA!* Seu cavalo ganhou a corrida!\nVocê recebeu *${premio} Réis*!`;
    } else {
      textoResultado = `❌ *DERROTA!* Seu cavalo comeu poeira.\nO banco agradece seus *${aposta} Réis*.`;
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    const saldoFinal = db[remoteJid][participant].saldo;

    // 5. Edita para o resultado final
    await sendEditedText(`🏇 *GRANDE PRÊMIO IMPERIAL* 🏇\n\n🏆 O Cavalo ${vencedor} venceu a corrida!\n\n${renderizarPista(progresso)}\n${textoResultado}\n🏦 Saldo atual: *${saldoFinal} Réis*`, msg);
  }
};
