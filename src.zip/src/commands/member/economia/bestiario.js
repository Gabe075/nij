import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "bestiario",
    description: "Catálogo de todos os animais e pets do império.",
    commands: ["bestiario", "animais"],
    usage: `${PREFIX}bestiario`,
    handle: async ({ sendReply }) => {
        return await sendReply("🐾 *BESTIÁRIO IMPERIAL* 🐾\nConheça todas as criaturas que habitam o Brazil!");
    }
};
