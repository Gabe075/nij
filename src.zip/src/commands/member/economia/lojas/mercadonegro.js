import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");

const ITENS_ILEGAIS = {
  "fumaca": { nome: "🧨 Bomba de Fumaça", preco: 1500, desc: "Destrói o Escudo Imperial da vítima automaticamente no !roubar." },
  "informante": { nome: "🕵️ Contrato de Informante", preco: 1000, desc: "Descobre o saldo e o banco da vítima (Comando: !espionar)." },
  "pedecabra": { nome: "🪝 Pé de Cabra", preco: 5000, desc: "Permite assaltar o cofre do Banco de alguém (Comando: !roubarbanco)." }
};

export default {
  name: "mercadonegro",
  description: "Compre itens ilegais no submundo.",
  commands: ["mercadonegro", "biqueira", "ilegal"],
  usage: `${PREFIX}mercadonegro`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    let level = 1;
    if (fs.existsSync(levelsPath)) {
      const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      if (levelsDB[remoteJid] && levelsDB[remoteJid][participant]) level = levelsDB[remoteJid][participant].level;
    }

    if (level < 10) {
      return await sendWarningReply("🛑 *Acesso Negado!*\nOs capangas barraram sua entrada. Você precisa ser pelo menos *Nível 10* para entrar no Mercado Negro.");
    }

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    if (!db[remoteJid][participant].inventario) db[remoteJid][participant].inventario = {};

    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const escolha = parts[1]?.toLowerCase();

    if (!acao || acao !== "comprar" || !escolha) {
      let menu = `🌑 *MERCADO NEGRO* 🌑\n\n_Fale baixo. O que você quer comprar?_\nSeu saldo: *${db[remoteJid][participant].saldo} Réis*\n\n`;
      
      for (const [key, item] of Object.entries(ITENS_ILEGAIS)) {
        const qtd = db[remoteJid][participant].inventario[key] || 0;
        menu += `🔸 *${item.nome}* - 💰 ${item.preco}\n`;
        menu += `↳ _${item.desc}_\n`;
        menu += `📦 Você tem: ${qtd} | 🛒 *${PREFIX}mercadonegro comprar ${key}*\n\n`;
      }
      return await sendReply(menu);
    }

    const item = ITENS_ILEGAIS[escolha];
    if (!item) return await sendWarningReply(`⚠️ Item não encontrado no submundo.`);

    if (db[remoteJid][participant].saldo < item.preco) {
      return await sendWarningReply(`💸 *Tá achando que é de graça?*\nVocê precisa de *${item.preco} Réis* para comprar isso.`);
    }

    db[remoteJid][participant].saldo -= item.preco;
    db[remoteJid][participant].inventario[escolha] = (db[remoteJid][participant].inventario[escolha] || 0) + 1;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, participant, "comprar_loja");

    return await sendSuccessReply(`🌑 *Negócio Fechado!*\nVocê comprou 1x *${item.nome}*. O item foi guardado no seu inventário.`);
  }
};
