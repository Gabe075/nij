import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export const PETS = {
  "cao": { nome: "Cão de Guarda 🐕", preco: 3000, desc: "Reduz a chance de você ser roubado." },
  "cavalo": { nome: "Cavalo Puro-Sangue 🐎", preco: 4000, desc: "Reduz o tempo de descanso do trabalho para 20 min." },
  "macaco": { nome: "Macaco Ladrão 🐒", preco: 3500, desc: "Aumenta sua chance de sucesso ao roubar." },
  "gato": { nome: "Gato da Sorte 🐈", preco: 2500, desc: "Dá +10% de bônus no seu salário do trabalho." }
};

export default {
  name: "mascotes",
  description: "Compre um mascote para ganhar bônus passivos.",
  commands: ["mascotes", "pets", "mascote", "pet"],
  usage: `${PREFIX}pets`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const escolha = parts[1]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (!acao || acao !== "comprar" || !escolha) {
      let menu = `🐾 *PET SHOP IMPERIAL* 🐾\n\nTenha um companheiro leal que te dá vantagens exclusivas!\n_(Você só pode ter 1 mascote ativo por vez)_\n\n`;
      
      for (const [key, pet] of Object.entries(PETS)) {
        menu += `🔸 *${pet.nome}*\n`;
        menu += `↳ _Efeito: ${pet.desc}_\n`;
        menu += `↳ _Preço: 💰 ${pet.preco} Réis_\n`;
        menu += `🛒 Comando: *${PREFIX}pets comprar ${key}*\n\n`;
      }
      
      const petAtual = db[remoteJid][participant].pet;
      if (petAtual && PETS[petAtual]) {
        menu += `🐾 *Seu Mascote Atual:* ${PETS[petAtual].nome}`;
      } else {
        menu += `🐾 *Seu Mascote Atual:* Nenhum`;
      }

      return await sendReply(menu);
    }

    const pet = PETS[escolha];
    if (!pet) return await sendWarningReply(`Mascote não encontrado! Digite *${PREFIX}pets* para ver a lista.`);

    if (db[remoteJid][participant].pet === escolha) {
      return await sendWarningReply(`Você já é dono de um *${pet.nome}*!`);
    }

    if (db[remoteJid][participant].saldo < pet.preco) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${pet.preco} Réis* na carteira para adotar este mascote.`);
    }

    db[remoteJid][participant].saldo -= pet.preco;
    db[remoteJid][participant].pet = escolha;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    return await sendSuccessReply(`🐾 *ADOÇÃO REALIZADA!*\n\nParabéns! Você acaba de adotar um *${pet.nome}*.\nOs bônus passivos dele já estão ativos na sua conta!`);
  }
};
