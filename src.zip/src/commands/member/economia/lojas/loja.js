import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { addProgressoMissao } from "../missoes/missoes.js"; // 🟢 Caminho atualizado!

const ecoPath = path.resolve("database", "economia.json");

const ITENS = {
  "escudo": { nome: "🛡️ Escudo Imperial", preco: 250, desc: "Protege sua carteira contra roubos por 12 horas." },
  "pocao": { nome: "🧪 Poção de Sabedoria", preco: 400, desc: "Concede +500 XP instantaneamente." },
  "kit": { nome: "🥷 Kit de Fuga", preco: 150, desc: "Zera o tempo de espera do seu próximo roubo." },
  "cafe": { nome: "☕ Café Expresso", preco: 80, desc: "Zera o seu cansaço, permitindo trabalhar novamente na mesma hora." }
};

export default {
  name: "loja",
  description: "Compre itens especiais e guarde no inventário.",
  commands: ["loja", "comprar", "shop"],
  usage: `${PREFIX}loja ou ${PREFIX}comprar <item>`,
  
  handle: async ({ args, commandName, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const senderJid = webMessage.key.participant || remoteJid;
    const cmd = commandName.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][senderJid]) db[remoteJid][senderJid] = { saldo: 0 };
    if (!db[remoteJid][senderJid].inventario) db[remoteJid][senderJid].inventario = {};

    if (cmd === "loja" && args.length === 0) {
      let menu = `🏪 *MERCADO IMPERIAL* 🏪\n\nSeu saldo: *${db[remoteJid][senderJid].saldo} Réis*\n\n`;
      for (const [key, item] of Object.entries(ITENS)) {
        menu += `🔸 *${item.nome}* - 💰 ${item.preco} Réis\n`;
        menu += `↳ _${item.desc}_\n`;
        menu += `🛒 Comando: *${PREFIX}comprar ${key}*\n\n`;
      }
      menu += `_Dica: Os itens comprados vão para o seu *${PREFIX}inventario*._`;
      return await sendReply(menu);
    }

    if (cmd === "comprar" || (cmd === "loja" && args.length > 0)) {
      const escolha = args[0]?.toLowerCase();
      const item = ITENS[escolha];

      if (!item) return await sendWarningReply(`⚠️ Item não encontrado! Digite *${PREFIX}loja* para ver o catálogo.`);

      const hoje = new Date().toDateString();
      if (db[remoteJid][senderJid].diaUltimaCompra !== hoje) {
        db[remoteJid][senderJid].diaUltimaCompra = hoje;
        db[remoteJid][senderJid].comprasHoje = 0;
      }

      if (db[remoteJid][senderJid].comprasHoje >= 5) {
        return await sendWarningReply(`🛑 *Loja Fechada!*\nVocê já atingiu o limite de *5 compras diárias*. Volte amanhã!`);
      }

      if (db[remoteJid][senderJid].saldo < item.preco) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${item.preco} Réis* para comprar o(a) ${item.nome}.`);
      }

      db[remoteJid][senderJid].saldo -= item.preco;
      db[remoteJid][senderJid].comprasHoje += 1;
      db[remoteJid][senderJid].inventario[escolha] = (db[remoteJid][senderJid].inventario[escolha] || 0) + 1;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

      // 🟢 ATUALIZA A MISSÃO
      addProgressoMissao(remoteJid, senderJid, "comprar_loja");

      const comprasRestantes = 5 - db[remoteJid][senderJid].comprasHoje;
      return await sendSuccessReply(`🛍️ *Compra Aprovada!*\nVocê comprou 1x *${item.nome}*.\nO item foi guardado na sua mochila! Use *${PREFIX}usar ${escolha}* quando quiser ativá-lo.\n\n_(Você ainda pode fazer ${comprasRestantes} compra(s) hoje)._`);
    }
  }
};
