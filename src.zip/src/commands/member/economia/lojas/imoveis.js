import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export const IMOVEIS = {
  "barraca": { nome: "⛺ Barraca de Caldo de Cana", preco: 500, lucroHora: 20 },
  "fazenda": { nome: "☕ Fazenda de Café", preco: 2500, lucroHora: 120 },
  "mina": { nome: "⛏️ Mina de Ouro", preco: 10000, lucroHora: 500 },
  "companhia": { nome: "🚢 Companhia de Comércio", preco: 50000, lucroHora: 3000 }
};

export default {
  name: "imoveis",
  description: "Compre propriedades para gerar renda passiva.",
  commands: ["imoveis", "imovel", "comprarimovel"],
  usage: `${PREFIX}imoveis comprar <id>`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const escolha = parts[1]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (!acao || acao !== "comprar" || !escolha) {
      let menu = `🏡 *IMOBILIÁRIA IMPERIAL* 🏡\n\nCompre negócios para gerar Réis automaticamente a cada hora!\n\n`;
      for (const [key, imovel] of Object.entries(IMOVEIS)) {
        menu += `🔸 *${imovel.nome}*\n`;
        menu += `↳ _Gera: ${imovel.lucroHora} Réis/hora_\n`;
        menu += `↳ _Custo: 💰 ${imovel.preco} Réis_\n`;
        menu += `🛒 Comando: *${PREFIX}imoveis comprar ${key}*\n\n`;
      }
      menu += `\n_Dica: Use *${PREFIX}coletar* para recolher seus lucros acumulados._`;
      return await sendReply(menu);
    }

    const imovel = IMOVEIS[escolha];
    if (!imovel) return await sendWarningReply(`⚠️ Imóvel não encontrado! Digite *${PREFIX}imoveis* para ver o catálogo.`);

    if (db[remoteJid][participant].saldo < imovel.preco) {
      return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${imovel.preco} Réis* na carteira para comprar este imóvel.`);
    }

    // Desconta o valor
    db[remoteJid][participant].saldo -= imovel.preco;
    
    // 🟢 CORREÇÃO: Garante que o objeto imoveis existe antes de salvar
    if (!db[remoteJid][participant].imoveis) {
      db[remoteJid][participant].imoveis = {};
    }
    
    db[remoteJid][participant].imoveis[escolha] = (db[remoteJid][participant].imoveis[escolha] || 0) + 1;

    // Se for a primeira compra, inicia o relógio de coleta
    if (!db[remoteJid][participant].ultimaColeta) {
      db[remoteJid][participant].ultimaColeta = Date.now();
    }

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    return await sendSuccessReply(`✅ 📜 *ESCRITURA ASSINADA!*\n\nParabéns! Você acaba de adquirir o(a) *${imovel.nome}*.\nEle já começou a gerar lucros para você. Lembre-se de usar *${PREFIX}coletar* todos os dias!`);
  }
};
