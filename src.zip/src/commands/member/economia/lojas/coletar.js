import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { IMOVEIS } from "./imoveis.js";
import { addProgressoMissao } from "../missoes/missoes.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "coletar",
  description: "Recolhe os lucros gerados pelos seus imóveis.",
  commands: ["coletar", "recolher", "lucros"],
  usage: `${PREFIX}coletar`,
  
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    
    if (!db[remoteJid] || !db[remoteJid][participant]) {
      return await sendWarningReply(`Você não possui nenhuma propriedade.\nUse *${PREFIX}imoveis* para comprar uma.`);
    }

    const meusImoveis = db[remoteJid][participant].imoveis;
    if (!meusImoveis || Object.keys(meusImoveis).length === 0) {
      return await sendWarningReply(`Você não possui nenhuma propriedade.\nUse *${PREFIX}imoveis* para comprar uma.`);
    }

    const agora = Date.now();
    const ultimaColeta = db[remoteJid][participant].ultimaColeta || agora;
    const horasPassadas = (agora - ultimaColeta) / (1000 * 60 * 60);

    if (horasPassadas < 1) {
      const minutosRestantes = Math.ceil((1 - horasPassadas) * 60);
      return await sendWarningReply(`⏳ Seus funcionários ainda estão trabalhando.\nVolte em *${minutosRestantes} minutos* para a próxima coleta.`);
    }

    const horasCalculo = Math.min(horasPassadas, 24);
    let lucroTotal = 0;
    let relatorio = `🚜 *RELATÓRIO DE COLETA* 🚜\n\n`;

    for (const [key, quantidade] of Object.entries(meusImoveis)) {
      if (IMOVEIS[key]) {
        const lucroImovel = Math.floor(IMOVEIS[key].lucroHora * quantidade * horasCalculo);
        lucroTotal += lucroImovel;
        relatorio += `🔸 ${quantidade}x ${IMOVEIS[key].nome}: *+${lucroImovel} Réis*\n`;
      }
    }

    db[remoteJid][participant].saldo += lucroTotal;
    db[remoteJid][participant].ultimaColeta = agora;

    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    addProgressoMissao(remoteJid, participant, "coletar");

    const avisoLimite = horasPassadas > 24 ? "\n\n_(⚠️ Seus cofres encheram após 24h. Colete mais vezes para não perder dinheiro!)_" : "";

    await sendSuccessReply(`${relatorio}\n💰 *Lucro Total Recolhido:* ${lucroTotal} Réis${avisoLimite}\n\n🏦 Saldo na Carteira: *${db[remoteJid][participant].saldo} Réis*`);
  }
};
