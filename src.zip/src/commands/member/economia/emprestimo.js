import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "emprestimo",
  description: "Pegue um empréstimo no Banco Imperial, mas cuidado com os juros!",
  commands: ["emprestimo", "bancoemprestimo", "divida"],
  usage: `${PREFIX}emprestimo`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const valor = parseInt(parts[1], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };

    // Atualiza juros diários (10% ao dia)
    const agora = Date.now();
    const umDia = 24 * 60 * 60 * 1000;
    
    if (db[remoteJid][participant].emprestimo) {
      const diasPassados = Math.floor((agora - db[remoteJid][participant].emprestimo.data) / umDia);
      if (diasPassados > 0) {
        // Aplica juros compostos
        for (let i = 0; i < diasPassados; i++) {
          db[remoteJid][participant].emprestimo.valor = Math.floor(db[remoteJid][participant].emprestimo.valor * 1.10);
        }
        db[remoteJid][participant].emprestimo.data = agora;
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      }
    }

    if (!acao || acao === "ajuda") {
      let menu = `🏦 *BANCO DE EMPRÉSTIMOS IMPERIAL* 🏦\n\n`;
      menu += `Precisa de dinheiro rápido? Pegue um empréstimo! Mas cuidado, os juros são de *10% ao dia*.\n\n`;
      menu += `🔸 *${PREFIX}emprestimo pegar <valor>* - Solicita um empréstimo\n`;
      menu += `🔸 *${PREFIX}emprestimo pagar <valor>* - Paga parte ou toda a sua dívida\n`;
      menu += `🔸 *${PREFIX}emprestimo status* - Veja o tamanho da sua dívida\n\n`;
      
      const limite = (db[remoteJid][participant].xp || 0) * 10 + 5000; // Limite baseado no XP
      menu += `_Seu limite de crédito atual é de: *${limite} Réis*_`;
      
      return await sendReply(menu);
    }

    if (acao === "status") {
      if (!db[remoteJid][participant].emprestimo || db[remoteJid][participant].emprestimo.valor <= 0) {
        return await sendReply("✅ Você não possui dívidas ativas no Banco Imperial.");
      }
      
      const div = db[remoteJid][participant].emprestimo.valor;
      return await sendReply(`📜 *EXTRATO DE DÍVIDA* 📜\n\nVocê deve atualmente *${div} Réis* ao Banco Imperial.\nOs juros de 10% são aplicados a cada 24 horas.`);
    }

    if (acao === "pegar") {
      if (isNaN(valor) || valor <= 0) return await sendWarningReply(`⚠️ Digite um valor válido.\nExemplo: *${PREFIX}emprestimo pegar 5000*`);
      
      if (db[remoteJid][participant].emprestimo && db[remoteJid][participant].emprestimo.valor > 0) {
        return await sendWarningReply(`⚠️ Você já tem um empréstimo ativo. Pague-o antes de pegar outro.`);
      }
      
      const limite = (db[remoteJid][participant].xp || 0) * 10 + 5000;
      if (valor > limite) {
        return await sendWarningReply(`⚠️ O banco negou o empréstimo!\nSeu limite de crédito atual é de *${limite} Réis*.`);
      }
      
      db[remoteJid][participant].saldo += valor;
      db[remoteJid][participant].emprestimo = {
        valor: valor,
        data: agora
      };
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *EMPRÉSTIMO APROVADO!*\n\nVocê recebeu *${valor} Réis* na sua carteira.\nLembre-se de pagar antes que os juros de 10% ao dia destruam suas finanças!`);
    }

    if (acao === "pagar") {
      if (!db[remoteJid][participant].emprestimo || db[remoteJid][participant].emprestimo.valor <= 0) {
        return await sendWarningReply("⚠️ Você não tem dívidas para pagar.");
      }
      
      if (isNaN(valor) || valor <= 0) return await sendWarningReply(`⚠️ Digite um valor válido.\nExemplo: *${PREFIX}emprestimo pagar 1000*`);
      
      const divida = db[remoteJid][participant].emprestimo.valor;
      const valorPago = Math.min(valor, divida); // Não deixa pagar mais do que deve
      
      if (db[remoteJid][participant].saldo < valorPago) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
      }
      
      db[remoteJid][participant].saldo -= valorPago;
      db[remoteJid][participant].emprestimo.valor -= valorPago;
      
      let msg = `✅ *PAGAMENTO REALIZADO!*\nVocê pagou *${valorPago} Réis* da sua dívida.\n`;
      
      if (db[remoteJid][participant].emprestimo.valor <= 0) {
        delete db[remoteJid][participant].emprestimo;
        msg += `🎉 *PARABÉNS! Você quitou toda a sua dívida com o banco!*`;
      } else {
        msg += `Restam *${db[remoteJid][participant].emprestimo.valor} Réis* para quitar.`;
      }
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(msg);
    }
  }
};
