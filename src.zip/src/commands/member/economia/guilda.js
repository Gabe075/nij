import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const guildasPath = path.resolve("database", "guildas.json");

const NIVEIS_GUILDA = {
  1: { nome: "Aprendizes", xpNecessario: 0, bonusXP: 0.05, bonusSalario: 0.02 },
  2: { nome: "Aventureiros", xpNecessario: 1000, bonusXP: 0.10, bonusSalario: 0.05 },
  3: { nome: "Veteranos", xpNecessario: 5000, bonusXP: 0.15, bonusSalario: 0.08 },
  4: { nome: "Mestres", xpNecessario: 15000, bonusXP: 0.20, bonusSalario: 0.12 },
  5: { nome: "Lendários", xpNecessario: 30000, bonusXP: 0.25, bonusSalario: 0.15 },
};

export default {
  name: "guilda",
  description: "Crie ou participe de uma guilda para ganhar bônus e competir com outras guildas.",
  commands: ["guilda", "clã", "gremio"],
  usage: `${PREFIX}guilda`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup, mentionedJidList }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const nomeGuilda = parts.slice(1).join(" ");
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let guildasDB = {};
    if (fs.existsSync(guildasPath)) guildasDB = JSON.parse(fs.readFileSync(guildasPath, "utf-8"));
    if (!guildasDB[remoteJid]) guildasDB[remoteJid] = {};

    const minhaGuildaId = db[remoteJid][participant].guilda;

    // Função para obter o nível da guilda
    const getLevelGuilda = (xp) => {
      let level = 1;
      for (const lvl in NIVEIS_GUILDA) {
        if (xp >= NIVEIS_GUILDA[lvl].xpNecessario) {
          level = parseInt(lvl);
        }
      }
      return NIVEIS_GUILDA[level];
    };

    if (!acao || acao === "ajuda") {
      let menu = `🛡️ *SISTEMA DE GUILDAS IMPERIAIS* 🛡️\n\n`;
      menu += `Una-se a outros jogadores, suba de nível e ganhe bônus!\n\n`;
      menu += `🔸 *${PREFIX}guilda criar <Nome da Guilda>* - Custa 10.000 Réis\n`;
      menu += `🔸 *${PREFIX}guilda info* - Ver informações da sua guilda\n`;
      menu += `🔸 *${PREFIX}guilda convidar @membro* - Convida alguém para a guilda (apenas líder)\n`;
      menu += `🔸 *${PREFIX}guilda expulsar @membro* - Expulsa alguém da guilda (apenas líder)\n`;
      menu += `🔸 *${PREFIX}guilda sair* - Sair da guilda\n`;
      menu += `🔸 *${PREFIX}guilda doar <valor>* - Doar para o cofre da guilda\n`;
      menu += `🔸 *${PREFIX}guilda ranking* - Ver as guildas mais fortes\n`;
      return await sendReply(menu);
    }

    if (acao === "criar") {
      if (minhaGuildaId) return await sendWarningReply("⚠️ Você já pertence a uma guilda! Saia dela primeiro.");
      if (!nomeGuilda) return await sendWarningReply(`⚠️ Digite o nome da guilda.\nExemplo: *${PREFIX}guilda criar Cavaleiros da Távola Redonda*`);
      
      const idGuilda = nomeGuilda.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (guildasDB[remoteJid][idGuilda]) return await sendWarningReply("⚠️ Já existe uma guilda com esse nome neste grupo!");

      const custoCriacao = 10000;
      if (db[remoteJid][participant].saldo < custoCriacao) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${custoCriacao} Réis* para fundar uma guilda.`);
      }

      db[remoteJid][participant].saldo -= custoCriacao;
      db[remoteJid][participant].guilda = idGuilda;
      guildasDB[remoteJid][idGuilda] = {
        nome: nomeGuilda,
        lider: participant,
        membros: [participant],
        cofre: 0,
        xp: 0,
        dataCriacao: Date.now()
      };
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(guildasPath, JSON.stringify(guildasDB, null, 2));
      return await sendSuccessReply(`🛡️ *GUILDA FUNDADA!*\n\nA guilda *${nomeGuilda}* foi criada com sucesso!`);
    }

    if (acao === "info") {
      if (!minhaGuildaId || !guildasDB[remoteJid][minhaGuildaId]) {
        return await sendWarningReply("⚠️ Você não pertence a nenhuma guilda.");
      }
      const guilda = guildasDB[remoteJid][minhaGuildaId];
      const nivelInfo = getLevelGuilda(guilda.xp);
      let msg = `🛡️ *GUILDA: ${guilda.nome}* 🛡️\n\n`;
      msg += `👑 *Líder:* @${guilda.lider.split("@")[0]}\n`;
      msg += `🌟 *Nível:* ${nivelInfo.level} (${nivelInfo.nome})\n`;
      msg += `✨ *XP:* ${guilda.xp}\n`;
      msg += `💰 *Cofre:* ${guilda.cofre} Réis\n`;
      msg += `👥 *Membros (${guilda.membros.length}):*\n`;
      guilda.membros.forEach(m => {
        msg += ` ↳ @${m.split("@")[0]}\n`;
      });
      return await sendReply(msg, guilda.membros);
    }

    if (acao === "convidar") {
      if (!minhaGuildaId) return await sendWarningReply("⚠️ Você não tem uma guilda.");
      const guilda = guildasDB[remoteJid][minhaGuildaId];
      if (guilda.lider !== participant) return await sendWarningReply("⚠️ Apenas o líder pode convidar membros.");
      if (mentionedJidList.length === 0) return await sendWarningReply("⚠️ Marque o usuário que deseja convidar.");
      const alvo = mentionedJidList[0];
      if (!db[remoteJid][alvo]) db[remoteJid][alvo] = { saldo: 0 };
      if (db[remoteJid][alvo].guilda) return await sendWarningReply("⚠️ Este usuário já pertence a uma guilda.");
      
      db[remoteJid][alvo].guilda = minhaGuildaId;
      guilda.membros.push(alvo);
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(guildasPath, JSON.stringify(guildasDB, null, 2));
      return await sendSuccessReply(`🤝 *NOVO MEMBRO!*\n\n@${alvo.split("@")[0]} agora faz parte da guilda *${guilda.nome}*!`, [alvo]);
    }

    if (acao === "expulsar") {
      if (!minhaGuildaId) return await sendWarningReply("⚠️ Você não tem uma guilda.");
      const guilda = guildasDB[remoteJid][minhaGuildaId];
      if (guilda.lider !== participant) return await sendWarningReply("⚠️ Apenas o líder pode expulsar membros.");
      if (mentionedJidList.length === 0) return await sendWarningReply("⚠️ Marque o usuário que deseja expulsar.");
      const alvo = mentionedJidList[0];
      if (alvo === participant) return await sendWarningReply("⚠️ Você não pode expulsar a si mesmo. Use o comando sair.");
      if (!guilda.membros.includes(alvo)) return await sendWarningReply("⚠️ Este usuário não faz parte da sua guilda.");
      
      guilda.membros = guilda.membros.filter(m => m !== alvo);
      if (db[remoteJid][alvo]) db[remoteJid][alvo].guilda = null;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(guildasPath, JSON.stringify(guildasDB, null, 2));
      return await sendSuccessReply(`🥾 *MEMBRO EXPULSO!*\n\n@${alvo.split("@")[0]} foi expulso da guilda *${guilda.nome}*.`, [alvo]);
    }

    if (acao === "sair") {
      if (!minhaGuildaId) return await sendWarningReply("⚠️ Você não está em nenhuma guilda.");
      const guilda = guildasDB[remoteJid][minhaGuildaId];
      if (guilda.lider === participant) {
        return await sendWarningReply("⚠️ Você é o líder! Para sair, você precisa passar a liderança ou a guilda será desfeita (recurso em breve).");
      }
      guilda.membros = guilda.membros.filter(m => m !== participant);
      db[remoteJid][participant].guilda = null;
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(guildasPath, JSON.stringify(guildasDB, null, 2));
      return await sendSuccessReply("🚪 Você saiu da guilda.");
    }

    if (acao === "doar") {
      if (!minhaGuildaId) return await sendWarningReply("⚠️ Você não tem uma guilda para doar.");
      const valorStr = parts.find(arg => /^\d+$/.test(arg));
      if (!valorStr) return await sendWarningReply(`⚠️ Digite um valor válido.\nExemplo: *${PREFIX}guilda doar 500*`);
      const valor = parseInt(valorStr, 10);
      if (valor <= 0) return await sendWarningReply("⚠️ O valor deve ser maior que zero.");
      if (db[remoteJid][participant].saldo < valor) return await sendWarningReply(`⚠️ Você só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
      
      const guilda = guildasDB[remoteJid][minhaGuildaId];
      db[remoteJid][participant].saldo -= valor;
      guilda.cofre += valor;
      guilda.xp += Math.floor(valor / 10); // 10 Réis = 1 XP para a guilda

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(guildasPath, JSON.stringify(guildasDB, null, 2));
      return await sendSuccessReply(`💰 *DOAÇÃO RECEBIDA!*\nVocê doou *${valor} Réis* para o cofre da guilda *${guilda.nome}* e ela ganhou *${Math.floor(valor / 10)} XP*!`);
    }

    if (acao === "ranking") {
      const guildasAtivas = Object.values(guildasDB[remoteJid]);
      if (guildasAtivas.length === 0) return await sendReply("Nenhuma guilda ativa no momento.");

      const sortedGuildas = guildasAtivas.sort((a, b) => b.xp - a.xp).slice(0, 5);

      let msg = `🏆 *RANKING DE GUILDAS* 🏆\n\n`;
      sortedGuildas.forEach((g, index) => {
        const nivelInfo = getLevelGuilda(g.xp);
        msg += `${index + 1}º - 🛡️ *${g.nome}*\n`;
        msg += `   ↳ Líder: @${g.lider.split("@")[0]}\n`;
        msg += `   ↳ Nível: ${nivelInfo.level} | XP: ${g.xp} | Membros: ${g.membros.length}\n\n`;
      });
      return await sendReply(msg, sortedGuildas.map(g => g.lider));
    }
  }
};
