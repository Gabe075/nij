import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");

// 🟢 NOVA ESTRUTURA: Trilhas de Carreira com Salário Fixo
export const PROFISSOES = {
  // 🧱 ÁREA: CONSTRUÇÃO CIVIL
  "ajudante": { nome: "Ajudante de Pedreiro 🧱", area: "Construção Civil", minLevel: 1, salario: 50 },
  "pedreiro": { nome: "Pedreiro 🏗️", area: "Construção Civil", minLevel: 10, salario: 120 },
  "arquiteto": { nome: "Arquiteto 📐", area: "Construção Civil", minLevel: 25, salario: 300 },
  "dono_obra": { nome: "Dono da Obra 🏢", area: "Construção Civil", minLevel: 50, salario: 800 },

  // 🏥 ÁREA: SAÚDE
  "socorrista": { nome: "Socorrista 🚑", area: "Saúde", minLevel: 1, salario: 60 },
  "enfermeiro": { nome: "Enfermeiro 💉", area: "Saúde", minLevel: 10, salario: 150 },
  "medico": { nome: "Médico Cirurgião 🩺", area: "Saúde", minLevel: 25, salario: 400 },
  "diretor_hospital": { nome: "Diretor do Hospital 🏥", area: "Saúde", minLevel: 50, salario: 1000 },

  // 🚓 ÁREA: SEGURANÇA
  "vigia": { nome: "Segurança de Shopping 🔦", area: "Segurança", minLevel: 1, salario: 55 },
  "policial": { nome: "Policial Militar 🚓", area: "Segurança", minLevel: 10, salario: 140 },
  "delegado": { nome: "Delegado Federal 🚔", area: "Segurança", minLevel: 25, salario: 350 },
  "ministro_defesa": { nome: "Ministro da Defesa 🎖️", area: "Segurança", minLevel: 50, salario: 900 },

  // 🍳 ÁREA: CULINÁRIA
  "lavador": { nome: "Lavador de Pratos 🧽", area: "Culinária", minLevel: 1, salario: 40 },
  "cozinheiro": { nome: "Cozinheiro 🍳", area: "Culinária", minLevel: 10, salario: 100 },
  "chef": { nome: "Chef de Cozinha 👨‍🍳", area: "Culinária", minLevel: 25, salario: 250 },
  "dono_restaurante": { nome: "Dono de Restaurante 🍽️", area: "Culinária", minLevel: 50, salario: 700 }
};

export default {
  name: "empregos",
  description: "Veja e escolha sua trilha de carreira.",
  commands: ["empregos", "profissoes", "escolher", "profissao"],
  usage: `${PREFIX}empregos ou ${PREFIX}escolher <nome>`,
  
  handle: async ({ args, sendReply, remoteJid, webMessage }) => {
    const participant = webMessage.key.participant || remoteJid;

    let level = 1;
    if (fs.existsSync(levelsPath)) {
      const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      if (levelsDB[remoteJid] && levelsDB[remoteJid][participant]) {
        level = levelsDB[remoteJid][participant].level;
      }
    }

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    if (!args[0]) {
      let msg = `🏢 *AGÊNCIA DE EMPREGOS IMPERIAL* 🏢\nSeu Nível: *${level}*\n\n`;
      msg += `_Evolua na sua área para ganhar promoções e salários maiores!_\n`;

      const areas = ["Construção Civil", "Saúde", "Segurança", "Culinária"];
      
      for (const area of areas) {
        msg += `\n💼 *ÁREA: ${area.toUpperCase()}*\n`;
        const profsArea = Object.entries(PROFISSOES).filter(([k, v]) => v.area === area);
        
        for (const [key, prof] of profsArea) {
          const status = level >= prof.minLevel ? "✅" : `🔒 Lvl ${prof.minLevel}`;
          msg += `🔸 [${status}] *${prof.nome}*\n`;
          msg += `   💰 Salário Fixo: ${prof.salario} Réis | Comando: *${key}*\n`;
        }
      }

      const profAtual = db[remoteJid][participant].profissao;
      if (profAtual && PROFISSOES[profAtual]) {
        msg += `\n🎯 *Seu cargo atual:* ${PROFISSOES[profAtual].nome}`;
      } else {
        msg += `\n🎯 *Seu cargo atual:* Desempregado`;
      }

      return await sendReply(msg);
    }

    const escolha = args[0].toLowerCase();
    const profissao = PROFISSOES[escolha];

    if (!profissao) return await sendReply(`⚠️ Cargo não encontrado! Digite *${PREFIX}empregos* para ver a lista.`);
    if (level < profissao.minLevel) return await sendReply(`🚫 *Promoção Recusada!*\nVocê precisa estar no *Nível ${profissao.minLevel}* para assumir o cargo de ${profissao.nome}. Continue trabalhando e ganhando XP!`);

    db[remoteJid][participant].profissao = escolha;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    await sendReply(`🎉 *PROMOÇÃO APROVADA!*\nParabéns, agora você atua como *${profissao.nome}*!\nSeu salário fixo agora é de *${profissao.salario} Réis*. Use *${PREFIX}trabalhar* para bater o ponto.`);
  }
};
