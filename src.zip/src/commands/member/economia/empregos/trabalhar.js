import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { PROFISSOES } from "./empregos.js";
import { addProgressoMissao } from "../missoes/missoes.js";

const ecoPath = path.resolve("database", "economia.json");
const familiasPath = path.resolve("database", "familias.json");
const casamentosPath = path.resolve("database", "casamentos.json");

function getBonusFamilia(cofre) {
  if (cofre >= 250000) return 25;
  if (cofre >= 100000) return 20;
  if (cofre >= 50000) return 15;
  if (cofre >= 20000) return 10;
  return 5;
}

export default {
  name: "trabalhar",
  description: "Trabalhe no seu cargo atual para ganhar seu salário fixo.",
  commands: ["trabalhar", "work", "trampar"],
  usage: `${PREFIX}trabalhar`,
  
  handle: async ({ sendReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendReply("⚠️ Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    const profKey = db[remoteJid][participant].profissao;
    const meuPet = db[remoteJid][participant].pet; 
    const minhaFamiliaId = db[remoteJid][participant].familia; 
    const meuCasamentoId = db[remoteJid][participant].casamento; 
    
    if (!profKey || !PROFISSOES[profKey]) {
      return await sendReply(`⚠️ Você está desempregado!\nDigite *${PREFIX}empregos* para escolher uma área de atuação antes de trabalhar.`);
    }

    const profissao = PROFISSOES[profKey];
    const agora = Date.now();
    
    let tempoDescanso = 30 * 60 * 1000; 
    if (meuPet === "cavalo") tempoDescanso = 20 * 60 * 1000;

    if (db[remoteJid][participant].ultimoTrabalho) {
      const tempoPassado = agora - db[remoteJid][participant].ultimoTrabalho;
      if (tempoPassado < tempoDescanso) {
        const minutosRestantes = Math.ceil((tempoDescanso - tempoPassado) / 60000);
        return await sendReply(`⏳ *Você está exausto!*\nO expediente acabou. Descanse mais *${minutosRestantes} minutos* antes de bater o ponto novamente.`);
      }
    }

    let salarioBase = profissao.salario;
    let salarioFinal = salarioBase;
    let holerite = `💵 _Salário Base: ${salarioBase} Réis_`;

    // 🐾 Bônus do Pet
    if (meuPet === "gato") {
      const bonusGato = Math.floor(salarioBase * 0.10);
      salarioFinal += bonusGato;
      holerite += `\n🐈 _Gato da Sorte (+10%): +${bonusGato} Réis_`;
    }

    // ⚔️ Bônus da Família
    if (minhaFamiliaId && fs.existsSync(familiasPath)) {
      const famDB = JSON.parse(fs.readFileSync(familiasPath, "utf-8"));
      if (famDB[remoteJid] && famDB[remoteJid][minhaFamiliaId]) {
        const cofre = famDB[remoteJid][minhaFamiliaId].cofre;
        const porcentagemBonus = getBonusFamilia(cofre);
        const bonusFamilia = Math.floor(salarioBase * (porcentagemBonus / 100));
        
        salarioFinal += bonusFamilia;
        holerite += `\n⚔️ _Bônus Família (+${porcentagemBonus}%): +${bonusFamilia} Réis_`;
      }
    }

    // 💍 Bônus do Casamento e Filhos
    if (meuCasamentoId && fs.existsSync(casamentosPath)) {
      const casamentosDB = JSON.parse(fs.readFileSync(casamentosPath, "utf-8"));
      if (casamentosDB[remoteJid] && casamentosDB[remoteJid][meuCasamentoId]) {
        const cas = casamentosDB[remoteJid][meuCasamentoId];
        const qtdFilhos = cas.filhos ? cas.filhos.length : 0;
        
        const porcentagemCasamento = 10 + (qtdFilhos * 5);
        const bonusCasamento = Math.floor(salarioBase * (porcentagemCasamento / 100));
        
        salarioFinal += bonusCasamento;
        holerite += `\n💍 _Bônus Casamento (+${porcentagemCasamento}%): +${bonusCasamento} Réis_`;
      }
    }

    db[remoteJid][participant].saldo += salarioFinal;
    db[remoteJid][participant].ultimoTrabalho = agora;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    // 🟢 ATUALIZA A MISSÃO
    addProgressoMissao(remoteJid, participant, "trabalhar");

    await sendReply(`💼 *EXPEDIENTE ENCERRADO* 💼\n\nVocê cumpriu seu turno como *${profissao.nome}*.\n\n${holerite}\n\n💰 *Total Recebido:* ${salarioFinal} Réis\n🏦 Saldo atual: *${db[remoteJid][participant].saldo} Réis*`);
  }
};
