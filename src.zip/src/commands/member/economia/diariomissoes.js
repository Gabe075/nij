import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "diariomissoes",
    description: "Acompanhe suas missões ativas e recompensas.",
    commands: ["diario", "missões"],
    usage: `${PREFIX}diario`,
    handle: async ({ sendReply }) => {
        return await sendReply("📜 *DIÁRIO DE AVENTURAS* 📜\nVocê tem 2 missões pendentes!");
    }
};
