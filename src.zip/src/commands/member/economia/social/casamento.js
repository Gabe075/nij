import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const casamentoPath = path.resolve("database", "casamento.json");

export default {
  name: "casamento",
  description: "Gerencie seu casamento imperial.",
  commands: ["casamento", "casar", "divorciar"],
  usage: `${PREFIX}casamento`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const mentionedJidList = webMessage.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let casDB = {};
    if (fs.existsSync(casamentoPath)) casDB = JSON.parse(fs.readFileSync(casamentoPath, "utf-8"));
    if (!casDB[remoteJid]) casDB[remoteJid] = {};

    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const meuCasamentoId = db[remoteJid][participant].casamento;

    // Funções auxiliares
    const getCasal = (id) => casDB[remoteJid][id];
    const getParceiro = (casal, eu) => (casal.noivo1 === eu) ? casal.noivo2 : casal.noivo1;

    // 📜 MENU DE AJUDA
    if (!acao || acao === "ajuda") {
      let menu = `💍 *CARTÓRIO IMPERIAL* 💍\n\n`;
      menu += `Encontre sua alma gêmea e construam um império juntos!\n\n`;
      menu += `🔸 *${PREFIX}casar @usuario* - Pede alguém em casamento (Custa 5.000 Réis)\n`;
      menu += `🔸 *${PREFIX}aceitar / recusar @usuario* - Responde a um pedido\n`;
      menu += `🔸 *${PREFIX}casamento info* - Ver sua certidão de casamento\n`;
      menu += `🔸 *${PREFIX}bau depositar/sacar <valor>* - Conta conjunta do casal\n`;
      menu += `🔸 *${PREFIX}terfilho <Nome>* - Adota um herdeiro (Custa 5.000 Réis)\n`;
      menu += `🔸 *${PREFIX}divorciar* - Separação litigiosa (Custa 10.000 Réis)\n`;
      return await sendReply(menu);
    }

    // ℹ️ INFO DO CASAMENTO
    if (acao === "info") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) {
        return await sendWarningReply("⚠️ Você não está casado(a).");
      }
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);
      const bonusTotal = 10 + (casal.filhos.length * 5);

      let msg = `💍 *CERTIDÃO DE CASAMENTO* 💍\n\n`;
      msg += `❤️ *Casal:* @${casal.noivo1.split("@")[0]} & @${casal.noivo2.split("@")[0]}\n`;
      msg += `💰 *Baú Conjunto:* ${casal.bau} Réis\n`;
      msg += `📈 *Bônus Total:* +${bonusTotal}% no salário\n\n`;

      msg += `👶 *Filhos (${casal.filhos.length}/3):*\n`;
      if (casal.filhos.length === 0) {
        msg += ` _Nenhum herdeiro ainda._\n`;
      } else {
        casal.filhos.forEach(f => msg += ` ↳ 🍼 ${f}\n`);
      }
      return await sendReply(msg, [casal.noivo1, casal.noivo2]);
    }

    // 💍 PEDIR EM CASAMENTO
    if (acao === "casar") {
      if (meuCasamentoId) return await sendWarningReply("⚠️ Você já está casado(a).");
      const alvoJid = mentionedJidList[0];
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque a pessoa que você quer pedir em casamento.\nExemplo: *${PREFIX}casar @usuario*`);
      if (alvoJid === participant) return await sendWarningReply("⚠️ Você não pode casar consigo mesmo(a).");
      if (db[remoteJid][alvoJid]?.casamento) return await sendWarningReply("⚠️ Essa pessoa já está casada.");

      const custoAliancas = 5000;
      if (db[remoteJid][participant].saldo < custoAliancas) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoAliancas} Réis* para comprar as alianças.`);
      }

      // Registra o pedido
      casDB[remoteJid][participant] = {
        pedido: alvoJid,
        dataPedido: Date.now(),
        custo: custoAliancas
      };
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendSuccessReply(`✅ 💍 *PEDIDO DE CASAMENTO!* 💍\n\n@${participant.split("@")[0]} está ajoelhado(a) com alianças de ouro (${custoAliancas} Réis) pedindo a mão de @${alvoJid.split("@")[0]} em casamento!\n\nPara responder, o alvo deve digitar:\n✅ *${PREFIX}aceitar @${participant.split("@")[0]}*\n❌ *${PREFIX}recusar @${participant.split("@")[0]}*`, [alvoJid]);
    }

    // ✅ ACEITAR PEDIDO
    if (acao === "aceitar") {
      const alvoJid = mentionedJidList[0];
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque a pessoa que te pediu em casamento.\nExemplo: *${PREFIX}aceitar @usuario*`);
      if (alvoJid === participant) return await sendWarningReply("⚠️ Você não pode aceitar um pedido de si mesmo(a).");
      if (meuCasamentoId) return await sendWarningReply("⚠️ Você já está casado(a).");

      const pedido = casDB[remoteJid][alvoJid]?.pedido;
      if (pedido !== participant) return await sendWarningReply("⚠️ Não há pedido de casamento pendente para você desta pessoa.");

      const custoAliancas = casDB[remoteJid][alvoJid].custo;

      // Desconta do noivo1 e cria o casamento
      db[remoteJid][alvoJid].saldo -= custoAliancas;
      db[remoteJid][alvoJid].casamento = alvoJid + participant;
      db[remoteJid][participant].casamento = alvoJid + participant;

      const idCasamento = alvoJid + participant;
      casDB[remoteJid][idCasamento] = {
        id: idCasamento,
        noivo1: alvoJid,
        noivo2: participant,
        dataCasamento: Date.now(),
        bau: 0,
        filhos: []
      };

      // Limpa o pedido
      delete casDB[remoteJid][alvoJid].pedido;
      delete casDB[remoteJid][alvoJid].dataPedido;
      delete casDB[remoteJid][alvoJid].custo;

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendSuccessReply(`✅ 🎉 *VIVA OS NOIVOS!* 🎉\n\n@${participant.split("@")[0]} disse SIM para @${alvoJid.split("@")[0]}!\n\nVocês agora dividem uma conta conjunta (*${PREFIX}bau*) e ganham +10% de bônus em todos os trabalhos!`, [alvoJid, participant]);
    }

    // ❌ RECUSAR PEDIDO
    if (acao === "recusar") {
      const alvoJid = mentionedJidList[0];
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque a pessoa que te pediu em casamento.\nExemplo: *${PREFIX}recusar @usuario*`);
      if (alvoJid === participant) return await sendWarningReply("⚠️ Você não pode recusar um pedido de si mesmo(a).");
      if (meuCasamentoId) return await sendWarningReply("⚠️ Você já está casado(a).");

      const pedido = casDB[remoteJid][alvoJid]?.pedido;
      if (pedido !== participant) return await sendWarningReply("⚠️ Não há pedido de casamento pendente para você desta pessoa.");

      // Limpa o pedido
      delete casDB[remoteJJid][alvoJid].pedido;
      delete casDB[remoteJid][alvoJid].dataPedido;
      delete casDB[remoteJid][alvoJid].custo;
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendWarningReply(`🛑 *PEDIDO RECUSADO!* 🛑\n\n@${participant.split("@")[0]} recusou o pedido de casamento de @${alvoJid.split("@")[0]}.`, [alvoJid, participant]);
    }

    // 💰 BAÚ CONJUNTO
    if (acao === "bau") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) return await sendWarningReply("⚠️ Você não está casado(a).");
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);

      const subAcao = parts[1]?.toLowerCase();
      const valorStr = parts[2];
      const valor = parseInt(valorStr, 10);

      if (!subAcao || (subAcao !== "depositar" && subAcao !== "sacar")) {
        return await sendWarningReply(`⚠️ Uso incorreto.\nExemplo: *${PREFIX}bau depositar 500* ou *${PREFIX}bau sacar 200*`);
      }
      if (isNaN(valor) || valor <= 0) return await sendWarningReply("⚠️ Digite um valor válido maior que zero.");

      if (subAcao === "depositar") {
        if (db[remoteJid][participant].saldo < valor) return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
        db[remoteJid][participant].saldo -= valor;
        casal.bau += valor;
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));
        return await sendSuccessReply(`✅ *DEPÓSITO NO BAÚ!*\nVocê depositou *${valor} Réis* no baú conjunto. Saldo atual: *${casal.bau} Réis*.`);
      }

      if (subAcao === "sacar") {
        if (casal.bau < valor) return await sendWarningReply(`💸 *Saldo Insuficiente no Baú!*\nO baú conjunto só tem *${casal.bau} Réis*.`);
        db[remoteJid][participant].saldo += valor;
        casal.bau -= valor;
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));
        return await sendSuccessReply(`✅ *SAQUE DO BAÚ!*\nVocê sacou *${valor} Réis* do baú conjunto. Saldo atual: *${casal.bau} Réis*.`);
      }
    }

    // 🍼 TER FILHO
    if (acao === "terfilho") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) return await sendWarningReply("⚠️ Você não está casado(a).");
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);

      if (casal.filhos.length >= 3) return await sendWarningReply("⚠️ A casa já está cheia! Vocês atingiram o limite máximo de 3 filhos.");

      const nomeFilho = parts.slice(1).join(" ");
      if (!nomeFilho) return await sendWarningReply(`⚠️ Escolha um nome para a criança.\nExemplo: *${PREFIX}terfilho Gabirosvaldo*`);

      const custoFilho = 5000;
      if (db[remoteJid][participant].saldo < custoFilho) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoFilho} Réis* na carteira para ter um filho.`);
      }

      // Registra o pedido de filho
      casDB[remoteJid][participant].pedidoFilho = {
        nome: nomeFilho,
        custo: custoFilho,
        parceiro: parceiroJid
      };
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendSuccessReply(`✅ 🍼 *PEDIDO DE FILHO!* 🍼\n\n@${participant.split("@")[0]} quer ter um filho chamado *${nomeFilho}* (Custa ${custoFilho} Réis da carteira de quem pediu).\n\n@${parceiroJid.split("@")[0]}, você aceita essa responsabilidade?\n✅ *${PREFIX}aceitarfilho @${participant.split("@")[0]}*\n❌ *${PREFIX}recusarfilho @${participant.split("@")[0]}*`, [parceiroJid]);
    }

    // ✅ ACEITAR FILHO
    if (acao === "aceitarfilho") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) return await sendWarningReply("⚠️ Você não está casado(a).");
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);

      const pedido = casDB[remoteJid][parceiroJid]?.pedidoFilho;
      if (!pedido || pedido.parceiro !== participant) return await sendWarningReply("⚠️ Não há pedido de filho pendente para você desta pessoa.");

      // Desconta e adiciona o filho
      db[remoteJid][parceiroJid].saldo -= pedido.custo;
      casal.filhos.push(pedido.nome);

      // Limpa o pedido
      delete casDB[remoteJid][parceiroJid].pedidoFilho;

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendSuccessReply(`✅ 🍼 *UM NOVO HERDEIRO!* 🍼\n\nParabéns! @${parceiroJid.split("@")[0]} e @${participant.split("@")[0]} acabam de ter um bebê chamado *${pedido.nome}*!\n\nA família cresceu e o bônus de salário de vocês aumentou em +5%!`, [parceiroJid, participant]);
    }

    // ❌ RECUSAR FILHO
    if (acao === "recusarfilho") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) return await sendWarningReply("⚠️ Você não está casado(a).");
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);

      const pedido = casDB[remoteJid][parceiroJid]?.pedidoFilho;
      if (!pedido || pedido.parceiro !== participant) return await sendWarningReply("⚠️ Não há pedido de filho pendente para você desta pessoa.");

      // Limpa o pedido
      delete casDB[remoteJid][parceiroJid].pedidoFilho;
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendWarningReply(`🛑 *PEDIDO RECUSADO!* 🛑\n\n@${participant.split("@")[0]} achou que não é o momento certo para ter filhos.\nO dinheiro foi devolvido para @${parceiroJid.split("@")[0]}.`, [parceiroJid]);
    }

    // 💔 DIVORCIAR
    if (acao === "divorciar") {
      if (!meuCasamentoId || !getCasal(meuCasamentoId)) return await sendWarningReply("⚠️ Você não está casado(a).");
      const casal = getCasal(meuCasamentoId);
      const parceiroJid = getParceiro(casal, participant);

      const custoDivorcio = 10000;
      if (db[remoteJid][participant].saldo < custoDivorcio) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${custoDivorcio} Réis* na carteira para pagar as custas do divórcio.`);
      }

      // Desconta e remove o casamento
      db[remoteJid][participant].saldo -= custoDivorcio;
      db[remoteJid][participant].casamento = null;
      db[remoteJid][parceiroJid].casamento = null;

      // Transfere o dinheiro do baú para a carteira de quem pediu o divórcio
      db[remoteJid][participant].saldo += casal.bau;

      delete casDB[remoteJid][meuCasamentoId];

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(casamentoPath, JSON.stringify(casDB, null, 2));

      return await sendSuccessReply(`💔 *DIVÓRCIO CONCLUÍDO!* 💔\n\n@${participant.split("@")[0]} e @${parceiroJid.split("@")[0]} estão oficialmente divorciados.\nO baú conjunto foi para quem pediu o divórcio e o bônus de salário foi cancelado.`, [parceiroJid]);
    }
  }
};
