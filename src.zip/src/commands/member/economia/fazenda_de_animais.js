import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const ANIMAIS = {
  "galinha": {
    nome: "Galinha 🐔",
    custo: 100,
    producao: { "ovo": 1 },
    tempoProducao: 10 * 60 * 1000 // 10 minutos
  },
  "vaca": {
    nome: "Vaca 🐄",
    custo: 500,
    producao: { "leite": 1, "carne": 0.1 },
    tempoProducao: 30 * 60 * 1000 // 30 minutos
  },
  "ovelha": {
    nome: "Ovelha 🐑",
    custo: 300,
    producao: { "la": 1 },
    tempoProducao: 20 * 60 * 1000 // 20 minutos
  },
};

export default {
  name: "fazendaanimais",
  description: "Crie animais em sua fazenda para produzir recursos valiosos.",
  commands: ["fazendaanimais", "animais", "criar"],
  usage: `${PREFIX}fazendaanimais`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const tipoAnimal = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, inventario: {} };
    if (!db[remoteJid][participant].animais) db[remoteJid][participant].animais = {};

    const agora = Date.now();

    // Coleta automática de produção
    for (const animalKey in db[remoteJid][participant].animais) {
      const animalData = db[remoteJid][participant].animais[animalKey];
      const animalInfo = ANIMAIS[animalKey];
      if (animalData.quantidade > 0 && agora - animalData.ultimaColeta >= animalInfo.tempoProducao) {
        for (const recurso in animalInfo.producao) {
          const quantidadeProduzida = animalInfo.producao[recurso] * animalData.quantidade;
          db[remoteJid][participant].inventario[recurso] = (db[remoteJid][participant].inventario[recurso] || 0) + quantidadeProduzida;
        }
        db[remoteJid][participant].animais[animalKey].ultimaColeta = agora;
      }
    }
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    if (!acao || acao === "ajuda") {
      let menu = `🐄 *FAZENDA DE ANIMAIS IMPERIAL* 🐄\n\n`;
      menu += `Crie animais para produzir recursos e vendê-los no mercado!\n\n`;
      
      for (const [key, animal] of Object.entries(ANIMAIS)) {
        menu += `🐔 *${animal.nome}*\n`;
        menu += `   ↳ Custo: ${animal.custo} Réis\n`;
        menu += `   ↳ Produção: ${Object.entries(animal.producao).map(([res, qtd]) => `${qtd}x ${res}`).join(", ")}\n`;
        menu += `   ↳ Tempo de Produção: ${animal.tempoProducao / (60 * 1000)} minutos\n`;
        menu += `🛒 *${PREFIX}fazendaanimais comprar ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}fazendaanimais meus* para ver seus animais e *${PREFIX}inventario* para ver seus recursos._`;
      return await sendReply(menu);
    }

    if (acao === "comprar") {
      if (!ANIMAIS[tipoAnimal]) return await sendWarningReply(`⚠️ Tipo de animal inválido!`);
      const animal = ANIMAIS[tipoAnimal];
      
      if (db[remoteJid][participant].saldo < animal.custo) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${animal.custo} Réis* para comprar um(a) ${animal.nome}.`);
      }
      
      db[remoteJid][participant].saldo -= animal.custo;
      
      if (!db[remoteJid][participant].animais[tipoAnimal]) {
        db[remoteJid][participant].animais[tipoAnimal] = {
          quantidade: 0,
          ultimaColeta: agora
        };
      }
      db[remoteJid][participant].animais[tipoAnimal].quantidade += 1;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *COMPRA REALIZADA!*\nVocê comprou 1x *${animal.nome}* por ${animal.custo} Réis.\nEle já está produzindo recursos para você!`);
    }

    if (acao === "meus") {
      const meusAnimais = db[remoteJid][participant].animais;
      if (Object.keys(meusAnimais).length === 0) return await sendReply("📭 Você não possui nenhum animal na sua fazenda.");
      
      let msg = `🐄 *SEUS ANIMAIS NA FAZENDA* 🐄\n\n`;
      for (const [key, data] of Object.entries(meusAnimais)) {
        if (data.quantidade > 0) {
          const animal = ANIMAIS[key];
          const tempoRestante = Math.ceil((animal.tempoProducao - (agora - data.ultimaColeta)) / (60 * 1000));
          msg += `*${animal.nome}:* ${data.quantidade} unidades\n`;
          msg += `   ↳ Produção por unidade: ${Object.entries(animal.producao).map(([res, qtd]) => `${qtd}x ${res}`).join(", ")}\n`;
          msg += `   ↳ Próxima produção em: ${tempoRestante > 0 ? `${tempoRestante} minutos` : "PRONTO!"}\n\n`;
        }
      }
      return await sendReply(msg);
    }
  }
};
