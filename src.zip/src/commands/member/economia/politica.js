import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const politicaPath = path.resolve("database", "politica.json");

const CARGOS_POLITICOS = {
  "conselheiro": { nome: "Conselheiro Imperial", custoCandidatura: 5000, salario: 1000, bonusGrupo: 0.02, duracaoMandato: 24 * 60 * 60 * 1000 }, // 24 horas
  "ministro": { nome: "Ministro da Fazenda", custoCandidatura: 15000, salario: 3000, bonusGrupo: 0.05, duracaoMandato: 48 * 60 * 60 * 1000 } // 48 horas
};

export default {
  name: "politica",
  description: "Participe da política imperial e ganhe influência.",
  commands: ["politica", "eleicoes", "candidatar"],
  usage: `${PREFIX}politica`,
  
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const cargoKey = parts[1]?.toLowerCase();

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let polDB = {};
    if (fs.existsSync(politicaPath)) polDB = JSON.parse(fs.readFileSync(politicaPath, "utf-8"));
    if (!polDB[remoteJid]) polDB[remoteJid] = {};

    // Menu principal
    if (!acao || acao === "ajuda") {
      let menu = `🗳️ *SISTEMA POLÍTICO IMPERIAL* 🗳️\n\n`;
      menu += `Participe das eleições e governe o Império!\n\n`;
      menu += `🔸 *${PREFIX}politica candidatar <cargo>* - Candidate-se a um cargo político\n`;
      menu += `🔸 *${PREFIX}politica cargos* - Veja os cargos disponíveis e seus benefícios\n`;
      menu += `🔸 *${PREFIX}politica atual* - Veja quem está no poder\n`;
      menu += `🔸 *${PREFIX}politica votar @candidato* - Vote no seu candidato favorito (em breve)\n`;
      return await sendReply(menu);
    }

    // Lista de cargos
    if (acao === "cargos") {
      let msg = `🏛️ *CARGOS POLÍTICOS DISPONÍVEIS* 🏛️\n\n`;
      for (const [key, cargo] of Object.entries(CARGOS_POLITICOS)) {
        msg += `🔸 *${cargo.nome}*\n`;
        msg += `   ↳ Salário: ${cargo.salario} Réis/mandato\n`;
        msg += `   ↳ Bônus para o Grupo: +${(cargo.bonusGrupo * 100).toFixed(0)}% de XP\n`;
        msg += `   ↳ Custo de Candidatura: ${cargo.custoCandidatura} Réis\n`;
        msg += `   ↳ Duração do Mandato: ${cargo.duracaoMandato / (60 * 60 * 1000)} horas\n\n`;
      }
      return await sendReply(msg);
    }

    // Candidatar-se
    if (acao === "candidatar") {
      if (!CARGOS_POLITICOS[cargoKey]) return await sendWarningReply(`⚠️ Cargo inválido! Digite *${PREFIX}politica cargos* para ver a lista.`);
      const cargo = CARGOS_POLITICOS[cargoKey];

      // Verifica se já está em algum cargo
      const meuCargo = Object.values(polDB[remoteJid]).find(c => c.eleito === participant && c.fimMandato > Date.now());
      if (meuCargo) return await sendWarningReply(`⚠️ Você já ocupa o cargo de *${meuCargo.nome}*. Aguarde o fim do seu mandato.`);

      // Verifica custo
      if (db[remoteJid][participant].saldo < cargo.custoCandidatura) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${cargo.custoCandidatura} Réis* para se candidatar a *${cargo.nome}*.`);
      }

      // Desconta e registra candidatura
      db[remoteJid][participant].saldo -= cargo.custoCandidatura;
      polDB[remoteJid][cargoKey] = {
        candidato: participant,
        eleito: null,
        dataCandidatura: Date.now(),
        fimMandato: 0,
        nome: cargo.nome
      };

      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(politicaPath, JSON.stringify(polDB, null, 2));

      return await sendSuccessReply(`✅ *CANDIDATURA REGISTRADA!*\nVocê se candidatou a *${cargo.nome}*. As eleições (em breve) decidirão o próximo governante!`);
    }

    // Ver cargos atuais
    if (acao === "atual") {
      const cargosAtuais = Object.values(polDB[remoteJid]).filter(c => c.eleito && c.fimMandato > Date.now());
      if (cargosAtuais.length === 0) return await sendReply("Nenhum cargo político ocupado no momento.");

      let msg = `🏛️ *GOVERNO IMPERIAL ATUAL* 🏛️\n\n`;
      cargosAtuais.forEach(c => {
        msg += `🔸 *${c.nome}:* @${c.eleito.split("@")[0]}\n`;
        msg += `   ↳ Mandato termina em: ${new Date(c.fimMandato).toLocaleString()}\n\n`;
      });
      return await sendReply(msg, cargosAtuais.map(c => c.eleito));
    }

    // TODO: Implementar sistema de votação e eleição automática
  }
};
