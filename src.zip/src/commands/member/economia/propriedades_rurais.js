import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const PROPRIEDADES = {
  "sitio": { nome: "Sítio Pequeno 🏡", custo: 5000, producaoBase: 200, tempoProducao: 30 * 60 * 1000 }, // 30 minutos
  "fazenda": { nome: "Fazenda Média 🚜", custo: 15000, producaoBase: 700, tempoProducao: 60 * 60 * 1000 }, // 1 hora
  "latifundio": { nome: "Latifúndio Gigante 🌾", custo: 50000, producaoBase: 2500, tempoProducao: 3 * 60 * 60 * 1000 } // 3 horas
};

export default {
  name: "propriedadesrurais",
  description: "Compre e gerencie propriedades rurais para produzir recursos e ganhar Réis.",
  commands: ["fazenda", "sitio", "propriedade"],
  usage: `${PREFIX}fazenda`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const tipoPropriedade = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    if (!db[remoteJid][participant].propriedades) db[remoteJid][participant].propriedades = {};

    if (!acao || acao === "ajuda") {
      let menu = `🌾 *PROPRIEDADES RURAIS IMPERIAIS* 🌾\n\n`;
      menu += `Invista em terras para produção de recursos e renda passiva!\n\n`;
      
      for (const [key, prop] of Object.entries(PROPRIEDADES)) {
        menu += `🏡 *${prop.nome}*\n`;
        menu += `   ↳ Custo: ${prop.custo} Réis\n`;
        menu += `   ↳ Produção Base: ${prop.producaoBase} Réis\n`;
        menu += `   ↳ Tempo de Produção: ${prop.tempoProducao / (60 * 1000)} minutos\n`;
        menu += `🛒 *${PREFIX}fazenda comprar ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}fazenda minhas* para ver suas propriedades e *${PREFIX}fazenda coletar* para pegar a produção._`;
      return await sendReply(menu);
    }

    if (acao === "comprar") {
      if (!PROPRIEDADES[tipoPropriedade]) return await sendWarningReply(`⚠️ Tipo de propriedade inválido!`);
      const prop = PROPRIEDADES[tipoPropriedade];
      
      if (db[remoteJid][participant].saldo < prop.custo) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nCusta *${prop.custo} Réis* para comprar um(a) ${prop.nome}.`);
      }
      
      db[remoteJid][participant].saldo -= prop.custo;
      
      if (!db[remoteJid][participant].propriedades[tipoPropriedade]) {
        db[remoteJid][participant].propriedades[tipoPropriedade] = {
          quantidade: 0,
          ultimaColeta: 0
        };
      }
      db[remoteJid][participant].propriedades[tipoPropriedade].quantidade += 1;
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *COMPRA REALIZADA!*\nVocê comprou 1x *${prop.nome}* por ${prop.custo} Réis.\nComece a coletar sua produção!`);
    }

    if (acao === "minhas") {
      const minhasProps = db[remoteJid][participant].propriedades;
      if (Object.keys(minhasProps).length === 0) return await sendReply("📭 Você não possui nenhuma propriedade rural.");
      
      let msg = `🏡 *SUAS PROPRIEDADES RURAIS* 🏡\n\n`;
      for (const [key, data] of Object.entries(minhasProps)) {
        if (data.quantidade > 0) {
          const prop = PROPRIEDADES[key];
          const tempoRestante = data.ultimaColeta > 0 ? Math.ceil((prop.tempoProducao - (agora - data.ultimaColeta)) / (60 * 1000)) : 0;
          msg += `*${prop.nome}:* ${data.quantidade} unidades\n`;
          msg += `   ↳ Produção por unidade: ${prop.producaoBase} Réis\n`;
          msg += `   ↳ Próxima coleta em: ${tempoRestante > 0 ? `${tempoRestante} minutos` : "PRONTO!"}\n\n`;
        }
      }
      return await sendReply(msg);
    }

    if (acao === "coletar") {
      const minhasProps = db[remoteJid][participant].propriedades;
      if (Object.keys(minhasProps).length === 0) return await sendWarningReply("⚠️ Você não possui propriedades para coletar.");
      
      let totalColetado = 0;
      let msgColeta = "";
      
      for (const [key, data] of Object.entries(minhasProps)) {
        if (data.quantidade > 0) {
          const prop = PROPRIEDADES[key];
          if (agora - data.ultimaColeta >= prop.tempoProducao) {
            const ganho = prop.producaoBase * data.quantidade;
            totalColetado += ganho;
            db[remoteJid][participant].saldo += ganho;
            db[remoteJid][participant].propriedades[key].ultimaColeta = agora;
            msgColeta += `✅ *${prop.nome}:* +${ganho} Réis\n`;
          }
        }
      }
      
      if (totalColetado === 0) {
        return await sendWarningReply("⚠️ Nenhuma propriedade está pronta para coleta ainda. Verifique *fazenda minhas*.");
      }
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`💰 *COLETA REALIZADA!*\n\nVocê coletou a produção de suas propriedades:\n${msgColeta}\n*Total Ganho:* ${totalColetado} Réis!`);
    }
  }
};
