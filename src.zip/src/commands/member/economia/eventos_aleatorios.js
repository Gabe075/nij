import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const EVENTOS = [
  {
    nome: "Chuvas de Moedas",
    descricao: "Uma chuva inesperada de moedas de ouro caiu sobre o reino!",
    efeito: (db, remoteJid, participant) => {
      const ganho = Math.floor(Math.random() * 500) + 200;
      db[remoteJid][participant].saldo += ganho;
      return `Você encontrou *${ganho} Réis* no chão! Que sorte!`;
    },
    chance: 15 // 15% de chance
  },
  {
    nome: "Peste Negra",
    descricao: "Uma terrível praga assola o Império, afetando a economia local.",
    efeito: (db, remoteJid, participant) => {
      const perda = Math.floor(Math.random() * 300) + 100;
      db[remoteJid][participant].saldo = Math.max(0, db[remoteJid][participant].saldo - perda);
      return `Você perdeu *${perda} Réis* em gastos com remédios e perdas comerciais.`;
    },
    chance: 10 // 10% de chance
  },
  {
    nome: "Descoberta de Mina",
    descricao: "Novas minas de ouro foram descobertas nas terras imperiais!",
    efeito: (db, remoteJid, participant) => {
      const ganho = Math.floor(Math.random() * 1000) + 500;
      db[remoteJid][participant].saldo += ganho;
      return `Seu investimento em mineração rendeu *${ganho} Réis*!`;
    },
    chance: 5 // 5% de chance
  },
  {
    nome: "Roubo Real",
    descricao: "O tesouro real foi roubado! A guarda está investigando e pode confiscar bens.",
    efeito: (db, remoteJid, participant) => {
      const perda = Math.floor(Math.random() * 800) + 300;
      db[remoteJid][participant].saldo = Math.max(0, db[remoteJid][participant].saldo - perda);
      return `A guarda confiscou *${perda} Réis* de seus bens para ajudar nas investigações.`;
    },
    chance: 8 // 8% de chance
  }
];

export default {
  name: "evento",
  description: "Aciona um evento aleatório que pode afetar sua economia.",
  commands: ["evento", "sorte"],
  usage: `${PREFIX}evento`,
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    const agora = Date.now();
    const tempoEspera = 2 * 60 * 60 * 1000; // 2 horas
    
    if (db[remoteJid][participant].ultimoEvento) {
      const tempoPassado = agora - db[remoteJid][participant].ultimoEvento;
      if (tempoPassado < tempoEspera) {
        const minutosRestantes = Math.ceil((tempoEspera - tempoPassado) / 60000);
        return await sendReply(`⏳ *O destino ainda está sendo traçado!* Aguarde *${minutosRestantes} minutos* para o próximo evento.`);
      }
    }

    db[remoteJid][participant].ultimoEvento = agora;

    let eventoEscolhido = null;
    let totalChance = 0;
    EVENTOS.forEach(e => totalChance += e.chance);

    let randomNum = Math.floor(Math.random() * totalChance);
    for (const evento of EVENTOS) {
      if (randomNum < evento.chance) {
        eventoEscolhido = evento;
        break;
      }
      randomNum -= evento.chance;
    }

    if (eventoEscolhido) {
      const resultado = eventoEscolhido.efeito(db, remoteJid, participant);
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendReply(`✨ *EVENTO ALEATÓRIO: ${eventoEscolhido.nome}* ✨\n\n${eventoEscolhido.descricao}\n${resultado}`);
    } else {
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendReply("✨ *EVENTO ALEATÓRIO: Dia Comum* ✨\n\nNada de especial aconteceu hoje no Império. Continue suas atividades!");
    }
  }
};
