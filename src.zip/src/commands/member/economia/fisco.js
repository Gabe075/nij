import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
  name: "fisco",
  description: "Declaração de Imposto de Renda Imperial para grandes fortunas.",
  commands: ["fisco", "imposto", "ir"],
  usage: `${PREFIX}fisco`,
  
  handle: async ({ sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return;

    const participant = webMessage.key.participant || remoteJid;

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };

    const carteira = db[remoteJid][participant].saldo || 0;
    const banco = db[remoteJid][participant].banco || 0;
    const patrimonio = carteira + banco;

    const agora = Date.now();
    const seteDias = 7 * 24 * 60 * 60 * 1000;
    const ultimaTaxa = db[remoteJid][participant].ultimoImposto || 0;

    if (patrimonio < 50000) {
      return await sendReply(`📜 *MINISTÉRIO DA FAZENDA*\n\nSeu patrimônio é de *${patrimonio} Réis*. Você está isento de impostos por possuir menos de 50.000 Réis.`);
    }

    if (agora - ultimaTaxa < seteDias) {
      const diasRestantes = Math.ceil((seteDias - (agora - ultimaTaxa)) / (24 * 60 * 60 * 1000));
      return await sendReply(`📜 *MINISTÉRIO DA FAZENDA*\n\nSeus impostos estão em dia. A próxima declaração obrigatória será em *${diasRestantes} dias*.`);
    }

    // Taxa de 5% sobre o patrimônio acima de 50k
    const valorTaxado = patrimonio - 50000;
    const imposto = Math.floor(valorTaxado * 0.05);

    let msg = `📜 *DECLARAÇÃO DE IMPOSTO DE RENDA* 📜\n\n`;
    msg += `Patrimônio Declarado: *${patrimonio} Réis*\n`;
    msg += `Faixa de Tributação: *5%* (Acima de 50k)\n`;
    msg += `Valor do Imposto: 💰 *${imposto} Réis*\n\n`;
    msg += `_O valor será descontado automaticamente do seu banco para financiar as obras do Império._`;

    if (db[remoteJid][participant].banco >= imposto) {
      db[remoteJid][participant].banco -= imposto;
    } else {
      const resto = imposto - db[remoteJid][participant].banco;
      db[remoteJid][participant].banco = 0;
      db[remoteJid][participant].saldo = Math.max(0, db[remoteJid][participant].saldo - resto);
    }

    db[remoteJid][participant].ultimoImposto = agora;
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    await sendSuccessReply(msg);
  }
};
