import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const RECEITAS = {
  "pocao_simples": {
    nome: "Poção de Cura Simples 🧪",
    recursos: { "ervas": 2, "agua": 1 },
    valorVenda: 150,
    tempoFabricacao: 5 * 60 * 1000 // 5 minutos
  },
  "espada_ferro": {
    nome: "Espada de Ferro ⚔️",
    recursos: { "ferro": 3, "carvao": 2 },
    valorVenda: 500,
    tempoFabricacao: 15 * 60 * 1000 // 15 minutos
  },
  "armadura_couro": {
    nome: "Armadura de Couro 🛡️",
    recursos: { "couro": 4, "linha": 1 },
    valorVenda: 700,
    tempoFabricacao: 20 * 60 * 1000 // 20 minutos
  },
};

export default {
  name: "artesanato",
  description: "Crie itens a partir de recursos coletados e venda-os ou use-os.",
  commands: ["artesanato", "craft", "fabricar"],
  usage: `${PREFIX}artesanato`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const itemReceita = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, inventario: {} };
    if (!db[remoteJid][participant].artesanato) db[remoteJid][participant].artesanato = { fabricando: null, fila: [] };

    const agora = Date.now();

    // Processa item em fabricação
    if (db[remoteJid][participant].artesanato.fabricando && db[remoteJid][participant].artesanato.fabricando.termina <= agora) {
      const itemFabricado = db[remoteJid][participant].artesanato.fabricando.item;
      const receita = RECEITAS[itemFabricado];
      
      db[remoteJid][participant].inventario[itemFabricado] = (db[remoteJid][participant].inventario[itemFabricado] || 0) + 1;
      await sendReply(`✅ *FABRICAÇÃO CONCLUÍDA!*\nSeu item *${receita.nome}* está pronto e foi adicionado ao seu inventário!`);
      
      db[remoteJid][participant].artesanato.fabricando = null;
      // Inicia o próximo da fila, se houver
      if (db[remoteJid][participant].artesanato.fila.length > 0) {
        const proximoItem = db[remoteJid][participant].artesanato.fila.shift();
        const proximaReceita = RECEITAS[proximoItem];
        db[remoteJid][participant].artesanato.fabricando = {
          item: proximoItem,
          termina: agora + proximaReceita.tempoFabricacao
        };
        await sendReply(`🛠️ *NOVA FABRICAÇÃO INICIADA!*\nComeçou a fabricar *${proximaReceita.nome}*. Estará pronto em ${proximaReceita.tempoFabricacao / (60 * 1000)} minutos.`);
      }
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
    }

    if (!acao || acao === "ajuda") {
      let menu = `🛠️ *SISTEMA DE ARTESANATO IMPERIAL* 🛠️\n\n`;
      menu += `Transforme recursos brutos em itens valiosos!\n\n`;
      
      for (const [key, rec] of Object.entries(RECEITAS)) {
        menu += `📦 *${rec.nome}*\n`;
        menu += `   ↳ Recursos Necessários: ${Object.entries(rec.recursos).map(([res, qtd]) => `${qtd}x ${res}`).join(", ")}\n`;
        menu += `   ↳ Tempo de Fabricação: ${rec.tempoFabricacao / (60 * 1000)} minutos\n`;
        menu += `   ↳ Valor de Venda: ${rec.valorVenda} Réis\n`;
        menu += `🔨 *${PREFIX}artesanato fabricar ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}artesanato status* para ver o que está fabricando._`;
      return await sendReply(menu);
    }

    if (acao === "fabricar") {
      if (!RECEITAS[itemReceita]) return await sendWarningReply(`⚠️ Receita inválida!`);
      const receita = RECEITAS[itemReceita];

      // Verifica recursos
      for (const res in receita.recursos) {
        if ((db[remoteJid][participant].inventario[res] || 0) < receita.recursos[res]) {
          return await sendWarningReply(`⚠️ Você não tem recursos suficientes para fabricar *${receita.nome}*. Faltam ${receita.recursos[res] - (db[remoteJid][participant].inventario[res] || 0)}x ${res}.`);
        }
      }

      // Consome recursos
      for (const res in receita.recursos) {
        db[remoteJid][participant].inventario[res] -= receita.recursos[res];
      }

      if (db[remoteJid][participant].artesanato.fabricando) {
        db[remoteJid][participant].artesanato.fila.push(itemReceita);
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendSuccessReply(`✅ *ITEM ADICIONADO À FILA!*\n*${receita.nome}* foi adicionado à sua fila de fabricação.`);
      } else {
        db[remoteJid][participant].artesanato.fabricando = {
          item: itemReceita,
          termina: agora + receita.tempoFabricacao
        };
        fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
        return await sendSuccessReply(`🛠️ *FABRICAÇÃO INICIADA!*\nComeçou a fabricar *${receita.nome}*. Estará pronto em ${receita.tempoFabricacao / (60 * 1000)} minutos.`);
      }
    }

    if (acao === "status") {
      let msg = `🛠️ *STATUS DE ARTESANATO* 🛠️\n\n`;
      if (db[remoteJid][participant].artesanato.fabricando) {
        const item = db[remoteJid][participant].artesanato.fabricando.item;
        const receita = RECEITAS[item];
        const tempoRestante = Math.ceil((db[remoteJid][participant].artesanato.fabricando.termina - agora) / (60 * 1000));
        msg += `Fabricando: *${receita.nome}*\n`;
        msg += `   ↳ Tempo Restante: ${tempoRestante} minutos\n\n`;
      } else {
        msg += `Nenhum item sendo fabricado no momento.\n\n`;
      }

      if (db[remoteJid][participant].artesanato.fila.length > 0) {
        msg += `Fila de Fabricação:\n`;
        db[remoteJid][participant].artesanato.fila.forEach((item, index) => {
          msg += `   ${index + 1}. ${RECEITAS[item].nome}\n`;
        });
      } else {
        msg += `Fila de fabricação vazia.`;
      }
      return await sendReply(msg);
    }
  }
};
