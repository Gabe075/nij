import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";
import { PROFISSOES } from "./empregos/empregos.js";
import { PETS } from "./lojas/pets.js"; // Assumindo que pets.js estará em lojas/

const ecoPath = path.resolve("database", "economia.json");
const levelsPath = path.resolve("database", "levels.json");
const familiasPath = path.resolve("database", "familias.json");
const casamentosPath = path.resolve("database", "casamentos.json");

function getTituloNobreza(level) {
  if (level < 5) return "Plebeu 🧑‍🌾";
  if (level < 10) return "Escudeiro 🛡️";
  if (level < 15) return "Cavaleiro ⚔️";
  if (level < 20) return "Barão 🎩";
  if (level < 30) return "Visconde 🧐";
  if (level < 40) return "Conde 🍷";
  if (level < 50) return "Marquês 📜";
  if (level < 70) return "Duque 🏰";
  return "Grão-Duque 👑";
}

export default {
  name: "perfil",
  description: "Mostra o seu perfil completo no Império.",
  commands: ["perfil", "status", "rg"],
  usage: `${PREFIX}perfil`,
  
  handle: async ({ sendReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendReply("⚠️ Este comando só pode ser usado em grupos.");

    const participant = webMessage.key.participant || remoteJid;

    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, banco: 0 };

    let level = 1;
    let xp = 0;
    if (fs.existsSync(levelsPath)) {
      const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
      if (levelsDB[remoteJid] && levelsDB[remoteJid][participant]) {
        level = levelsDB[remoteJid][participant].level || 1;
        xp = levelsDB[remoteJid][participant].xp || 0;
      }
    }

    const xpProximoNivel = (level - 1) * 400 + 300;
    const titulo = getTituloNobreza(level);
    
    const profKey = db[remoteJid][participant].profissao;
    const profissaoNome = profKey && PROFISSOES[profKey] ? PROFISSOES[profKey].nome : "Desempregado";

    const petKey = db[remoteJid][participant].pet;
    const petNome = petKey && PETS[petKey] ? PETS[petKey].nome : "Nenhum";

    const carteira = db[remoteJid][participant].saldo || 0;
    const banco = db[remoteJid][participant].banco || 0;
    const patrimonio = carteira + banco;

    // 🏡 Conta os Imóveis
    const meusImoveis = db[remoteJid][participant].imoveis || {};
    const qtdImoveis = Object.values(meusImoveis).reduce((acc, val) => acc + val, 0);

    let msg = `⚜️ *PERFIL IMPERIAL* ⚜️\n\n`;
    msg += `👤 *Cidadão:* @${participant.split("@")[0]}\n`;
    msg += `👑 *Título:* ${titulo}\n`;
    msg += `💼 *Profissão:* ${profissaoNome}\n`;
    msg += `🐾 *Mascote:* ${petNome}\n`;
    msg += `🏡 *Imóveis:* ${qtdImoveis}\n`;

    const minhaFamiliaId = db[remoteJid][participant].familia;
    if (minhaFamiliaId && fs.existsSync(familiasPath)) {
      const famDB = JSON.parse(fs.readFileSync(familiasPath, "utf-8"));
      if (famDB[remoteJid] && famDB[remoteJid][minhaFamiliaId]) {
        msg += `⚔️ *Família:* ${famDB[remoteJid][minhaFamiliaId].nome}\n`;
      }
    }

    const meuCasamentoId = db[remoteJid][participant].casamento;
    if (meuCasamentoId && fs.existsSync(casamentosPath)) {
      const casDB = JSON.parse(fs.readFileSync(casamentosPath, "utf-8"));
      if (casDB[remoteJid] && casDB[remoteJid][meuCasamentoId]) {
        const cas = casDB[remoteJid][meuCasamentoId];
        const parceiro = cas.parceiro1 === participant ? cas.parceiro2 : cas.parceiro1;
        const qtdFilhos = cas.filhos ? cas.filhos.length : 0;
        msg += `💍 *Casado(a) com:* @${parceiro.split("@")[0]}\n`;
        msg += `👶 *Filhos:* ${qtdFilhos}\n`;
      }
    }

    msg += `\n🌟 *Nível:* ${level}\n`;
    msg += `✨ *XP:* ${xp} / ${xpProximoNivel} _(Faltam ${xpProximoNivel - xp})_\n\n`;
    msg += `👛 *Carteira:* ${carteira} Réis\n`;
    msg += `🏛️ *Banco:* ${banco} Réis\n`;
    msg += `📊 *Patrimônio:* ${patrimonio} Réis\n`;

    await sendReply(msg, [participant]);
  }
};
