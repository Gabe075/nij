import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");
const arenaPath = path.resolve("database", "arena.json");

export default {
  name: "arena",
  description: "Desafie outros jogadores para duelos na Arena Imperial e ganhe recompensas.",
  commands: ["arena", "duelo", "batalha"],
  usage: `${PREFIX}arena`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup, mentionedJidList }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const alvoJid = mentionedJidList[0];
    const valorAposta = parseInt(parts[1], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };

    let arenaDB = {};
    if (fs.existsSync(arenaPath)) arenaDB = JSON.parse(fs.readFileSync(arenaPath, "utf-8"));
    if (!arenaDB[remoteJid]) arenaDB[remoteJid] = { desafios: {} };

    if (!acao || acao === "ajuda") {
      let menu = `⚔️ *ARENA IMPERIAL* ⚔️\n\n`;
      menu += `Desafie outros jogadores para duelos emocionantes!\n\n`;
      menu += `🔸 *${PREFIX}arena desafiar @jogador <aposta>* - Desafia um jogador para um duelo\n`;
      menu += `🔸 *${PREFIX}arena aceitar @desafiante* - Aceita um desafio pendente\n`;
      menu += `🔸 *${PREFIX}arena recusar @desafiante* - Recusa um desafio\n`;
      menu += `🔸 *${PREFIX}arena meusdesafios* - Veja seus desafios pendentes\n`;
      return await sendReply(menu);
    }

    if (acao === "desafiar") {
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque o jogador que deseja desafiar.\nExemplo: *${PREFIX}arena desafiar @jogador 1000*`);
      if (alvoJid === participant) return await sendWarningReply("⚠️ Você não pode desafiar a si mesmo.");
      if (isNaN(valorAposta) || valorAposta <= 0) return await sendWarningReply(`⚠️ Digite um valor de aposta válido.\nExemplo: *${PREFIX}arena desafiar @jogador 1000*`);

      if (db[remoteJid][participant].saldo < valorAposta) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${valorAposta} Réis* para fazer esta aposta.`);
      }
      if (db[remoteJid][alvoJid] && db[remoteJid][alvoJid].saldo < valorAposta) {
        return await sendWarningReply(`⚠️ O desafiado @${alvoJid.split("@")[0]} não possui *${valorAposta} Réis* para cobrir a aposta.`);
      }

      const desafioId = `${participant}-${alvoJid}`;
      if (arenaDB[remoteJid].desafios[desafioId]) return await sendWarningReply("⚠️ Já existe um desafio pendente entre vocês.");

      arenaDB[remoteJid].desafios[desafioId] = {
        desafiante: participant,
        desafiado: alvoJid,
        aposta: valorAposta,
        data: Date.now()
      };
      fs.writeFileSync(arenaPath, JSON.stringify(arenaDB, null, 2));
      return await sendSuccessReply(`⚔️ *DESAFIO LANÇADO!* ⚔️\n\n@${participant.split("@")[0]} desafiou @${alvoJid.split("@")[0]} para um duelo valendo *${valorAposta} Réis*!\n@${alvoJid.split("@")[0]}, use *${PREFIX}arena aceitar @${participant.split("@")[0]}* ou *${PREFIX}arena recusar @${participant.split("@")[0]}*.`, [alvoJid, participant]);
    }

    if (acao === "aceitar") {
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque o desafiante.\nExemplo: *${PREFIX}arena aceitar @desafiante*`);
      const desafioId = `${alvoJid}-${participant}`;
      const desafio = arenaDB[remoteJid].desafios[desafioId];

      if (!desafio || desafio.desafiado !== participant) return await sendWarningReply("⚠️ Você não tem um desafio pendente deste jogador.");

      // Verifica se ambos têm o dinheiro
      if (db[remoteJid][desafio.desafiante].saldo < desafio.aposta) {
        delete arenaDB[remoteJid].desafios[desafioId];
        fs.writeFileSync(arenaPath, JSON.stringify(arenaDB, null, 2));
        return await sendWarningReply(`⚠️ O desafiante @${desafio.desafiante.split("@")[0]} não possui mais *${desafio.aposta} Réis* para a aposta. Desafio cancelado.`, [desafio.desafiante]);
      }
      if (db[remoteJid][participant].saldo < desafio.aposta) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê não possui *${desafio.aposta} Réis* para cobrir a aposta.`);
      }

      // Realiza o duelo
      db[remoteJid][desafio.desafiante].saldo -= desafio.aposta;
      db[remoteJid][participant].saldo -= desafio.aposta;

      const vencedor = Math.random() < 0.5 ? participant : desafio.desafiante;
      const perdedor = vencedor === participant ? desafio.desafiante : participant;
      const premio = desafio.aposta * 2;

      db[remoteJid][vencedor].saldo += premio;
      delete arenaDB[remoteJid].desafios[desafioId];
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      fs.writeFileSync(arenaPath, JSON.stringify(arenaDB, null, 2));

      return await sendSuccessReply(`🎉 *DUELO REALIZADO!* 🎉\n\n@${vencedor.split("@")[0]} venceu o duelo contra @${perdedor.split("@")[0]} e ganhou *${premio} Réis*!`, [vencedor, perdedor]);
    }

    if (acao === "recusar") {
      if (!alvoJid) return await sendWarningReply(`⚠️ Marque o desafiante.\nExemplo: *${PREFIX}arena recusar @desafiante*`);
      const desafioId = `${alvoJid}-${participant}`;
      const desafio = arenaDB[remoteJid].desafios[desafioId];

      if (!desafio || desafio.desafiado !== participant) return await sendWarningReply("⚠️ Você não tem um desafio pendente deste jogador.");

      delete arenaDB[remoteJid].desafios[desafioId];
      fs.writeFileSync(arenaPath, JSON.stringify(arenaDB, null, 2));
      return await sendReply(`❌ *DESAFIO RECUSADO!* ❌\n\nVocê recusou o desafio de @${alvoJid.split("@")[0]}.`, [alvoJid]);
    }

    if (acao === "meusdesafios") {
      const meusDesafios = Object.values(arenaDB[remoteJid].desafios).filter(d => d.desafiado === participant || d.desafiante === participant);
      if (meusDesafios.length === 0) return await sendReply("Você não possui desafios pendentes.");

      let msg = `📜 *SEUS DESAFIOS PENDENTES* 📜\n\n`;
      meusDesafios.forEach(d => {
        const tipo = d.desafiante === participant ? "(Você desafiou)" : "(Você foi desafiado)";
        const outro = d.desafiante === participant ? d.desafiado : d.desafiante;
        msg += `⚔️ *Desafio:* ${tipo}\n`;
        msg += `   ↳ Contra: @${outro.split("@")[0]}\n`;
        msg += `   ↳ Aposta: ${d.aposta} Réis\n\n`;
      });
      return await sendReply(msg, meusDesafios.map(d => d.desafiante).concat(meusDesafios.map(d => d.desafiado)));
    }
  }
};
