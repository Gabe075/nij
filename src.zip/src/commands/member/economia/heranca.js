import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "heranca",
    description: "Defina herdeiros para seus bens no império.",
    commands: ["heranca", "testamento"],
    usage: `${PREFIX}heranca`,
    handle: async ({ sendReply }) => {
        return await sendReply("📜 *TESTAMENTO REAL* 📜\nGaranta que seus bens fiquem na família!");
    }
};
