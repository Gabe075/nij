import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "wiki",
    description: "Enciclopédia Imperial de itens e recursos.",
    commands: ["wiki", "infoitem"],
    usage: `${PREFIX}wiki <item>`,
    handle: async ({ fullArgs, sendReply }) => {
        return await sendReply("📖 *WIKI IMPERIAL* 📖\nConsulte informações sobre qualquer item do bot!");
    }
};
