import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

export default {
    name: "pescalendaria",
    description: "Pescaria em alto mar para capturar peixes lendários.",
    commands: ["pescalendaria", "altomar"],
    usage: `${PREFIX}pescalendaria`,
    handle: async ({ sendReply }) => {
        return await sendReply("🎣 *EXPEDIÇÃO DE PESCA LENDÁRIA* 🎣\nEm breve: Capture o Kraken e outros peixes míticos!");
    }
};
