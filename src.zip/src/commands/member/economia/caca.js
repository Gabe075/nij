import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const ANIMAIS_CACADOS = {
  "coelho": {
    nome: "Coelho 🐇",
    recompensaMin: 50,
    recompensaMax: 150,
    recursos: { "carne": 1, "pele": 1 },
    chanceItemRaro: 5,
    itemRaro: "pe_de_coelho",
    tempoEspera: 5 * 60 * 1000 // 5 minutos
  },
  "javali": {
    nome: "Javali 🐗",
    recompensaMin: 200,
    recompensaMax: 500,
    recursos: { "carne": 3, "couro": 2 },
    chanceItemRaro: 10,
    itemRaro: "presa_javali",
    tempoEspera: 15 * 60 * 1000 // 15 minutos
  },
  "urso": {
    nome: "Urso 🐻",
    recompensaMin: 800,
    recompensaMax: 1500,
    recursos: { "carne": 5, "pele_urso": 1 },
    chanceItemRaro: 20,
    itemRaro: "garra_urso",
    tempoEspera: 30 * 60 * 1000 // 30 minutos
  },
};

export default {
  name: "caca",
  description: "Vá caçar animais selvagens para obter carne, peles e itens raros.",
  commands: ["caca", "cacar", "floresta"],
  usage: `${PREFIX}caca`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const animalAlvo = parts[1]?.toLowerCase();
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0, inventario: {} };

    const agora = Date.now();

    if (!acao || acao === "ajuda") {
      let menu = `🏹 *CAÇA IMPERIAL* 🏹\n\n`;
      menu += `Aventure-se na floresta para caçar animais e coletar recursos!\n\n`;
      
      for (const [key, animal] of Object.entries(ANIMAIS_CACADOS)) {
        menu += `🦌 *${animal.nome}*\n`;
        menu += `   ↳ Recompensa: ${animal.recompensaMin}-${animal.recompensaMax} Réis\n`;
        menu += `   ↳ Recursos: ${Object.entries(animal.recursos).map(([res, qtd]) => `${qtd}x ${res}`).join(", ")}\n`;
        menu += `   ↳ Chance de Item Raro: ${animal.chance}% (${animal.itemRaro})\n`;
        menu += `   ↳ Tempo de Espera: ${animal.tempoEspera / (60 * 1000)} minutos\n`;
        menu += `🎯 *${PREFIX}caca ${key}*\n\n`;
      }
      
      menu += `_Use *${PREFIX}inventario* para ver seus recursos e itens raros._`;
      return await sendReply(menu);
    }

    if (ANIMAIS_CACADOS[acao]) {
      const animal = ANIMAIS_CACADOS[acao];
      
      if (db[remoteJid][participant].ultimaCaca && agora - db[remoteJid][participant].ultimaCaca < animal.tempoEspera) {
        const minutosRestantes = Math.ceil((animal.tempoEspera - (agora - db[remoteJid][participant].ultimaCaca)) / (60 * 1000));
        return await sendReply(`⏳ *Você está exausto da última caçada!* Aguarde *${minutosRestantes} minutos* para caçar novamente.`);
      }

      db[remoteJid][participant].ultimaCaca = agora;
      
      let msgResultado = `🏹 Você saiu para caçar um *${animal.nome}*...\n\n`;
      let ganho = Math.floor(Math.random() * (animal.recompensaMax - animal.recompensaMin)) + animal.recompensaMin;
      db[remoteJid][participant].saldo += ganho;
      msgResultado += `💰 Você vendeu a carne e ganhou *${ganho} Réis*!\n`;

      for (const recurso in animal.recursos) {
        const qtdRecurso = animal.recursos[recurso];
        db[remoteJid][participant].inventario[recurso] = (db[remoteJid][participant].inventario[recurso] || 0) + qtdRecurso;
        msgResultado += `📦 Você coletou *${qtdRecurso}x ${recurso}*!\n`;
      }

      const chanceItem = Math.floor(Math.random() * 100);
      if (chanceItem < animal.chanceItemRaro) {
        db[remoteJid][participant].inventario[animal.itemRaro] = (db[remoteJid][participant].inventario[animal.itemRaro] || 0) + 1;
        msgResultado += `✨ Você encontrou um item raro: *${animal.itemRaro}*!\n`;
      }
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(msgResultado);
    }

    return await sendWarningReply(`⚠️ Comando inválido ou animal não encontrado. Use *${PREFIX}caca* para ver as opções.`);
  }
};
