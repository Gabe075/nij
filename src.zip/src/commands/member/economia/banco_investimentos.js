import fs from "fs";
import path from "path";
import { PREFIX } from "../../../config.js";

const ecoPath = path.resolve("database", "economia.json");

const INVESTIMENTOS = {
  "renda_fixa": {
    nome: "Renda Fixa 📈",
    minimo: 1000,
    jurosAnual: 0.10, // 10% ao ano
    tempoMinimo: 7 * 24 * 60 * 60 * 1000 // 7 dias
  },
  "imobiliario": {
    nome: "Fundo Imobiliário 🏢",
    minimo: 5000,
    jurosAnual: 0.15, // 15% ao ano
    tempoMinimo: 30 * 24 * 60 * 60 * 1000 // 30 dias
  },
  "ouro": {
    nome: "Fundo de Ouro 🥇",
    minimo: 10000,
    jurosAnual: 0.20, // 20% ao ano
    tempoMinimo: 60 * 24 * 60 * 60 * 1000 // 60 dias
  },
};

export default {
  name: "bancoinvestimentos",
  description: "Invista seu dinheiro em opções de longo prazo para obter rendimentos.",
  commands: ["investirbanco", "bancoinvest", "aplicar"],
  usage: `${PREFIX}bancoinvestimentos`,
  handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
    if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
    
    const participant = webMessage.key.participant || remoteJid;
    const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
    const acao = parts[0]?.toLowerCase();
    const tipoInvestimento = parts[1]?.toLowerCase();
    const valor = parseInt(parts[2], 10);
    
    let db = {};
    if (fs.existsSync(ecoPath)) db = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
    if (!db[remoteJid]) db[remoteJid] = {};
    if (!db[remoteJid][participant]) db[remoteJid][participant] = { saldo: 0 };
    if (!db[remoteJid][participant].investimentos) db[remoteJid][participant].investimentos = {};

    const agora = Date.now();

    // Processa rendimentos
    for (const invKey in db[remoteJid][participant].investimentos) {
      const invData = db[remoteJid][participant].investimentos[invKey];
      const invInfo = INVESTIMENTOS[invKey];

      if (invData.valor > 0 && agora - invData.ultimaAtualizacao >= invInfo.tempoMinimo) {
        const tempoPassado = agora - invData.ultimaAtualizacao;
        const rendimento = invData.valor * (invInfo.jurosAnual / (365 * 24 * 60 * 60 * 1000)) * tempoPassado; // Rendimento proporcional ao tempo
        db[remoteJid][participant].saldo += rendimento;
        invData.valor += rendimento;
        invData.ultimaAtualizacao = agora;
        await sendReply(`💰 *RENDIMENTO DE INVESTIMENTO!*\nSeu investimento em *${invInfo.nome}* rendeu *${rendimento.toFixed(2)} Réis*!`);
      }
    }
    fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));

    if (!acao || acao === "ajuda") {
      let menu = `🏦 *BANCO DE INVESTIMENTOS IMPERIAL* 🏦\n\n`;
      menu += `Faça seu dinheiro trabalhar para você com investimentos de longo prazo!\n\n`;
      
      for (const [key, inv] of Object.entries(INVESTIMENTOS)) {
        menu += `📊 *${inv.nome}*\n`;
        menu += `   ↳ Investimento Mínimo: ${inv.minimo} Réis\n`;
        menu += `   ↳ Juros Anual: ${(inv.jurosAnual * 100).toFixed(0)}%\n`;
        menu += `   ↳ Tempo Mínimo: ${inv.tempoMinimo / (24 * 60 * 60 * 1000)} dias\n`;
        menu += `📈 *${PREFIX}bancoinvestimentos aplicar ${key} <valor>*\n\n`;
      }
      
      menu += `_Use *${PREFIX}bancoinvestimentos meus* para ver seus investimentos._`;
      return await sendReply(menu);
    }

    if (acao === "aplicar") {
      if (!INVESTIMENTOS[tipoInvestimento]) return await sendWarningReply(`⚠️ Tipo de investimento inválido!`);
      const inv = INVESTIMENTOS[tipoInvestimento];
      
      if (isNaN(valor) || valor < inv.minimo) {
        return await sendWarningReply(`⚠️ O valor mínimo para *${inv.nome}* é de *${inv.minimo} Réis*.`);
      }
      
      if (db[remoteJid][participant].saldo < valor) {
        return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê só tem *${db[remoteJid][participant].saldo} Réis* na carteira.`);
      }
      
      db[remoteJid][participant].saldo -= valor;
      db[remoteJid][participant].investimentos[tipoInvestimento] = {
        valor: (db[remoteJid][participant].investimentos[tipoInvestimento]?.valor || 0) + valor,
        ultimaAtualizacao: agora
      };
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`✅ *INVESTIMENTO REALIZADO!*\nVocê aplicou *${valor} Réis* em *${inv.nome}*. Seus rendimentos começarão a ser calculados após ${inv.tempoMinimo / (24 * 60 * 60 * 1000)} dias!`);
    }

    if (acao === "resgatar") {
      if (!INVESTIMENTOS[tipoInvestimento]) return await sendWarningReply(`⚠️ Tipo de investimento inválido!`);
      const inv = INVESTIMENTOS[tipoInvestimento];
      
      if (!db[remoteJid][participant].investimentos[tipoInvestimento] || db[remoteJid][participant].investimentos[tipoInvestimento].valor <= 0) {
        return await sendWarningReply(`⚠️ Você não possui investimentos em *${inv.nome}*.`);
      }

      const invData = db[remoteJid][participant].investimentos[tipoInvestimento];
      if (agora - invData.ultimaAtualizacao < inv.tempoMinimo) {
        const tempoRestante = Math.ceil((inv.tempoMinimo - (agora - invData.ultimaAtualizacao)) / (24 * 60 * 60 * 1000));
        return await sendWarningReply(`⚠️ Você só pode resgatar seu investimento em *${inv.nome}* após *${tempoRestante} dias*.`);
      }

      const valorResgatado = invData.valor;
      db[remoteJid][participant].saldo += valorResgatado;
      delete db[remoteJid][participant].investimentos[tipoInvestimento];
      
      fs.writeFileSync(ecoPath, JSON.stringify(db, null, 2));
      return await sendSuccessReply(`💰 *RESGATE REALIZADO!*\nVocê resgatou *${valorResgatado.toFixed(2)} Réis* do seu investimento em *${inv.nome}*!`);
    }

    if (acao === "meus") {
      const meusInvestimentos = db[remoteJid][participant].investimentos;
      if (Object.keys(meusInvestimentos).length === 0) return await sendReply("📭 Você não possui nenhum investimento ativo.");
      
      let msg = `📊 *SEUS INVESTIMENTOS ATIVOS* 📊\n\n`;
      for (const [key, data] of Object.entries(meusInvestimentos)) {
        const inv = INVESTIMENTOS[key];
        const tempoRestante = Math.ceil((inv.tempoMinimo - (agora - data.ultimaAtualizacao)) / (24 * 60 * 60 * 1000));
        msg += `📈 *${inv.nome}*\n`;
        msg += `   ↳ Valor Aplicado: ${data.valor.toFixed(2)} Réis\n`;
        msg += `   ↳ Juros Anual: ${(inv.jurosAnual * 100).toFixed(0)}%\n`;
        msg += `   ↳ Resgate disponível em: ${tempoRestante > 0 ? `${tempoRestante} dias` : "AGORA!"}\n\n`;
      }
      return await sendReply(msg);
    }
  }
};
