import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { getStardewData, saveStardewDB, gastarEnergia, ESTACOES } from "../../../../lib/StardewUtils.js";
import { CULTIVOS } from "../../../../lib/Cultivos.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
    name: "fazenda",
    description: "Gerencie sua fazenda estilo Stardew Valley.",
    commands: ["fazenda", "plantar", "colher", "regar", "statusfazenda"],
    usage: `${PREFIX}fazenda`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
        if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
        
        const participant = webMessage.key.participant || remoteJid;
        const { global, user, db: stardewDB } = getStardewData(remoteJid, participant);
        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        let ecoDB = {};
        if (fs.existsSync(ecoPath)) ecoDB = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
        
        // Travas de segurança contra Undefined
        if (!ecoDB[remoteJid]) ecoDB[remoteJid] = {};
        if (!ecoDB[remoteJid][participant]) ecoDB[remoteJid][participant] = { saldo: 0, nivel: 1, xp: 0, inventario: {} };
        
        // SISTEMA DE COMPRA DA FAZENDA (CAPITALISMO)
        if (acao === "comprar_escritura") {
            const CUSTO_FAZENDA = 45000;
            if (user.fazendaComprada) return await sendWarningReply("Você já é dono de uma fazenda!");
            
            if (ecoDB[remoteJid][participant].saldo < CUSTO_FAZENDA) {
                return await sendWarningReply(`💸 *Saldo Insuficiente!*\nVocê precisa de *${CUSTO_FAZENDA} Réis* para comprar a escritura da fazenda. (Seu saldo atual: ${ecoDB[remoteJid][participant].saldo})`);
            }
            
            ecoDB[remoteJid][participant].saldo -= CUSTO_FAZENDA;
            user.fazendaComprada = true;
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            saveStardewDB(stardewDB);
            return await sendSuccessReply(`🎉 *ESCRITURA ADQUIRIDA!* 🎉\nVocê comprou a sua Fazenda Imperial por ${CUSTO_FAZENDA} Réis!\nAgora você pode plantar, colher e construir o seu império agrícola. Use *${PREFIX}fazenda loja* para comprar sementes.`);
        }

        // Bloqueio para quem não comprou
        if (!user.fazendaComprada && acao !== "ajuda" && acao !== undefined) {
            return await sendWarningReply(`🔒 *Acesso Negado!*\nVocê precisa comprar a escritura da fazenda para acessar essas opções.\nCusto: 45.000 Réis.\nComando: *${PREFIX}fazenda comprar_escritura*`);
        }

        // MENU PRINCIPAL
        if (!acao || acao === "ajuda") {
            let menu = `🚜 *SUA FAZENDA IMPERIAL* 🚜\n\n`;
            if (!user.fazendaComprada) {
                menu += `⚠️ *Você ainda não possui a escritura da fazenda!*\n`;
                menu += `💰 Custo: 45.000 Réis\n`;
                menu += `🛒 Compre com: *${PREFIX}fazenda comprar_escritura*\n\n`;
            } else {
                menu += `📅 *Estação:* ${global.estacao} | *Dia:* ${global.dia}\n`;
                menu += `⚡ *Energia:* ${user.energia}/${user.energiaMax}\n`;
                menu += `🌟 *Nível de Fazendeiro:* ${user.nivelFazenda} (${user.xpFazenda} XP)\n\n`;
                
                menu += `🔸 *${PREFIX}fazenda status* - Ver seus cultivos\n`;
                menu += `🔸 *${PREFIX}fazenda loja* - Comprar sementes\n`;
                menu += `🔸 *${PREFIX}fazenda plantar <item>* - Plantar uma semente\n`;
                menu += `🔸 *${PREFIX}fazenda regar* - Regar todos os seus cultivos\n`;
                menu += `🔸 *${PREFIX}fazenda colher* - Colher cultivos prontos\n`;
                menu += `🔸 *${PREFIX}fazenda comer <item>* - Recuperar energia\n`;
            }
            return await sendReply(menu);
        }

        if (acao === "status") {
            if (user.fazenda.length === 0) return await sendReply("📭 Sua fazenda está vazia. Compre sementes na loja!");
            
            let msg = `🌱 *CULTIVOS EM ANDAMENTO* 🌱\n\n`;
            user.fazenda.forEach((c, index) => {
                const cult = CULTIVOS[c.item];
                const diasPassados = global.dia - c.diaPlantio + (global.estacaoId - c.estacao) * 28;
                const pronto = diasPassados >= cult.diasParaCrescer;
                
                msg += `${index + 1}. *${cult.nome}*\n`;
                msg += `   ↳ Status: ${pronto ? "✅ Pronto para colher!" : `⏳ Crescendo (${diasPassados}/${cult.diasParaCrescer} dias)`}\n`;
                msg += `   ↳ Regado: ${c.regado ? "💧 Sim" : "❌ Não (Não crescerá hoje)"}\n\n`;
            });
            return await sendReply(msg);
        }

        if (acao === "loja") {
            let msg = `🏪 *ARMAZÉM DO PIERRE IMPERIAL* 🏪\n\n`;
            msg += `Sementes disponíveis para a estação: *${global.estacao}*\n\n`;
            
            for (const [key, c] of Object.entries(CULTIVOS)) {
                if (c.estacao === global.estacaoId) {
                    msg += `📦 *${c.nome}*\n`;
                    msg += `   ↳ Preço: ${c.precoSemente} Réis\n`;
                    msg += `   ↳ Crescimento: ${c.diasParaCrescer} dias\n`;
                    msg += `🛒 *${PREFIX}fazenda comprar ${key}*\n\n`;
                }
            }
            return await sendReply(msg);
        }

        if (acao === "comprar") {
            const item = parts[1]?.toLowerCase();
            if (!CULTIVOS[item]) return await sendWarningReply("⚠️ Item inválido!");
            if (CULTIVOS[item].estacao !== global.estacaoId) return await sendWarningReply("⚠️ Esta semente não é desta estação!");
            
            const preco = CULTIVOS[item].precoSemente;
            if (ecoDB[remoteJid][participant].saldo < preco) return await sendWarningReply(`💸 Saldo insuficiente! Você precisa de ${preco} Réis.`);
            
            ecoDB[remoteJid][participant].saldo -= preco;
            user.inventario[item] = (user.inventario[item] || 0) + 1;
            
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            saveStardewDB(stardewDB);
            return await sendSuccessReply(`✅ Você comprou 1x semente de *${CULTIVOS[item].nome}*!`);
        }

        if (acao === "plantar") {
            const item = parts[1]?.toLowerCase();
            if (!user.inventario[item] || user.inventario[item] <= 0) return await sendWarningReply("⚠️ Você não tem essa semente!");
            
            if (!gastarEnergia(stardewDB, remoteJid, participant, 5)) return await sendWarningReply("⚡ Você está exausto! Coma algo ou espere até amanhã.");
            
            user.inventario[item] -= 1;
            user.fazenda.push({
                item: item,
                diaPlantio: global.dia,
                estacao: global.estacaoId,
                regado: false
            });
            
            saveStardewDB(stardewDB);
            return await sendSuccessReply(`🌱 Você plantou *${CULTIVOS[item].nome}*! Não esqueça de regar.`);
        }

        if (acao === "regar") {
            if (user.fazenda.length === 0) return await sendWarningReply("⚠️ Não há nada para regar!");
            
            if (!gastarEnergia(stardewDB, remoteJid, participant, 5)) return await sendWarningReply("⚡ Você está exausto!");
            
            user.fazenda.forEach(c => c.regado = true);
            saveStardewDB(stardewDB);
            return await sendSuccessReply("💧 Você regou todos os seus cultivos! Eles crescerão amanhã.");
        }

        if (acao === "colher") {
            let colhidos = [];
            let xpGanho = 0;
            let lucroTotal = 0;
            
            const novaFazenda = user.fazenda.filter(c => {
                const cult = CULTIVOS[c.item];
                const diasPassados = global.dia - c.diaPlantio + (global.estacaoId - c.estacao) * 28;
                if (diasPassados >= cult.diasParaCrescer) {
                    colhidos.push(cult.nome);
                    xpGanho += cult.xp;
                    lucroTotal += cult.precoVenda;
                    
                    if (cult.multiColheita) {
                        c.diaPlantio = global.dia;
                        c.regado = false;
                        return true; 
                    }
                    return false;
                }
                return true;
            });
            
            if (colhidos.length === 0) return await sendWarningReply("⚠️ Nada pronto para colher ainda.");
            
            user.fazenda = novaFazenda;
            user.xpFazenda += xpGanho;
            ecoDB[remoteJid][participant].saldo += lucroTotal;
            
            if (user.xpFazenda >= user.nivelFazenda * 100) {
                user.nivelFazenda += 1;
                user.energiaMax += 10;
                user.energia = user.energiaMax;
                sendReply(`🎉 *LEVEL UP!* Você agora é um Fazendeiro Nível ${user.nivelFazenda}!\nSua energia máxima aumentou!`);
            }
            
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            saveStardewDB(stardewDB);
            return await sendSuccessReply(`🧺 *COLHEITA REALIZADA!*\n\nVocê colheu: ${colhidos.join(", ")}\n💰 Lucro: ${lucroTotal} Réis\n🌟 XP Ganho: ${xpGanho}`);
        }

        if (acao === "comer") {
            const item = parts[1]?.toLowerCase();
            if (!user.inventario[item] || user.inventario[item] <= 0) return await sendWarningReply("⚠️ Você não tem esse alimento!");
            
            const RECEITAS_STARDEW = {
                "salada": { nome: "Salada de Primavera 🥗", energiaRecuperada: 40 },
                "sobremesa_morango": { nome: "Sobremesa de Morango 🍓", energiaRecuperada: 60 },
                "sopa_abobora": { nome: "Sopa de Abóbora 🎃", energiaRecuperada: 80 },
                "vinho_uva": { nome: "Vinho de Uva Imperial 🍷", energiaRecuperada: 20 }
            };

            const alimento = RECEITAS_STARDEW[item];
            if (!alimento) return await sendWarningReply("⚠️ Isso não é comestível!");
            
            user.inventario[item] -= 1;
            user.energia = Math.min(user.energiaMax, user.energia + alimento.energiaRecuperada);
            
            saveStardewDB(stardewDB);
            return await sendSuccessReply(`😋 Você comeu *${alimento.nome}* e recuperou *${alimento.energiaRecuperada}* de energia!`);
        }
    }
};
