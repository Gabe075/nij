import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { getStardewData, saveStardewDB } from "../../../../lib/StardewUtils.js";
import { FERRAMENTAS_INFO } from "../../../../lib/DadosFerramentas.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
    name: "ferramentas",
    description: "Melhore suas ferramentas na Ferraria do Clint Imperial.",
    commands: ["ferramentas", "ferreiro", "upgrade"],
    usage: `${PREFIX}ferramentas`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
        if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
        
        const participant = webMessage.key.participant || remoteJid;
        const { user, db } = getStardewData(remoteJid, participant);
        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        let ecoDB = {};
        if (fs.existsSync(ecoPath)) ecoDB = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
        
        if (!ecoDB[remoteJid]) ecoDB[remoteJid] = {};
        if (!ecoDB[remoteJid][participant]) ecoDB[remoteJid][participant] = { saldo: 0 };
        
        if (!user.ferramentas) {
            user.ferramentas = { enxada: 0, regador: 0, picareta: 0, machado: 0 };
        }

        if (!acao || acao === "ajuda") {
            let menu = `🔨 *FERRARIA DO CLINT IMPERIAL* 🔨\n\n`;
            menu += `Melhore suas ferramentas para gastar menos energia e ser mais eficiente!\n\n`;
            
            for (const [key, info] of Object.entries(FERRAMENTAS_INFO)) {
                const nivelAtual = user.ferramentas[key] || 0;
                const proximoNivel = nivelAtual + 1;
                
                menu += `🛠️ *${info.nome}* (Atual: ${info.niveis[nivelAtual].material})\n`;
                if (proximoNivel < info.niveis.length) {
                    const next = info.niveis[proximoNivel];
                    menu += `   ↳ Próximo: ${next.material} | Custo: ${next.custo} Réis\n`;
                    menu += `   ↳ Comando: *${PREFIX}ferramentas upgrade ${key}*\n`;
                } else {
                    menu += `   ↳ *NÍVEL MÁXIMO ATINGIDO!* ✨\n`;
                }
                menu += `\n`;
            }
            return await sendReply(menu);
        }

        if (acao === "upgrade") {
            const ferramenta = parts[1]?.toLowerCase();
            if (!FERRAMENTAS_INFO[ferramenta]) return await sendWarningReply("⚠️ Ferramenta inválida!");
            
            const nivelAtual = user.ferramentas[ferramenta] || 0;
            const proximoNivel = nivelAtual + 1;
            
            if (proximoNivel >= FERRAMENTAS_INFO[ferramenta].niveis.length) {
                return await sendWarningReply("⚠️ Esta ferramenta já está no nível máximo!");
            }
            
            const infoNext = FERRAMENTAS_INFO[ferramenta].niveis[proximoNivel];
            if (ecoDB[remoteJid][participant].saldo < infoNext.custo) {
                return await sendWarningReply(`💸 Saldo insuficiente! Você precisa de ${infoNext.custo} Réis.`);
            }
            
            ecoDB[remoteJid][participant].saldo -= infoNext.custo;
            user.ferramentas[ferramenta] = proximoNivel;
            
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            saveStardewDB(db);
            return await sendSuccessReply(`🔨 *UPGRADE CONCLUÍDO!*\nSua *${FERRAMENTAS_INFO[ferramenta].nome}* agora é de *${infoNext.material}*!`);
        }
    }
};
