import fs from "fs";
import path from "path";
import { PREFIX } from "../../../../config.js";
import { getStardewData, saveStardewDB } from "../../../../lib/StardewUtils.js";
import { RECEITAS_STARDEW } from "../../../../lib/Culinaria.js";

const ecoPath = path.resolve("database", "economia.json");

export default {
    name: "cozinha",
    description: "Prepare pratos deliciosos com seus cultivos.",
    commands: ["cozinha", "cozinhar", "receitas"],
    usage: `${PREFIX}cozinha`,
    handle: async ({ fullArgs, sendReply, sendWarningReply, sendSuccessReply, remoteJid, webMessage, isGroup }) => {
        if (!isGroup) return await sendWarningReply("Este comando só pode ser usado em grupos.");
        
        const participant = webMessage.key.participant || remoteJid;
        const { user, db } = getStardewData(remoteJid, participant);
        const parts = fullArgs ? fullArgs.trim().split(/\s+/) : [];
        const acao = parts[0]?.toLowerCase();

        if (!acao || acao === "ajuda") {
            let menu = `🍳 *COZINHA DA FAZENDA IMPERIAL* 🍳\n\n`;
            menu += `Use seus cultivos para preparar pratos que recuperam energia!\n\n`;
            
            for (const [key, r] of Object.entries(RECEITAS_STARDEW)) {
                menu += `🍴 *${r.nome}*\n`;
                menu += `   ↳ Ingredientes: ${Object.entries(r.ingredientes).map(([ing, qtd]) => `${qtd}x ${ing}`).join(", ")}\n`;
                menu += `   ↳ Energia: +${r.energiaRecuperada} | XP: ${r.xp}\n`;
                menu += `   ↳ Comando: *${PREFIX}cozinha preparar ${key}*\n\n`;
            }
            return await sendReply(menu);
        }

        if (acao === "preparar") {
            const prato = parts[1]?.toLowerCase();
            if (!RECEITAS_STARDEW[prato]) return await sendWarningReply("⚠️ Receita não encontrada!");
            
            const receita = RECEITAS_STARDEW[prato];
            
            // Verifica ingredientes no inventário do usuário (Stardew) e no inventário global (Economia)
            // Para simplificar e integrar, vamos checar no inventário de recursos que criamos antes
            let ecoDB = {};
            if (fs.existsSync(ecoPath)) ecoDB = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
            const userEco = ecoDB[remoteJid]?.[participant] || { inventario: {} };
            if (!userEco.inventario) userEco.inventario = {};

            for (const [ing, qtd] of Object.entries(receita.ingredientes)) {
                const qtdNoStardew = user.inventario[ing] || 0;
                const qtdNoEco = userEco.inventario[ing] || 0;
                
                if (qtdNoStardew + qtdNoEco < qtd) {
                    return await sendWarningReply(`⚠️ Ingredientes insuficientes para *${receita.nome}*! Faltam ${qtd - (qtdNoStardew + qtdNoEco)}x ${ing}.`);
                }
            }

            // Consome ingredientes
            for (const [ing, qtd] of Object.entries(receita.ingredientes)) {
                let falta = qtd;
                if (user.inventario[ing]) {
                    const tirar = Math.min(user.inventario[ing], falta);
                    user.inventario[ing] -= tirar;
                    falta -= tirar;
                }
                if (falta > 0 && userEco.inventario[ing]) {
                    userEco.inventario[ing] -= falta;
                }
            }

            // Adiciona prato ao inventário
            user.inventario[prato] = (user.inventario[prato] || 0) + 1;
            user.xpFazenda += receita.xp;
            
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            saveStardewDB(db);
            return await sendSuccessReply(`🍳 Você preparou um(a) *${receita.nome}*! Use *${PREFIX}fazenda comer ${prato}* para recuperar energia.`);
        }
    }
};
