import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "facebook",
  description: "Baixa vídeos do Facebook via Bronxys",
  commands: ["facebook", "fb", "face"],
  usage: `${PREFIX}facebook [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("facebook") && !fullArgs.includes("fb.watch") && !fullArgs.includes("fb.share")) {
      return sendReply("⚠️ Majestade, informe um link válido do Facebook!");
    }

    await sendReact("📥");

    try {
      const videoUrl = `${BASE_URL}/face_video?url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      // Mandamos baixar diretamente pelo helper
      await sendVideoFromURL(videoUrl, "🎬 *Facebook Imperial processado!*");
      await sendReact("✅");

    } catch (error) {
      // Se a API da Bronxys negar o vídeo, o helper vai falhar em baixar e cair aqui
      await sendErrorReply("❌ Não consegui baixar! O link do Facebook pode ser de grupo fechado, ou a API não suporta o formato 'fb.share'. Tente abrir o vídeo e pegar o link oficial (facebook.com/watch).");
    }
  },
};
