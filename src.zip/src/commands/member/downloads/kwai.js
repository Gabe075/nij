import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "kwai",
  description: "Baixa vídeos do Kwai via Bronxys",
  commands: ["kwai"],
  usage: `${PREFIX}kwai [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("kwai")) {
      return sendReply("⚠️ Cadê o link do Kwai, senhor?");
    }

    await sendReact("📥");

    try {
      // Endpoint direto do Kwai
      const videoUrl = `${BASE_URL}/kwai?url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      await sendVideoFromURL(videoUrl, "🎬 *Kwai Imperial*");
      await sendReact("✅");

    } catch (error) {
      await sendErrorReply("❌ Erro ao processar o vídeo do Kwai.");
    }
  },
};
