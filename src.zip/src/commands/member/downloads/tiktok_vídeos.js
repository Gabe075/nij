import axios from "axios";
import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "tiktok",
  description: "Baixa vídeos do TikTok sem marca d'água via Bronxys API",
  commands: ["tiktok", "tk", "tt"],
  usage: `${PREFIX}tiktok [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("tiktok.com")) return sendReply("⚠️ Majestade, informe um link válido do TikTok!");

    await sendReact("📥");

    try {
      // No seu CASES.js, o TikTok é chamado diretamente pela URL do vídeo
      const videoUrl = `${BASE_URL}/tiktok?url=${fullArgs}&apikey=${API_KEY}`;
      
      // Enviamos diretamente usando o helper do seu bot
      await sendVideoFromURL(videoUrl, "🎬 *TikTok processado pela Coroa.*");
      await sendReact("✅");

    } catch (error) {
      console.error(error);
      await sendErrorReply("❌ Falha ao baixar vídeo do TikTok. Verifique o link ou sua API Key.");
    }
  },
};
