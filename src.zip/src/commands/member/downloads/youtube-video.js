import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "yt-video",
  description: "Baixa vídeos do YouTube (MP4) via Bronxys",
  commands: ["yt-video", "ytmp4", "play_video"],
  usage: `${PREFIX}yt-video [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("youtu")) return sendReply("⚠️ Cadê o link do YouTube, senhor?");

    await sendReact("🎥");

    try {
      // No seu CASES.js, o parâmetro é 'nome_url' para o download direto
      const videoUrl = `${BASE_URL}/play_video?nome_url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      await sendVideoFromURL(videoUrl, "🎬 *YouTube Imperial*");
      await sendReact("✅");

    } catch (error) {
      await sendErrorReply("❌ Falha ao baixar vídeo. A API pode estar instável.");
    }
  },
};
