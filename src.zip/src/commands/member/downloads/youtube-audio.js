import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "yt-audio",
  description: "Baixa músicas do YouTube (MP3) via Bronxys",
  commands: ["yt-audio", "ytmp3", "play", "musica"],
  usage: `${PREFIX}yt-audio [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendAudioFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("youtu")) return sendReply("⚠️ Cadê o link do YouTube?");

    await sendReact("🎵");

    try {
      // No seu CASES.js, o endpoint 'play' é o que gera o áudio
      const audioUrl = `${BASE_URL}/play?nome_url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      await sendAudioFromURL(audioUrl, false, true);
      await sendReact("✅");

    } catch (error) {
      await sendErrorReply("❌ Falha na conversão para MP3.");
    }
  },
};
