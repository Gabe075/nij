import axios from "axios";
import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "instagram",
  description: "Baixa Reels ou Fotos do Instagram via Bronxys API",
  commands: ["instagram", "ig", "reels"],
  usage: `${PREFIX}instagram [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendImageFromURL, sendErrorReply }) => {
    if (!fullArgs.includes("instagram.com")) return sendReply("⚠️ Majestade, cadê o link do Instagram?");

    await sendReact("📸");

    try {
      // Diferente do TikTok, o Instagram no seu CASES.js busca o JSON primeiro
      const { data } = await axios.get(`${BASE_URL}/instagram?url=${fullArgs}&apikey=${API_KEY}`);
      
      if (!data.msg || data.msg.length === 0) throw new Error("Mídia não encontrada");

      const mediaUrl = data.msg[0].url;
      const mediaType = data.msg[0].type; // 'mp4', 'jpg', 'webp', etc.

      if (mediaType === "mp4") {
        await sendVideoFromURL(mediaUrl, "🎬 *Reels Imperial*");
      } else {
        await sendImageFromURL(mediaUrl, "📸 *Imagem Imperial*");
      }
      
      await sendReact("✅");

    } catch (error) {
      console.error(error);
      await sendErrorReply("❌ Erro ao processar conteúdo do Instagram. A API pode estar instável.");
    }
  },
};
