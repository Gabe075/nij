import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "threads",
  description: "Baixa vídeos ou fotos do Threads via Bronxys",
  commands: ["threads", "thr"],
  usage: `${PREFIX}threads [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendImageFromURL, sendErrorReply }) => {
    // Agora a barreira aceita qualquer link que tenha "threads" na URL, seja .com ou .net
    if (!fullArgs.includes("threads")) {
      return sendReply("⚠️ Majestade, informe um link válido do Threads!");
    }

    await sendReact("📥");

    try {
      const mediaUrl = `${BASE_URL}/threads?url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      // Tenta puxar como vídeo primeiro
      await sendVideoFromURL(mediaUrl, "🎬 *Threads Imperial*");
      await sendReact("✅");

    } catch (error) {
      // Se não for vídeo, tenta puxar como foto
      try {
        const mediaUrl = `${BASE_URL}/threads?url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
        await sendImageFromURL(mediaUrl, "📸 *Foto do Threads*");
        await sendReact("✅");
      } catch (err) {
        await sendErrorReply("❌ Falha ao baixar do Threads. O link pode ser inválido ou a API não encontrou a mídia.");
      }
    }
  },
};
