import { PREFIX } from "../../../config.js";

const API_KEY = "Gabe.AM29";
const BASE_URL = "https://api.bronxyshost.com.br/api-bronxys";

export default {
  name: "twitter",
  description: "Baixa vídeos do X (antigo Twitter) via Bronxys",
  commands: ["twitter", "x", "tw"],
  usage: `${PREFIX}twitter [link]`,

  handle: async ({ fullArgs, sendReply, sendReact, sendVideoFromURL, sendErrorReply }) => {
    // Aceita tanto links do twitter quanto os novos links do x.com
    if (!fullArgs.includes("twitter.com") && !fullArgs.includes("x.com")) {
      return sendReply("⚠️ Majestade, informe um link válido do X/Twitter!");
    }

    await sendReact("📥");

    try {
      // Conforme seu CASES.js, o endpoint é 'twitter_video'
      const videoUrl = `${BASE_URL}/twitter_video?url=${encodeURIComponent(fullArgs)}&apikey=${API_KEY}`;
      
      await sendVideoFromURL(videoUrl, "🎬 *Vídeo do X processado!*");
      await sendReact("✅");

    } catch (error) {
      await sendErrorReply("❌ Falha ao baixar! Verifique se a conta do X é pública ou se o link está correto.");
    }
  },
};
