import fs from "fs";
import path from "path";
import { exec } from "child_process";
import unzipper from "unzipper";

import {
  downloadContentFromMessage,
} from "baileys";

export default {
  name: "figpack",
  description: "Extrai e converte stickers de arquivos .fig (formato zip)",
  commands: ["pack"],

  handle: async ({
    webMessage,
    sendStickerFromFile,
    sendWaitReact,
    sendSuccessReact,
    sendErrorReply,
  }) => {
    let tempFile = null;
    let extractPath = null;

    try {
      await sendWaitReact();

      const quoted =
        webMessage.message?.extendedTextMessage
          ?.contextInfo?.quotedMessage;

      if (!quoted?.documentMessage) {
        return await sendErrorReply("Responda um arquivo .fig");
      }

      const doc = quoted.documentMessage;

      if (!doc.fileName?.toLowerCase().endsWith(".fig")) {
        return await sendErrorReply("O arquivo precisa ter a extensão .fig");
      }

      // baixa arquivo
      const stream = await downloadContentFromMessage(doc, "document");
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      // define caminhos
      const timestamp = Date.now();
      tempFile = `./temp/${timestamp}.fig`;
      extractPath = `./temp/extracted_${timestamp}`;

      fs.writeFileSync(tempFile, buffer);
      fs.mkdirSync(extractPath, { recursive: true });

      // Extrai usando unzipper (O arquivo DEVE ser um ZIP renomeado para .fig)
      await fs
        .createReadStream(tempFile)
        .pipe(unzipper.Extract({ path: extractPath }))
        .promise();

      // Pega arquivos recursivamente
      function getAllFiles(dir) {
        let results = [];
        const list = fs.readdirSync(dir);
        for (const file of list) {
          const fullPath = path.join(dir, file);
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            results = results.concat(getAllFiles(fullPath));
          } else {
            results.push(fullPath);
          }
        }
        return results;
      }

      // Filtra os formatos suportados
      const files = getAllFiles(extractPath).filter((file) => {
        const ext = path.extname(file).toLowerCase();
        return [".webp", ".png", ".jpg", ".jpeg", ".gif", ".mp4"].includes(ext);
      });

      if (!files.length) {
        return await sendErrorReply("Nenhuma mídia suportada encontrada no pacote.");
      }

      // Processa e envia cada arquivo
      for (const file of files) {
        try {
          const ext = path.extname(file).toLowerCase();
          let finalStickerPath = file;

          // Se for imagem estática (png, jpg), converte para webp
          if ([".png", ".jpg", ".jpeg"].includes(ext)) {
            finalStickerPath = `${file}_converted.webp`;
            await new Promise((resolve, reject) => {
              const cmd = `ffmpeg -i "${file}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -f webp -quality 90 "${finalStickerPath}"`;
              exec(cmd, (err) => (err ? reject(err) : resolve()));
            });
          } 
          // Se for vídeo ou gif, converte para webp animado
          else if ([".mp4", ".gif"].includes(ext)) {
            finalStickerPath = `${file}_converted.webp`;
            await new Promise((resolve, reject) => {
              const cmd = `ffmpeg -y -i "${file}" -vf "scale=350:350,fps=15" -c:v libwebp -loop 0 -quality 8 -compression_level 6 -method 6 -preset picture -an -f webp "${finalStickerPath}"`;
              exec(cmd, (err) => (err ? reject(err) : resolve()));
            });
          }

          // Envia a figurinha
          await sendStickerFromFile(finalStickerPath);

        } catch (err) {
          console.log("Erro ao processar/enviar figurinha:", file, err.message);
        }
      }

      await sendSuccessReact();

    } catch (err) {
      console.log(err);
      await sendErrorReply(`Erro:\n${err.message}`);
    } finally {
      // Limpeza
      try {
        if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        if (extractPath && fs.existsSync(extractPath)) {
          fs.rmSync(extractPath, { recursive: true, force: true });
        }
      } catch (cleanupErr) {
        console.log("Erro ao limpar arquivos:", cleanupErr.message);
      }
    }
  },
};
