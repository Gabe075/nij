import axios from "axios";
import fs from "fs";
import path from "path";
import { PREFIX } from "../config.js";

// Chave da Groq
const GROQ_KEY = "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";

// Caminhos dos bancos de dados
const aiDbPath = path.resolve("database", "ai-groups.json");
const antiBetDbPath = path.resolve("database", "anti-bet.json");
const memoryPath = path.resolve("database", "memory.json");
const levelsPath = path.resolve("database", "levels.json");
const remindersPath = path.resolve("database", "reminders.json");
const ecoPath = path.resolve("database", "economia.json");
const loteriaPath = path.resolve("database", "loteria.json");
const antifakePath = path.resolve("database", "antifake.json");

// Variável para garantir que o despertador só inicie uma vez
let reminderLoopStarted = false;

// Funções auxiliares
function getDB(dbPath) {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}));
    return {};
  }
  return JSON.parse(fs.readFileSync(dbPath, "utf-8"));
}

function saveDB(dbPath, data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

export async function customMiddleware({ type, commonFunctions, webMessage, socket, action, data }) {
  
  // ==========================================
  // ⏰ MOTOR DE SEGUNDO PLANO (Lembretes e Loteria)
  // ==========================================
  if (!reminderLoopStarted && socket) {
    reminderLoopStarted = true;
    
    setInterval(async () => {
      const now = Date.now();

      // --- 1. LÓGICA DOS LEMBRETES ---
      if (fs.existsSync(remindersPath)) {
        try {
          let reminders = JSON.parse(fs.readFileSync(remindersPath, "utf-8"));
          let changed = false;

          for (let i = reminders.length - 1; i >= 0; i--) {
            const rem = reminders[i];
            
            if (now >= rem.targetTime) {
              let prefixMsg = "⏰ *BEEP BEEP!*";
              
              if (rem.type === "ds") {
                const timeLeft = rem.baseTime - now;
                if (timeLeft > 2 * 60 * 60 * 1000) {
                  prefixMsg = "🌅 *BOM DIA! Lembrete de hoje:*";
                } else if (timeLeft > 5 * 60 * 1000) {
                  prefixMsg = "⏳ *ATENÇÃO! Faltam 30 minutos para:*";
                } else {
                  prefixMsg = "🚨 *É AGORA!*";
                }
              }

              try {
                await socket.sendMessage(rem.participant, { text: `${prefixMsg}\n\n👉 *${rem.message}*` });
              } catch (e) {}
              
              if (rem.type === "df") {
                reminders.splice(i, 1); 
              } else if (rem.type === "dc") {
                rem.targetTime += rem.intervalMs; 
              } else if (rem.type === "dr") {
                rem.targetTime += 24 * 60 * 60 * 1000; 
              } else if (rem.type === "ds") {
                const timeLeft = rem.baseTime - now;
                if (timeLeft > 2 * 60 * 60 * 1000) {
                  rem.targetTime = rem.baseTime - (30 * 60 * 1000); 
                } else if (timeLeft > 5 * 60 * 1000) {
                  rem.targetTime = rem.baseTime; 
                } else {
                  reminders.splice(i, 1); 
                }
              }
              changed = true;
            }
          }
          if (changed) fs.writeFileSync(remindersPath, JSON.stringify(reminders, null, 2));
        } catch (err) {
          console.error("Erro nos lembretes:", err);
        }
      }

      // --- 2. LÓGICA DA LOTERIA IMPERIAL ---
      if (fs.existsSync(ecoPath)) {
        try {
          let loteriaDB = fs.existsSync(loteriaPath) ? JSON.parse(fs.readFileSync(loteriaPath, "utf-8")) : {};
          let ecoDB = JSON.parse(fs.readFileSync(ecoPath, "utf-8"));
          const hoje = new Date().toDateString();

          if (!loteriaDB.global) loteriaDB.global = { dia: "", horarios: [], status: "fechado", fechamento: 0, participantes: [] };
          let loteriaChanged = false;

          // A. GERA OS 3 HORÁRIOS ALEATÓRIOS DO DIA
          if (loteriaDB.global.dia !== hoje) {
            loteriaDB.global.dia = hoje;
            loteriaDB.global.status = "fechado";
            loteriaDB.global.participantes = [];
            
            const fimDoDia = new Date().setHours(23, 59, 59, 999);
            loteriaDB.global.horarios = [
              now + Math.random() * (fimDoDia - now),
              now + Math.random() * (fimDoDia - now),
              now + Math.random() * (fimDoDia - now)
            ].sort();
            loteriaChanged = true;
          }

          // B. ABRE A LOTERIA E ANUNCIA
          if (loteriaDB.global.status === "fechado" && loteriaDB.global.horarios.length > 0) {
            if (now >= loteriaDB.global.horarios[0]) {
              loteriaDB.global.horarios.shift(); 
              loteriaDB.global.status = "aberto";
              loteriaDB.global.fechamento = now + (15 * 60 * 1000); 
              loteriaDB.global.participantes = [];
              loteriaChanged = true;

              const grupos = Object.keys(ecoDB);
              for (const grupo of grupos) {
                try {
                  await socket.sendMessage(grupo, { text: `🚨 🎟️ *LOTERIA IMPERIAL ABERTA!* 🎟️ 🚨\n\nO sorteio relâmpago começou! Vocês têm *15 MINUTOS* para comprar o bilhete.\n\n💰 Custo: 100 Réis\n🏆 Prêmio: Até 10.000 Réis!\n\n👉 Digite *!loteria comprar* para participar!` });
                } catch (e) {}
              }
            }
          }

          // C. FECHA A LOTERIA E SORTEA O VENCEDOR
          if (loteriaDB.global.status === "aberto" && now >= loteriaDB.global.fechamento) {
            loteriaDB.global.status = "fechado";
            const participantes = loteriaDB.global.participantes;
            
            if (participantes.length < 2) {
              const grupos = Object.keys(ecoDB);
              for (const grupo of grupos) {
                try {
                  await socket.sendMessage(grupo, { text: `🎟️ *LOTERIA CANCELADA* 🎟️\n\nNão houve participantes suficientes (mínimo 2). O dinheiro dos bilhetes foi devolvido.` });
                } catch (e) {}
              }
              for (const p of participantes) {
                if (ecoDB[p.grupo] && ecoDB[p.grupo][p.jid]) ecoDB[p.grupo][p.jid].saldo += 100;
              }
            } else {
              const vencedorIndex = Math.floor(Math.random() * participantes.length);
              const vencedor = participantes[vencedorIndex];

              let level = 1;
              if (fs.existsSync(levelsPath)) {
                const levelsDB = JSON.parse(fs.readFileSync(levelsPath, "utf-8"));
                if (levelsDB[vencedor.grupo] && levelsDB[vencedor.grupo][vencedor.jid]) {
                  level = levelsDB[vencedor.grupo][vencedor.jid].level;
                }
              }
              let premio = Math.min(10000, level * 1000);
              if (premio < 1000) premio = 1000;

              if (ecoDB[vencedor.grupo] && ecoDB[vencedor.grupo][vencedor.jid]) {
                ecoDB[vencedor.grupo][vencedor.jid].saldo += premio;
              }

              const grupos = Object.keys(ecoDB);
              for (const grupo of grupos) {
                try {
                  await socket.sendMessage(grupo, { 
                    text: `🎉 🎟️ *RESULTADO DA LOTERIA!* 🎟️ 🎉\n\nO grande vencedor do sorteio relâmpago foi @${vencedor.jid.split("@")[0]}!\n\nComo o vencedor é *Nível ${level}*, o prêmio gerado foi de 💰 *${premio} Réis*!`, 
                    mentions: [vencedor.jid] 
                  });
                } catch (e) {}
              }
            }
            fs.writeFileSync(ecoPath, JSON.stringify(ecoDB, null, 2));
            loteriaChanged = true;
          }

          if (loteriaChanged) fs.writeFileSync(loteriaPath, JSON.stringify(loteriaDB, null, 2));
        } catch (err) {
          console.error("Erro no motor da loteria:", err);
        }
      }
    }, 10000);
  }

  // ==========================================
  // 🛡️ ANTI-FAKE (Controle de DDI na entrada)
  // ==========================================
  if (type === "participant" && action === "add" && data) {
    try {
      const remoteJid = webMessage?.key?.remoteJid || webMessage?.id; 
      if (fs.existsSync(antifakePath) && remoteJid) {
        const db = JSON.parse(fs.readFileSync(antifakePath, "utf-8"));
        const blockedDDIs = db[remoteJid] || [];

        if (blockedDDIs.length > 0) {
          let participants = Array.isArray(data) ? data : [data];

          for (let user of participants) {
            if (typeof user === "string" && user.trim().startsWith("{")) {
              try { user = JSON.parse(user); } catch (e) {}
            }

            let targetJid = "";
            if (typeof user === "object" && user !== null) {
              targetJid = user.phoneNumber || user.id || user.jid;
            } else {
              targetJid = String(user);
            }

            if (!targetJid) continue;

            const participantNumber = targetJid.split("@")[0].replace(/[^0-9]/g, "");
            const isBlocked = blockedDDIs.some(ddi => participantNumber.startsWith(ddi));

            if (isBlocked) {
              const groupMetadata = await socket.groupMetadata(remoteJid);
              const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
              const actorJid = webMessage?.participant || webMessage?.key?.participant || targetJid;

              if (!admins.includes(actorJid)) {
                const jidToRemove = (typeof user === "object" && user.id) ? user.id : targetJid;
                await socket.groupParticipantsUpdate(remoteJid, [jidToRemove], "remove");
                await socket.sendMessage(remoteJid, {
                  text: `🚫 *ANTI-FAKE ATIVADO!*\n\nUm número estrangeiro (+${participantNumber.substring(0, 3)}...) tentou entrar e foi banido.\n\n_(Apenas Administradores podem adicionar números de outros países)._`
                });
              }
            }
          }
        }
      }
    } catch (err) {
      console.error("❌ Erro no Anti-Fake:", err.message);
    }
  }

  // ==========================================
  // PROCESSAMENTO DE MENSAGENS
  // ==========================================
  if (type === "message" && commonFunctions) {
    const { 
      remoteJid, 
      isGroup, 
      fullMessage, 
      sendReply, 
      sendReact, 
      isImage, 
      isVideo, 
      isAudio, 
      isSticker,
      userLid,
      deleteMessage
    } = commonFunctions;

    if (!isGroup || !fullMessage) return;
    if (webMessage.key.fromMe) return;

    // 🕒 SISTEMA ANTI-FLOOD
    const messageTime = Number(webMessage.messageTimestamp);
    const currentTime = Math.floor(Date.now() / 1000);
    if (currentTime - messageTime > 60) return;

// 🛡️ SISTEMA ANTI-BET IMPERIAL
if (fs.existsSync(antiBetDbPath)) {

  const antiBetGroups =
    JSON.parse(
      fs.readFileSync(
        antiBetDbPath,
        "utf-8"
      )
    );

  if (antiBetGroups.includes(remoteJid)) {

    function isBetLink(text = "") {

      const texto = text.toLowerCase();

      let score = 0;

      // =========================
      // TRACKERS
      // =========================

      const trackers = [
        "campaignid=",
        "creativeid=",
        "adsetid=",
        "click_id=",
        "pixel_id=",
        "fbclid=",
        "kwaiid=",
        "_ts=",
        "utm_source=",
        "utm_campaign="
      ];

      for (const tracker of trackers) {
        if (texto.includes(tracker)) {
          score += 3;
        }
      }

      // =========================
      // PALAVRAS SUSPEITAS
      // =========================

      const palavras = [
        "bet",
        "pg",
        "win",
        "vip",
        "cassino",
        "casino",
        "slot",
        "slots",
        "roleta",
        "fortune",
        "jackpot",
        "crash",
        "double",
        "aviator",
        "stake",
        "blaze",
        "1win",
        "pixbet",
        "betano",
        "bet365",
        "tigrinho"
      ];

      for (const palavra of palavras) {
        if (texto.includes(palavra)) {
          score += 2;
        }
      }

      // =========================
      // MUITOS PARÂMETROS
      // =========================

      const parametros =
        (texto.match(/=/g) || []).length;

      if (parametros >= 4) {
        score += 4;
      }

      // =========================
      // EXTRAÇÃO DE URL
      // =========================

      const urls =
        texto.match(/https?:\/\/[^\s]+/g) || [];

      for (const link of urls) {

        try {

          const url = new URL(link);

          const host =
            url.hostname.replace("www.", "");

          // =====================
          // DOMÍNIO RANDOMIZADO
          // =====================

          const dominioAleatorio =
            /^[a-z0-9-]{5,20}\.(com|net|org|vip|co)$/i
              .test(host);

          if (dominioAleatorio) {
            score += 4;
          }

          // =====================
          // TLDS SUSPEITAS
          // =====================

          const tlds = [
            ".vip",
            ".top",
            ".xyz",
            ".fun",
            ".click",
            ".monster"
          ];

          if (
            tlds.some(
              tld => host.endsWith(tld)
            )
          ) {
            score += 5;
          }

          // =====================
          // HOST COM PADRÕES
          // =====================

          if (
            host.includes("pg") ||
            host.includes("win")
          ) {
            score += 3;
          }

        } catch {}

      }

      // =========================
      // SCORE FINAL
      // =========================

      return score >= 8;
    }

    const detected =
      isBetLink(fullMessage);

    if (detected) {

      try {

        await deleteMessage(
          webMessage.key
        );

        const participantJid =
          webMessage.key.participant;

        await socket.groupParticipantsUpdate(
          remoteJid,
          [participantJid],
          "remove"
        );

        await sendReply(
`🚫 *GUILHOTINA IMPERIAL!*

Um link de apostas/cassino foi detectado automaticamente.

👤 Usuário removido com sucesso.`
        );

        return;

      } catch (err) {

        console.error(
          "Erro no Anti-Bet:",
          err.message
        );

        return;
      }
    }
  }
}

    // 🎮 SISTEMA DE LEVEL E XP
    const participantJid = webMessage.key.participant; 
    const levelsDB = getDB(levelsPath);
    
    if (!levelsDB[remoteJid]) levelsDB[remoteJid] = {};
    if (!levelsDB[remoteJid][participantJid]) {
      levelsDB[remoteJid][participantJid] = { xp: 0, level: 1 };
    }

    const xpGained = Math.floor(Math.random() * 16) + 10;
    levelsDB[remoteJid][participantJid].xp += xpGained;

    const currentXp = levelsDB[remoteJid][participantJid].xp;
    const oldLevel = levelsDB[remoteJid][participantJid].level || 1;
    
    const correctLevel = currentXp < 300 ? 1 : 2 + Math.floor((currentXp - 300) / 400);

    let subiuDeNivel = false;
    if (correctLevel > oldLevel) {
      levelsDB[remoteJid][participantJid].level = correctLevel;
      subiuDeNivel = true;
    }

    saveDB(levelsPath, levelsDB);

    if (subiuDeNivel) {
      await sendReply(`🎉 Parabéns @${participantJid.split("@")[0]}! Você alcançou o *Nível ${correctLevel}*! 🚀`, [participantJid]);
    }

    // 🤖 SISTEMA DA IA (Gabirosvaldo)
    if (isImage || isVideo || isAudio || isSticker) return;
    if (fullMessage.startsWith(PREFIX)) return;
    if (!fs.existsSync(aiDbPath)) return;
    
    const aiGroups = JSON.parse(fs.readFileSync(aiDbPath, "utf-8"));
    if (!aiGroups.includes(remoteJid)) return;

    try {
      await sendReact("👀");

      const memoryDB = getDB(memoryPath);
      const memoryKey = `${remoteJid}-${userLid}`;
      let history = memoryDB[memoryKey] || [];

      history.push({ role: "user", content: fullMessage });
      if (history.length > 15) history = history.slice(history.length - 15);

      const messagesToSend = [
        {
          role: "system",
          content: "Seu nome é Gabirosvaldo. Você é um jovem brasileiro conversando no WhatsApp com amigos. Seja natural, direto e amigável. Fale como uma pessoa real, usando um tom casual. Evite parecer um robô ou assistente. Use gírias de forma muito natural e esporádica, apenas quando fizer sentido no contexto, sem exagerar ou forçar a barra. Responda de forma curta, como em uma mensagem de texto."
        },
        ...history
      ];

      const response = await axios.post(
        "https://api.groq.com/openai/v1/chat/completions",
        {
          model: "llama-3.1-8b-instant",
          messages: messagesToSend,
          temperature: 0.8,
          max_tokens: 300
        },
        {
          headers: {
            "Authorization": `Bearer ${GROQ_KEY}`,
            "Content-Type": "application/json"
          }
        }
      );

      const respostaIA = response.data.choices[0].message.content;

      history.push({ role: "assistant", content: respostaIA });
      if (history.length > 15) history = history.slice(history.length - 15);

      memoryDB[memoryKey] = history;
      saveDB(memoryPath, memoryDB);

      await sendReply(respostaIA);

    } catch (error) {
      console.error("❌ Erro na Groq:", error.response?.data || error.message);
    }
  }
}
