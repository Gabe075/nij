/**
 * Logs
 *
 * @author Dev Gui
 */
import pkg from "../../package.json" with { type: "json" };

export function sayLog(message) {
  console.log("\x1b[36m[DOM PEDRO II | TALK]\x1b[0m", message);
}

export function inputLog(message) {
  console.log("\x1b[30m[DOM PEDRO II | INPUT]\x1b[0m", message);
}

export function infoLog(message) {
  console.log("\x1b[34m[DOM PEDRO II | INFO]\x1b[0m", message);
}

export function successLog(message) {
  console.log("\x1b[32m[DOM PEDRO II | SUCCESS]\x1b[0m", message);
}

export function errorLog(message) {
  console.log("\x1b[31m[DOM PEDRO II | ERROR]\x1b[0m", message);
}

export function warningLog(message) {
  console.log("\x1b[33m[DOM PEDRO II | WARNING]\x1b[0m", message);
}


export function bannerLog() {
  console.log(`\x1b[32m░█▀▄░█▀█░█▄█░░█▀█░█▀▀░█▀▄░█▀█░█▀█░░▀█▀░▀█▀░\x1b[0m`);
  console.log(`\x1b[33m░█░█░█░█░█░█░░█▀▀░█▀▀░█░█░█▀▄░█░█░░░█░░░█░░\x1b[0m`);
  console.log(`\x1b[32m░▀▀░░▀▀▀░▀░▀░░▀░░░▀▀▀░▀▀░░▀░▀░▀▀▀░░▀▀▀░▀▀▀░\x1b[0m`);
  console.log(`\x1b[32m👑 Versão: \x1b[0m${pkg.version}\n`);
}