import fs from "fs";
import path from "path";
import unzipper from "unzipper";

export async function extractStickers(filePath) {
  const extractPath = "./temp/stickers";

  if (!fs.existsSync(extractPath)) {
    fs.mkdirSync(extractPath, { recursive: true });
  }

  await fs
    .createReadStream(filePath)
    .pipe(unzipper.Extract({ path: extractPath }))
    .promise();

  const files = fs
    .readdirSync(extractPath)
    .filter((file) => file.endsWith(".webp"));

  return files.map((file) => path.join(extractPath, file));
}